﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_applicationSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_applicationSettings))
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.rb2 = New System.Windows.Forms.RadioButton()
        Me.rb1 = New System.Windows.Forms.RadioButton()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Track_Smooth = New System.Windows.Forms.TrackBar()
        Me.btnSmoothing = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Track_Sharp = New System.Windows.Forms.TrackBar()
        Me.btnSharpness = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Track_Gamma = New System.Windows.Forms.TrackBar()
        Me.Track_Histogram = New System.Windows.Forms.TrackBar()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnContrast = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.chkWithImage = New System.Windows.Forms.CheckBox()
        Me.cmbSplitMode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.rbFiles = New System.Windows.Forms.RadioButton()
        Me.rbDoc = New System.Windows.Forms.RadioButton()
        Me.rbProfile = New System.Windows.Forms.RadioButton()
        Me.rbpanoramic = New System.Windows.Forms.RadioButton()
        Me.rbColors = New System.Windows.Forms.RadioButton()
        Me.rbXray = New System.Windows.Forms.RadioButton()
        Me.rbCompare = New System.Windows.Forms.RadioButton()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.chkPositions2 = New System.Windows.Forms.CheckBox()
        Me.chkImageNotes2 = New System.Windows.Forms.CheckBox()
        Me.chkCreationDate2 = New System.Windows.Forms.CheckBox()
        Me.chkImageid2 = New System.Windows.Forms.CheckBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.chkPositions1 = New System.Windows.Forms.CheckBox()
        Me.chkImageNotes1 = New System.Windows.Forms.CheckBox()
        Me.chkCreationDate1 = New System.Windows.Forms.CheckBox()
        Me.chkImageID1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.chkPositions = New System.Windows.Forms.CheckBox()
        Me.chkImageNotes = New System.Windows.Forms.CheckBox()
        Me.chkCreationDate = New System.Windows.Forms.CheckBox()
        Me.chkImageid = New System.Windows.Forms.CheckBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtComputerName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkOpenDentist = New System.Windows.Forms.CheckBox()
        Me.chkadmnID = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtLabel = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.chkSSNNo = New System.Windows.Forms.CheckBox()
        Me.chkOrderNo = New System.Windows.Forms.CheckBox()
        Me.chkptName = New System.Windows.Forms.CheckBox()
        Me.chkPtID = New System.Windows.Forms.CheckBox()
        Me.chkDentist = New System.Windows.Forms.CheckBox()
        Me.chkmultiple = New System.Windows.Forms.CheckBox()
        Me.chkReopen = New System.Windows.Forms.CheckBox()
        Me.cmbMonitor = New System.Windows.Forms.ComboBox()
        Me.cmbLanguage = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.btnD = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnA = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.btnResetDefault = New System.Windows.Forms.Button()
        Me.chkAutoUpdate = New System.Windows.Forms.CheckBox()
        Me.btnResetFilter = New System.Windows.Forms.Button()
        Me.btnTest = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.trkThreshold = New System.Windows.Forms.TrackBar()
        Me.trkAmount = New System.Windows.Forms.TrackBar()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.trkPixel = New System.Windows.Forms.TrackBar()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.outside_edge = New System.Windows.Forms.PictureBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.Normal = New System.Windows.Forms.PictureBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Active = New System.Windows.Forms.PictureBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Selected = New System.Windows.Forms.PictureBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.btnReady_Stop = New System.Windows.Forms.Button()
        Me.btnLoadPhoto_Stop = New System.Windows.Forms.Button()
        Me.btnOpenPhoto_Stop = New System.Windows.Forms.Button()
        Me.btnOpenNewPt_Stop = New System.Windows.Forms.Button()
        Me.btnOpenPt_Stop = New System.Windows.Forms.Button()
        Me.btnStartup_Stop = New System.Windows.Forms.Button()
        Me.btnReady_Play = New System.Windows.Forms.Button()
        Me.btnReady = New System.Windows.Forms.Button()
        Me.btnLoadPhoto_Play = New System.Windows.Forms.Button()
        Me.btnLoadPhoto = New System.Windows.Forms.Button()
        Me.btnOpenPhoto_Play = New System.Windows.Forms.Button()
        Me.btnOpenPhoto = New System.Windows.Forms.Button()
        Me.btnOpenNewPt_Play = New System.Windows.Forms.Button()
        Me.btnOpenNewPt = New System.Windows.Forms.Button()
        Me.btnOpenPt_Play = New System.Windows.Forms.Button()
        Me.btnOpenPt = New System.Windows.Forms.Button()
        Me.btnStartup_Play = New System.Windows.Forms.Button()
        Me.btnStartup = New System.Windows.Forms.Button()
        Me.txtExpose = New System.Windows.Forms.TextBox()
        Me.txtLoadPhoto = New System.Windows.Forms.TextBox()
        Me.txtNewPhoto = New System.Windows.Forms.TextBox()
        Me.txtNewPatient = New System.Windows.Forms.TextBox()
        Me.txtSoundOpenPt = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtSound_StartUp = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.dtpRegDate = New System.Windows.Forms.DateTimePicker()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.chkLstModules = New System.Windows.Forms.CheckedListBox()
        Me.btnFromDisk = New System.Windows.Forms.Button()
        Me.txtMaxUsers = New System.Windows.Forms.TextBox()
        Me.txtLicenseCode = New System.Windows.Forms.TextBox()
        Me.txtLicenseName = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.ColorDialog2 = New System.Windows.Forms.ColorDialog()
        Me.ColorDialog3 = New System.Windows.Forms.ColorDialog()
        Me.ColorDialog4 = New System.Windows.Forms.ColorDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.Track_Smooth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.Track_Sharp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.Track_Gamma, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Track_Histogram, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.trkThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkPixel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        CType(Me.outside_edge, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox13.SuspendLayout()
        CType(Me.Normal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Active, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Selected, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox12)
        Me.TabPage3.Controls.Add(Me.btnReset)
        Me.TabPage3.Controls.Add(Me.GroupBox11)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 23)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(768, 406)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Image Settings"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.rb2)
        Me.GroupBox12.Controls.Add(Me.rb1)
        Me.GroupBox12.Location = New System.Drawing.Point(551, 240)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(200, 69)
        Me.GroupBox12.TabIndex = 15
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Auto-histogram version"
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.Location = New System.Drawing.Point(3, 37)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(45, 18)
        Me.rb2.TabIndex = 1
        Me.rb2.Text = "2.0"
        Me.rb2.UseVisualStyleBackColor = True
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.Checked = True
        Me.rb1.Location = New System.Drawing.Point(3, 16)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(45, 18)
        Me.rb1.TabIndex = 0
        Me.rb1.TabStop = True
        Me.rb1.Text = "1.0"
        Me.rb1.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Enabled = False
        Me.btnReset.Location = New System.Drawing.Point(597, 204)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(91, 30)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Track_Smooth)
        Me.GroupBox11.Controls.Add(Me.btnSmoothing)
        Me.GroupBox11.Controls.Add(Me.Label16)
        Me.GroupBox11.Controls.Add(Me.Label17)
        Me.GroupBox11.Location = New System.Drawing.Point(6, 319)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(533, 85)
        Me.GroupBox11.TabIndex = 13
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Smoothing filter strength[10]"
        '
        'Track_Smooth
        '
        Me.Track_Smooth.Location = New System.Drawing.Point(5, 16)
        Me.Track_Smooth.Name = "Track_Smooth"
        Me.Track_Smooth.Size = New System.Drawing.Size(321, 45)
        Me.Track_Smooth.TabIndex = 7
        '
        'btnSmoothing
        '
        Me.btnSmoothing.Enabled = False
        Me.btnSmoothing.Location = New System.Drawing.Point(412, 19)
        Me.btnSmoothing.Name = "btnSmoothing"
        Me.btnSmoothing.Size = New System.Drawing.Size(91, 30)
        Me.btnSmoothing.TabIndex = 6
        Me.btnSmoothing.Text = "Test"
        Me.btnSmoothing.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(286, 64)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(49, 14)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "[more]"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(5, 65)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(42, 14)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "[less]"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Track_Sharp)
        Me.GroupBox5.Controls.Add(Me.btnSharpness)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 233)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(533, 76)
        Me.GroupBox5.TabIndex = 12
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Sharpness filter strength[6]"
        '
        'Track_Sharp
        '
        Me.Track_Sharp.BackColor = System.Drawing.SystemColors.Control
        Me.Track_Sharp.Location = New System.Drawing.Point(8, 16)
        Me.Track_Sharp.Name = "Track_Sharp"
        Me.Track_Sharp.Size = New System.Drawing.Size(318, 45)
        Me.Track_Sharp.TabIndex = 6
        '
        'btnSharpness
        '
        Me.btnSharpness.Enabled = False
        Me.btnSharpness.Location = New System.Drawing.Point(412, 31)
        Me.btnSharpness.Name = "btnSharpness"
        Me.btnSharpness.Size = New System.Drawing.Size(91, 30)
        Me.btnSharpness.TabIndex = 5
        Me.btnSharpness.Text = "Test"
        Me.btnSharpness.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(286, 60)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 14)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "[more]"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(5, 60)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(42, 14)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "[less]"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Track_Gamma)
        Me.GroupBox4.Controls.Add(Me.Track_Histogram)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.btnContrast)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(539, 227)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Optimal contrast correction:"
        '
        'Track_Gamma
        '
        Me.Track_Gamma.Location = New System.Drawing.Point(14, 156)
        Me.Track_Gamma.Maximum = 40
        Me.Track_Gamma.Minimum = -40
        Me.Track_Gamma.Name = "Track_Gamma"
        Me.Track_Gamma.Size = New System.Drawing.Size(318, 45)
        Me.Track_Gamma.TabIndex = 10
        Me.Track_Gamma.TickFrequency = 5
        Me.Track_Gamma.Value = -40
        '
        'Track_Histogram
        '
        Me.Track_Histogram.Location = New System.Drawing.Point(14, 42)
        Me.Track_Histogram.Maximum = 50
        Me.Track_Histogram.Minimum = -50
        Me.Track_Histogram.Name = "Track_Histogram"
        Me.Track_Histogram.Size = New System.Drawing.Size(318, 45)
        Me.Track_Histogram.TabIndex = 9
        Me.Track_Histogram.TickFrequency = 10
        Me.Track_Histogram.Value = -50
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(289, 204)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(58, 14)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "[darker]"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(144, 204)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 14)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "[neutral]"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(8, 204)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 14)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "[brighter]"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(8, 132)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(159, 14)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Gamma correction: [0.5]"
        '
        'btnContrast
        '
        Me.btnContrast.Enabled = False
        Me.btnContrast.Location = New System.Drawing.Point(418, 35)
        Me.btnContrast.Name = "btnContrast"
        Me.btnContrast.Size = New System.Drawing.Size(91, 30)
        Me.btnContrast.TabIndex = 4
        Me.btnContrast.Text = "Test"
        Me.btnContrast.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(289, 95)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 14)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "[brighter]"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(144, 95)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 14)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "[neutral]"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 95)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 14)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "[darker]"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(220, 14)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Histogram stretch correction: [12]"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox10)
        Me.TabPage2.Controls.Add(Me.cmbSplitMode)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.GroupBox9)
        Me.TabPage2.Controls.Add(Me.GroupBox8)
        Me.TabPage2.Controls.Add(Me.GroupBox7)
        Me.TabPage2.Controls.Add(Me.GroupBox6)
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(768, 406)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "View"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.chkWithImage)
        Me.GroupBox10.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(278, 289)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(200, 109)
        Me.GroupBox10.TabIndex = 7
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Miscellaneous"
        '
        'chkWithImage
        '
        Me.chkWithImage.AutoSize = True
        Me.chkWithImage.Location = New System.Drawing.Point(11, 26)
        Me.chkWithImage.Name = "chkWithImage"
        Me.chkWithImage.Size = New System.Drawing.Size(172, 18)
        Me.chkWithImage.TabIndex = 0
        Me.chkWithImage.Text = "Display age with image"
        Me.chkWithImage.UseVisualStyleBackColor = True
        '
        'cmbSplitMode
        '
        Me.cmbSplitMode.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSplitMode.FormattingEnabled = True
        Me.cmbSplitMode.Items.AddRange(New Object() {"Single", "2 Horizontal", "2 Vertical", "2 X 2 Grid", "3 X 3 Grid"})
        Me.cmbSplitMode.Location = New System.Drawing.Point(284, 244)
        Me.cmbSplitMode.Name = "cmbSplitMode"
        Me.cmbSplitMode.Size = New System.Drawing.Size(194, 22)
        Me.cmbSplitMode.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(282, 225)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 14)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Start-up split mode:"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.rbFiles)
        Me.GroupBox9.Controls.Add(Me.rbDoc)
        Me.GroupBox9.Controls.Add(Me.rbProfile)
        Me.GroupBox9.Controls.Add(Me.rbpanoramic)
        Me.GroupBox9.Controls.Add(Me.rbColors)
        Me.GroupBox9.Controls.Add(Me.rbXray)
        Me.GroupBox9.Controls.Add(Me.rbCompare)
        Me.GroupBox9.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(278, 19)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(200, 194)
        Me.GroupBox9.TabIndex = 4
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Startup-view"
        '
        'rbFiles
        '
        Me.rbFiles.AutoSize = True
        Me.rbFiles.Location = New System.Drawing.Point(11, 165)
        Me.rbFiles.Name = "rbFiles"
        Me.rbFiles.Size = New System.Drawing.Size(53, 18)
        Me.rbFiles.TabIndex = 6
        Me.rbFiles.TabStop = True
        Me.rbFiles.Text = "Files"
        Me.rbFiles.UseVisualStyleBackColor = True
        '
        'rbDoc
        '
        Me.rbDoc.AutoSize = True
        Me.rbDoc.Location = New System.Drawing.Point(11, 142)
        Me.rbDoc.Name = "rbDoc"
        Me.rbDoc.Size = New System.Drawing.Size(95, 18)
        Me.rbDoc.TabIndex = 5
        Me.rbDoc.Text = "Documents"
        Me.rbDoc.UseVisualStyleBackColor = True
        '
        'rbProfile
        '
        Me.rbProfile.AutoSize = True
        Me.rbProfile.Location = New System.Drawing.Point(11, 119)
        Me.rbProfile.Name = "rbProfile"
        Me.rbProfile.Size = New System.Drawing.Size(64, 18)
        Me.rbProfile.TabIndex = 4
        Me.rbProfile.Text = "Profile"
        Me.rbProfile.UseVisualStyleBackColor = True
        '
        'rbpanoramic
        '
        Me.rbpanoramic.AutoSize = True
        Me.rbpanoramic.Location = New System.Drawing.Point(11, 96)
        Me.rbpanoramic.Name = "rbpanoramic"
        Me.rbpanoramic.Size = New System.Drawing.Size(90, 18)
        Me.rbpanoramic.TabIndex = 3
        Me.rbpanoramic.Text = "Panoramic"
        Me.rbpanoramic.UseVisualStyleBackColor = True
        '
        'rbColors
        '
        Me.rbColors.AutoSize = True
        Me.rbColors.Location = New System.Drawing.Point(11, 73)
        Me.rbColors.Name = "rbColors"
        Me.rbColors.Size = New System.Drawing.Size(65, 18)
        Me.rbColors.TabIndex = 2
        Me.rbColors.Text = "Colors"
        Me.rbColors.UseVisualStyleBackColor = True
        '
        'rbXray
        '
        Me.rbXray.AutoSize = True
        Me.rbXray.Location = New System.Drawing.Point(11, 51)
        Me.rbXray.Name = "rbXray"
        Me.rbXray.Size = New System.Drawing.Size(67, 18)
        Me.rbXray.TabIndex = 1
        Me.rbXray.Text = "X.Rays"
        Me.rbXray.UseVisualStyleBackColor = True
        '
        'rbCompare
        '
        Me.rbCompare.AutoSize = True
        Me.rbCompare.Checked = True
        Me.rbCompare.Location = New System.Drawing.Point(11, 29)
        Me.rbCompare.Name = "rbCompare"
        Me.rbCompare.Size = New System.Drawing.Size(82, 18)
        Me.rbCompare.TabIndex = 0
        Me.rbCompare.TabStop = True
        Me.rbCompare.Text = "Compare"
        Me.rbCompare.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.chkPositions2)
        Me.GroupBox8.Controls.Add(Me.chkImageNotes2)
        Me.GroupBox8.Controls.Add(Me.chkCreationDate2)
        Me.GroupBox8.Controls.Add(Me.chkImageid2)
        Me.GroupBox8.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(17, 267)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(233, 112)
        Me.GroupBox8.TabIndex = 3
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Tooth status image caption"
        '
        'chkPositions2
        '
        Me.chkPositions2.AutoSize = True
        Me.chkPositions2.Location = New System.Drawing.Point(11, 82)
        Me.chkPositions2.Name = "chkPositions2"
        Me.chkPositions2.Size = New System.Drawing.Size(123, 18)
        Me.chkPositions2.TabIndex = 3
        Me.chkPositions2.Text = "Tooth positions"
        Me.chkPositions2.UseVisualStyleBackColor = True
        '
        'chkImageNotes2
        '
        Me.chkImageNotes2.AutoSize = True
        Me.chkImageNotes2.Checked = True
        Me.chkImageNotes2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkImageNotes2.Location = New System.Drawing.Point(11, 63)
        Me.chkImageNotes2.Name = "chkImageNotes2"
        Me.chkImageNotes2.Size = New System.Drawing.Size(106, 18)
        Me.chkImageNotes2.TabIndex = 2
        Me.chkImageNotes2.Text = "Image notes"
        Me.chkImageNotes2.UseVisualStyleBackColor = True
        '
        'chkCreationDate2
        '
        Me.chkCreationDate2.AutoSize = True
        Me.chkCreationDate2.Checked = True
        Me.chkCreationDate2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCreationDate2.Location = New System.Drawing.Point(11, 45)
        Me.chkCreationDate2.Name = "chkCreationDate2"
        Me.chkCreationDate2.Size = New System.Drawing.Size(113, 18)
        Me.chkCreationDate2.TabIndex = 1
        Me.chkCreationDate2.Text = "Creation date"
        Me.chkCreationDate2.UseVisualStyleBackColor = True
        '
        'chkImageid2
        '
        Me.chkImageid2.AutoSize = True
        Me.chkImageid2.Checked = True
        Me.chkImageid2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkImageid2.Location = New System.Drawing.Point(11, 26)
        Me.chkImageid2.Name = "chkImageid2"
        Me.chkImageid2.Size = New System.Drawing.Size(85, 18)
        Me.chkImageid2.TabIndex = 0
        Me.chkImageid2.Text = "Image-ID"
        Me.chkImageid2.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.chkPositions1)
        Me.GroupBox7.Controls.Add(Me.chkImageNotes1)
        Me.GroupBox7.Controls.Add(Me.chkCreationDate1)
        Me.GroupBox7.Controls.Add(Me.chkImageID1)
        Me.GroupBox7.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(17, 153)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(233, 108)
        Me.GroupBox7.TabIndex = 2
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Caption for large images"
        '
        'chkPositions1
        '
        Me.chkPositions1.AutoSize = True
        Me.chkPositions1.Checked = True
        Me.chkPositions1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPositions1.Location = New System.Drawing.Point(8, 80)
        Me.chkPositions1.Name = "chkPositions1"
        Me.chkPositions1.Size = New System.Drawing.Size(123, 18)
        Me.chkPositions1.TabIndex = 3
        Me.chkPositions1.Text = "Tooth positions"
        Me.chkPositions1.UseVisualStyleBackColor = True
        '
        'chkImageNotes1
        '
        Me.chkImageNotes1.AutoSize = True
        Me.chkImageNotes1.Checked = True
        Me.chkImageNotes1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkImageNotes1.Location = New System.Drawing.Point(8, 61)
        Me.chkImageNotes1.Name = "chkImageNotes1"
        Me.chkImageNotes1.Size = New System.Drawing.Size(106, 18)
        Me.chkImageNotes1.TabIndex = 2
        Me.chkImageNotes1.Text = "Image notes"
        Me.chkImageNotes1.UseVisualStyleBackColor = True
        '
        'chkCreationDate1
        '
        Me.chkCreationDate1.AutoSize = True
        Me.chkCreationDate1.Checked = True
        Me.chkCreationDate1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCreationDate1.Location = New System.Drawing.Point(8, 42)
        Me.chkCreationDate1.Name = "chkCreationDate1"
        Me.chkCreationDate1.Size = New System.Drawing.Size(113, 18)
        Me.chkCreationDate1.TabIndex = 1
        Me.chkCreationDate1.Text = "Creation date"
        Me.chkCreationDate1.UseVisualStyleBackColor = True
        '
        'chkImageID1
        '
        Me.chkImageID1.AutoSize = True
        Me.chkImageID1.Checked = True
        Me.chkImageID1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkImageID1.Location = New System.Drawing.Point(8, 23)
        Me.chkImageID1.Name = "chkImageID1"
        Me.chkImageID1.Size = New System.Drawing.Size(85, 18)
        Me.chkImageID1.TabIndex = 0
        Me.chkImageID1.Text = "Image-ID"
        Me.chkImageID1.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.chkPositions)
        Me.GroupBox6.Controls.Add(Me.chkImageNotes)
        Me.GroupBox6.Controls.Add(Me.chkCreationDate)
        Me.GroupBox6.Controls.Add(Me.chkImageid)
        Me.GroupBox6.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(17, 20)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(233, 116)
        Me.GroupBox6.TabIndex = 1
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Caption for thumbnails"
        '
        'chkPositions
        '
        Me.chkPositions.AutoSize = True
        Me.chkPositions.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.chkPositions.Location = New System.Drawing.Point(11, 86)
        Me.chkPositions.Name = "chkPositions"
        Me.chkPositions.Size = New System.Drawing.Size(129, 19)
        Me.chkPositions.TabIndex = 3
        Me.chkPositions.Text = "Tooth positions"
        Me.chkPositions.UseVisualStyleBackColor = True
        '
        'chkImageNotes
        '
        Me.chkImageNotes.AutoSize = True
        Me.chkImageNotes.Checked = True
        Me.chkImageNotes.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkImageNotes.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.chkImageNotes.Location = New System.Drawing.Point(11, 66)
        Me.chkImageNotes.Name = "chkImageNotes"
        Me.chkImageNotes.Size = New System.Drawing.Size(112, 19)
        Me.chkImageNotes.TabIndex = 2
        Me.chkImageNotes.Text = "Image notes"
        Me.chkImageNotes.UseVisualStyleBackColor = True
        '
        'chkCreationDate
        '
        Me.chkCreationDate.AutoSize = True
        Me.chkCreationDate.Checked = True
        Me.chkCreationDate.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCreationDate.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.chkCreationDate.Location = New System.Drawing.Point(11, 45)
        Me.chkCreationDate.Name = "chkCreationDate"
        Me.chkCreationDate.Size = New System.Drawing.Size(119, 19)
        Me.chkCreationDate.TabIndex = 1
        Me.chkCreationDate.Text = "Creation date"
        Me.chkCreationDate.UseVisualStyleBackColor = True
        '
        'chkImageid
        '
        Me.chkImageid.AutoSize = True
        Me.chkImageid.Checked = True
        Me.chkImageid.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkImageid.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.chkImageid.Location = New System.Drawing.Point(11, 25)
        Me.chkImageid.Name = "chkImageid"
        Me.chkImageid.Size = New System.Drawing.Size(91, 19)
        Me.chkImageid.TabIndex = 0
        Me.chkImageid.Text = "Image-ID"
        Me.chkImageid.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(776, 433)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.chkmultiple)
        Me.TabPage1.Controls.Add(Me.chkReopen)
        Me.TabPage1.Controls.Add(Me.cmbMonitor)
        Me.TabPage1.Controls.Add(Me.cmbLanguage)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(768, 406)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "General"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtComputerName)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Location = New System.Drawing.Point(271, 134)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(335, 66)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Workplace"
        '
        'txtComputerName
        '
        Me.txtComputerName.BackColor = System.Drawing.SystemColors.Info
        Me.txtComputerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtComputerName.Location = New System.Drawing.Point(151, 19)
        Me.txtComputerName.Name = "txtComputerName"
        Me.txtComputerName.Size = New System.Drawing.Size(178, 22)
        Me.txtComputerName.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(117, 14)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Workplace name:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkOpenDentist)
        Me.GroupBox2.Controls.Add(Me.chkadmnID)
        Me.GroupBox2.Location = New System.Drawing.Point(25, 329)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(278, 71)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Patient list"
        '
        'chkOpenDentist
        '
        Me.chkOpenDentist.AutoSize = True
        Me.chkOpenDentist.Location = New System.Drawing.Point(13, 46)
        Me.chkOpenDentist.Name = "chkOpenDentist"
        Me.chkOpenDentist.Size = New System.Drawing.Size(253, 18)
        Me.chkOpenDentist.TabIndex = 1
        Me.chkOpenDentist.Text = "Patient selection also opens Dentist"
        Me.chkOpenDentist.UseVisualStyleBackColor = True
        '
        'chkadmnID
        '
        Me.chkadmnID.AutoSize = True
        Me.chkadmnID.Location = New System.Drawing.Point(13, 23)
        Me.chkadmnID.Name = "chkadmnID"
        Me.chkadmnID.Size = New System.Drawing.Size(253, 18)
        Me.chkadmnID.TabIndex = 0
        Me.chkadmnID.Text = "Display patient Adm-id in patient list"
        Me.chkadmnID.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtLabel)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.chkSSNNo)
        Me.GroupBox1.Controls.Add(Me.chkOrderNo)
        Me.GroupBox1.Controls.Add(Me.chkptName)
        Me.GroupBox1.Controls.Add(Me.chkPtID)
        Me.GroupBox1.Controls.Add(Me.chkDentist)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 133)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(233, 191)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Text in main window"
        '
        'txtLabel
        '
        Me.txtLabel.Location = New System.Drawing.Point(14, 158)
        Me.txtLabel.Name = "txtLabel"
        Me.txtLabel.Size = New System.Drawing.Size(148, 22)
        Me.txtLabel.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 14)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Label:"
        '
        'chkSSNNo
        '
        Me.chkSSNNo.AutoSize = True
        Me.chkSSNNo.Location = New System.Drawing.Point(14, 113)
        Me.chkSSNNo.Name = "chkSSNNo"
        Me.chkSSNNo.Size = New System.Drawing.Size(152, 18)
        Me.chkSSNNo.TabIndex = 4
        Me.chkSSNNo.Text = "Display SSN number"
        Me.chkSSNNo.UseVisualStyleBackColor = True
        '
        'chkOrderNo
        '
        Me.chkOrderNo.AutoSize = True
        Me.chkOrderNo.Location = New System.Drawing.Point(14, 90)
        Me.chkOrderNo.Name = "chkOrderNo"
        Me.chkOrderNo.Size = New System.Drawing.Size(163, 18)
        Me.chkOrderNo.TabIndex = 3
        Me.chkOrderNo.Text = "Display Order number"
        Me.chkOrderNo.UseVisualStyleBackColor = True
        '
        'chkptName
        '
        Me.chkptName.AutoSize = True
        Me.chkptName.Location = New System.Drawing.Point(14, 67)
        Me.chkptName.Name = "chkptName"
        Me.chkptName.Size = New System.Drawing.Size(159, 18)
        Me.chkptName.TabIndex = 2
        Me.chkptName.Text = "Display Patient name"
        Me.chkptName.UseVisualStyleBackColor = True
        '
        'chkPtID
        '
        Me.chkPtID.AutoSize = True
        Me.chkPtID.Location = New System.Drawing.Point(14, 44)
        Me.chkPtID.Name = "chkPtID"
        Me.chkPtID.Size = New System.Drawing.Size(139, 18)
        Me.chkPtID.TabIndex = 1
        Me.chkPtID.Text = "Display Patient-ID"
        Me.chkPtID.UseVisualStyleBackColor = True
        '
        'chkDentist
        '
        Me.chkDentist.AutoSize = True
        Me.chkDentist.Location = New System.Drawing.Point(14, 21)
        Me.chkDentist.Name = "chkDentist"
        Me.chkDentist.Size = New System.Drawing.Size(158, 18)
        Me.chkDentist.TabIndex = 0
        Me.chkDentist.Text = "Display dentist name"
        Me.chkDentist.UseVisualStyleBackColor = True
        '
        'chkmultiple
        '
        Me.chkmultiple.AutoSize = True
        Me.chkmultiple.Location = New System.Drawing.Point(25, 110)
        Me.chkmultiple.Name = "chkmultiple"
        Me.chkmultiple.Size = New System.Drawing.Size(233, 18)
        Me.chkmultiple.TabIndex = 5
        Me.chkmultiple.Text = "Allow multiple program instances"
        Me.chkmultiple.UseVisualStyleBackColor = True
        '
        'chkReopen
        '
        Me.chkReopen.AutoSize = True
        Me.chkReopen.Location = New System.Drawing.Point(25, 88)
        Me.chkReopen.Name = "chkReopen"
        Me.chkReopen.Size = New System.Drawing.Size(278, 18)
        Me.chkReopen.TabIndex = 4
        Me.chkReopen.Text = "Reopen images when opening a patient"
        Me.chkReopen.UseVisualStyleBackColor = True
        '
        'cmbMonitor
        '
        Me.cmbMonitor.FormattingEnabled = True
        Me.cmbMonitor.Items.AddRange(New Object() {"Default", "1"})
        Me.cmbMonitor.Location = New System.Drawing.Point(165, 46)
        Me.cmbMonitor.Name = "cmbMonitor"
        Me.cmbMonitor.Size = New System.Drawing.Size(121, 22)
        Me.cmbMonitor.TabIndex = 3
        '
        'cmbLanguage
        '
        Me.cmbLanguage.FormattingEnabled = True
        Me.cmbLanguage.Items.AddRange(New Object() {"English"})
        Me.cmbLanguage.Location = New System.Drawing.Point(164, 18)
        Me.cmbLanguage.Name = "cmbLanguage"
        Me.cmbLanguage.Size = New System.Drawing.Size(202, 22)
        Me.cmbLanguage.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(36, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 14)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Start-up monitor:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(36, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Language:"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.btnD)
        Me.TabPage4.Controls.Add(Me.btnC)
        Me.TabPage4.Controls.Add(Me.btnB)
        Me.TabPage4.Controls.Add(Me.btnA)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.Label26)
        Me.TabPage4.Controls.Add(Me.Label25)
        Me.TabPage4.Controls.Add(Me.btnResetDefault)
        Me.TabPage4.Controls.Add(Me.chkAutoUpdate)
        Me.TabPage4.Controls.Add(Me.btnResetFilter)
        Me.TabPage4.Controls.Add(Me.btnTest)
        Me.TabPage4.Controls.Add(Me.Label24)
        Me.TabPage4.Controls.Add(Me.trkThreshold)
        Me.TabPage4.Controls.Add(Me.trkAmount)
        Me.TabPage4.Controls.Add(Me.Label23)
        Me.TabPage4.Controls.Add(Me.trkPixel)
        Me.TabPage4.Controls.Add(Me.Label21)
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(768, 406)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Super Filter"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'btnD
        '
        Me.btnD.Location = New System.Drawing.Point(123, 35)
        Me.btnD.Name = "btnD"
        Me.btnD.Size = New System.Drawing.Size(34, 31)
        Me.btnD.TabIndex = 49
        Me.btnD.Text = "D"
        Me.btnD.UseVisualStyleBackColor = True
        '
        'btnC
        '
        Me.btnC.Location = New System.Drawing.Point(88, 35)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(34, 31)
        Me.btnC.TabIndex = 48
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'btnB
        '
        Me.btnB.Location = New System.Drawing.Point(53, 35)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(34, 31)
        Me.btnB.TabIndex = 47
        Me.btnB.Text = "B"
        Me.btnB.UseVisualStyleBackColor = True
        '
        'btnA
        '
        Me.btnA.Location = New System.Drawing.Point(18, 35)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(34, 31)
        Me.btnA.TabIndex = 46
        Me.btnA.Text = "A"
        Me.btnA.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(407, 206)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(25, 14)
        Me.Label27.TabIndex = 45
        Me.Label27.Text = "[0]"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(407, 159)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(46, 14)
        Me.Label26.TabIndex = 44
        Me.Label26.Text = "[20%]"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(407, 107)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(45, 14)
        Me.Label25.TabIndex = 43
        Me.Label25.Text = "[1,10]"
        '
        'btnResetDefault
        '
        Me.btnResetDefault.Location = New System.Drawing.Point(151, 331)
        Me.btnResetDefault.Name = "btnResetDefault"
        Me.btnResetDefault.Size = New System.Drawing.Size(250, 23)
        Me.btnResetDefault.TabIndex = 39
        Me.btnResetDefault.Text = "Reset filter to default"
        Me.btnResetDefault.UseVisualStyleBackColor = True
        '
        'chkAutoUpdate
        '
        Me.chkAutoUpdate.AutoSize = True
        Me.chkAutoUpdate.Location = New System.Drawing.Point(151, 280)
        Me.chkAutoUpdate.Name = "chkAutoUpdate"
        Me.chkAutoUpdate.Size = New System.Drawing.Size(148, 18)
        Me.chkAutoUpdate.TabIndex = 38
        Me.chkAutoUpdate.Text = "Automatic updating"
        Me.chkAutoUpdate.UseVisualStyleBackColor = True
        '
        'btnResetFilter
        '
        Me.btnResetFilter.Location = New System.Drawing.Point(291, 251)
        Me.btnResetFilter.Name = "btnResetFilter"
        Me.btnResetFilter.Size = New System.Drawing.Size(110, 23)
        Me.btnResetFilter.TabIndex = 37
        Me.btnResetFilter.Text = "Reset"
        Me.btnResetFilter.UseVisualStyleBackColor = True
        '
        'btnTest
        '
        Me.btnTest.Location = New System.Drawing.Point(151, 251)
        Me.btnTest.Name = "btnTest"
        Me.btnTest.Size = New System.Drawing.Size(104, 23)
        Me.btnTest.TabIndex = 36
        Me.btnTest.Text = "Test"
        Me.btnTest.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(53, 206)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(74, 14)
        Me.Label24.TabIndex = 35
        Me.Label24.Text = "Threshold:"
        '
        'trkThreshold
        '
        Me.trkThreshold.Location = New System.Drawing.Point(151, 195)
        Me.trkThreshold.Name = "trkThreshold"
        Me.trkThreshold.Size = New System.Drawing.Size(250, 45)
        Me.trkThreshold.TabIndex = 34
        '
        'trkAmount
        '
        Me.trkAmount.Location = New System.Drawing.Point(151, 144)
        Me.trkAmount.Name = "trkAmount"
        Me.trkAmount.Size = New System.Drawing.Size(250, 45)
        Me.trkAmount.TabIndex = 33
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(61, 159)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(60, 14)
        Me.Label23.TabIndex = 32
        Me.Label23.Text = "Amount:"
        '
        'trkPixel
        '
        Me.trkPixel.Location = New System.Drawing.Point(151, 94)
        Me.trkPixel.Maximum = 1
        Me.trkPixel.Name = "trkPixel"
        Me.trkPixel.Size = New System.Drawing.Size(250, 45)
        Me.trkPixel.TabIndex = 31
        Me.trkPixel.TickFrequency = 5
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(61, 107)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(70, 14)
        Me.Label21.TabIndex = 30
        Me.Label21.Text = "Pixel size:"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox14)
        Me.TabPage5.Controls.Add(Me.GroupBox13)
        Me.TabPage5.Location = New System.Drawing.Point(4, 23)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(768, 406)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Color"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.outside_edge)
        Me.GroupBox14.Controls.Add(Me.Label22)
        Me.GroupBox14.Location = New System.Drawing.Point(44, 228)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(291, 84)
        Me.GroupBox14.TabIndex = 7
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Image Colors"
        '
        'outside_edge
        '
        Me.outside_edge.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.outside_edge.Location = New System.Drawing.Point(149, 27)
        Me.outside_edge.Name = "outside_edge"
        Me.outside_edge.Size = New System.Drawing.Size(100, 28)
        Me.outside_edge.TabIndex = 0
        Me.outside_edge.TabStop = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(33, 34)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(92, 14)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "Outside edge"
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.Normal)
        Me.GroupBox13.Controls.Add(Me.Label20)
        Me.GroupBox13.Controls.Add(Me.Label18)
        Me.GroupBox13.Controls.Add(Me.Active)
        Me.GroupBox13.Controls.Add(Me.Label19)
        Me.GroupBox13.Controls.Add(Me.Selected)
        Me.GroupBox13.Location = New System.Drawing.Point(44, 44)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(291, 161)
        Me.GroupBox13.TabIndex = 6
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Colors for Measurements"
        '
        'Normal
        '
        Me.Normal.BackColor = System.Drawing.Color.Green
        Me.Normal.Location = New System.Drawing.Point(149, 30)
        Me.Normal.Name = "Normal"
        Me.Normal.Size = New System.Drawing.Size(100, 27)
        Me.Normal.TabIndex = 0
        Me.Normal.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(33, 126)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(44, 14)
        Me.Label20.TabIndex = 5
        Me.Label20.Text = "Active"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(33, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(51, 14)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "Normal"
        '
        'Active
        '
        Me.Active.BackColor = System.Drawing.Color.Red
        Me.Active.Location = New System.Drawing.Point(149, 119)
        Me.Active.Name = "Active"
        Me.Active.Size = New System.Drawing.Size(100, 27)
        Me.Active.TabIndex = 2
        Me.Active.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(33, 77)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(61, 14)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "Selected"
        '
        'Selected
        '
        Me.Selected.BackColor = System.Drawing.Color.Magenta
        Me.Selected.Location = New System.Drawing.Point(149, 72)
        Me.Selected.Name = "Selected"
        Me.Selected.Size = New System.Drawing.Size(100, 27)
        Me.Selected.TabIndex = 1
        Me.Selected.TabStop = False
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.btnReady_Stop)
        Me.TabPage6.Controls.Add(Me.btnLoadPhoto_Stop)
        Me.TabPage6.Controls.Add(Me.btnOpenPhoto_Stop)
        Me.TabPage6.Controls.Add(Me.btnOpenNewPt_Stop)
        Me.TabPage6.Controls.Add(Me.btnOpenPt_Stop)
        Me.TabPage6.Controls.Add(Me.btnStartup_Stop)
        Me.TabPage6.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.TabPage6.Controls.Add(Me.btnReady_Play)
        Me.TabPage6.Controls.Add(Me.btnReady)
        Me.TabPage6.Controls.Add(Me.btnLoadPhoto_Play)
        Me.TabPage6.Controls.Add(Me.btnLoadPhoto)
        Me.TabPage6.Controls.Add(Me.btnOpenPhoto_Play)
        Me.TabPage6.Controls.Add(Me.btnOpenPhoto)
        Me.TabPage6.Controls.Add(Me.btnOpenNewPt_Play)
        Me.TabPage6.Controls.Add(Me.btnOpenNewPt)
        Me.TabPage6.Controls.Add(Me.btnOpenPt_Play)
        Me.TabPage6.Controls.Add(Me.btnOpenPt)
        Me.TabPage6.Controls.Add(Me.btnStartup_Play)
        Me.TabPage6.Controls.Add(Me.btnStartup)
        Me.TabPage6.Controls.Add(Me.txtExpose)
        Me.TabPage6.Controls.Add(Me.txtLoadPhoto)
        Me.TabPage6.Controls.Add(Me.txtNewPhoto)
        Me.TabPage6.Controls.Add(Me.txtNewPatient)
        Me.TabPage6.Controls.Add(Me.txtSoundOpenPt)
        Me.TabPage6.Controls.Add(Me.Label33)
        Me.TabPage6.Controls.Add(Me.Label32)
        Me.TabPage6.Controls.Add(Me.Label31)
        Me.TabPage6.Controls.Add(Me.Label30)
        Me.TabPage6.Controls.Add(Me.Label29)
        Me.TabPage6.Controls.Add(Me.txtSound_StartUp)
        Me.TabPage6.Controls.Add(Me.Label28)
        Me.TabPage6.Controls.Add(Me.CheckBox11)
        Me.TabPage6.Location = New System.Drawing.Point(4, 23)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(768, 406)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Sound"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'btnReady_Stop
        '
        Me.btnReady_Stop.Location = New System.Drawing.Point(460, 241)
        Me.btnReady_Stop.Name = "btnReady_Stop"
        Me.btnReady_Stop.Size = New System.Drawing.Size(44, 31)
        Me.btnReady_Stop.TabIndex = 31
        Me.btnReady_Stop.Text = "Stop"
        Me.btnReady_Stop.UseVisualStyleBackColor = True
        Me.btnReady_Stop.Visible = False
        '
        'btnLoadPhoto_Stop
        '
        Me.btnLoadPhoto_Stop.Location = New System.Drawing.Point(460, 204)
        Me.btnLoadPhoto_Stop.Name = "btnLoadPhoto_Stop"
        Me.btnLoadPhoto_Stop.Size = New System.Drawing.Size(44, 31)
        Me.btnLoadPhoto_Stop.TabIndex = 30
        Me.btnLoadPhoto_Stop.Text = "Stop"
        Me.btnLoadPhoto_Stop.UseVisualStyleBackColor = True
        Me.btnLoadPhoto_Stop.Visible = False
        '
        'btnOpenPhoto_Stop
        '
        Me.btnOpenPhoto_Stop.Location = New System.Drawing.Point(460, 163)
        Me.btnOpenPhoto_Stop.Name = "btnOpenPhoto_Stop"
        Me.btnOpenPhoto_Stop.Size = New System.Drawing.Size(44, 31)
        Me.btnOpenPhoto_Stop.TabIndex = 29
        Me.btnOpenPhoto_Stop.Text = "Stop"
        Me.btnOpenPhoto_Stop.UseVisualStyleBackColor = True
        Me.btnOpenPhoto_Stop.Visible = False
        '
        'btnOpenNewPt_Stop
        '
        Me.btnOpenNewPt_Stop.Location = New System.Drawing.Point(460, 126)
        Me.btnOpenNewPt_Stop.Name = "btnOpenNewPt_Stop"
        Me.btnOpenNewPt_Stop.Size = New System.Drawing.Size(44, 31)
        Me.btnOpenNewPt_Stop.TabIndex = 28
        Me.btnOpenNewPt_Stop.Text = "Stop"
        Me.btnOpenNewPt_Stop.UseVisualStyleBackColor = True
        Me.btnOpenNewPt_Stop.Visible = False
        '
        'btnOpenPt_Stop
        '
        Me.btnOpenPt_Stop.Location = New System.Drawing.Point(460, 90)
        Me.btnOpenPt_Stop.Name = "btnOpenPt_Stop"
        Me.btnOpenPt_Stop.Size = New System.Drawing.Size(44, 31)
        Me.btnOpenPt_Stop.TabIndex = 27
        Me.btnOpenPt_Stop.Text = "Stop"
        Me.btnOpenPt_Stop.UseVisualStyleBackColor = True
        Me.btnOpenPt_Stop.Visible = False
        '
        'btnStartup_Stop
        '
        Me.btnStartup_Stop.Location = New System.Drawing.Point(460, 49)
        Me.btnStartup_Stop.Name = "btnStartup_Stop"
        Me.btnStartup_Stop.Size = New System.Drawing.Size(44, 31)
        Me.btnStartup_Stop.TabIndex = 26
        Me.btnStartup_Stop.Text = "Stop"
        Me.btnStartup_Stop.UseVisualStyleBackColor = True
        Me.btnStartup_Stop.Visible = False
        '
        'btnReady_Play
        '
        Me.btnReady_Play.Location = New System.Drawing.Point(460, 240)
        Me.btnReady_Play.Name = "btnReady_Play"
        Me.btnReady_Play.Size = New System.Drawing.Size(41, 31)
        Me.btnReady_Play.TabIndex = 24
        Me.btnReady_Play.Text = "Play"
        Me.btnReady_Play.UseVisualStyleBackColor = True
        '
        'btnReady
        '
        Me.btnReady.BackgroundImage = CType(resources.GetObject("btnReady.BackgroundImage"), System.Drawing.Image)
        Me.btnReady.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnReady.Location = New System.Drawing.Point(413, 239)
        Me.btnReady.Name = "btnReady"
        Me.btnReady.Size = New System.Drawing.Size(41, 31)
        Me.btnReady.TabIndex = 23
        Me.btnReady.UseVisualStyleBackColor = True
        '
        'btnLoadPhoto_Play
        '
        Me.btnLoadPhoto_Play.Location = New System.Drawing.Point(460, 204)
        Me.btnLoadPhoto_Play.Name = "btnLoadPhoto_Play"
        Me.btnLoadPhoto_Play.Size = New System.Drawing.Size(41, 31)
        Me.btnLoadPhoto_Play.TabIndex = 22
        Me.btnLoadPhoto_Play.Text = "Play"
        Me.btnLoadPhoto_Play.UseVisualStyleBackColor = True
        '
        'btnLoadPhoto
        '
        Me.btnLoadPhoto.BackgroundImage = CType(resources.GetObject("btnLoadPhoto.BackgroundImage"), System.Drawing.Image)
        Me.btnLoadPhoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnLoadPhoto.Location = New System.Drawing.Point(414, 203)
        Me.btnLoadPhoto.Name = "btnLoadPhoto"
        Me.btnLoadPhoto.Size = New System.Drawing.Size(41, 31)
        Me.btnLoadPhoto.TabIndex = 21
        Me.btnLoadPhoto.UseVisualStyleBackColor = True
        '
        'btnOpenPhoto_Play
        '
        Me.btnOpenPhoto_Play.Location = New System.Drawing.Point(460, 164)
        Me.btnOpenPhoto_Play.Name = "btnOpenPhoto_Play"
        Me.btnOpenPhoto_Play.Size = New System.Drawing.Size(41, 31)
        Me.btnOpenPhoto_Play.TabIndex = 20
        Me.btnOpenPhoto_Play.Text = "Play"
        Me.btnOpenPhoto_Play.UseVisualStyleBackColor = True
        '
        'btnOpenPhoto
        '
        Me.btnOpenPhoto.BackgroundImage = CType(resources.GetObject("btnOpenPhoto.BackgroundImage"), System.Drawing.Image)
        Me.btnOpenPhoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnOpenPhoto.Location = New System.Drawing.Point(414, 163)
        Me.btnOpenPhoto.Name = "btnOpenPhoto"
        Me.btnOpenPhoto.Size = New System.Drawing.Size(41, 31)
        Me.btnOpenPhoto.TabIndex = 19
        Me.btnOpenPhoto.UseVisualStyleBackColor = True
        '
        'btnOpenNewPt_Play
        '
        Me.btnOpenNewPt_Play.Location = New System.Drawing.Point(460, 127)
        Me.btnOpenNewPt_Play.Name = "btnOpenNewPt_Play"
        Me.btnOpenNewPt_Play.Size = New System.Drawing.Size(41, 31)
        Me.btnOpenNewPt_Play.TabIndex = 18
        Me.btnOpenNewPt_Play.Text = "Play"
        Me.btnOpenNewPt_Play.UseVisualStyleBackColor = True
        '
        'btnOpenNewPt
        '
        Me.btnOpenNewPt.BackgroundImage = CType(resources.GetObject("btnOpenNewPt.BackgroundImage"), System.Drawing.Image)
        Me.btnOpenNewPt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnOpenNewPt.Location = New System.Drawing.Point(413, 126)
        Me.btnOpenNewPt.Name = "btnOpenNewPt"
        Me.btnOpenNewPt.Size = New System.Drawing.Size(41, 31)
        Me.btnOpenNewPt.TabIndex = 17
        Me.btnOpenNewPt.UseVisualStyleBackColor = True
        '
        'btnOpenPt_Play
        '
        Me.btnOpenPt_Play.Location = New System.Drawing.Point(460, 90)
        Me.btnOpenPt_Play.Name = "btnOpenPt_Play"
        Me.btnOpenPt_Play.Size = New System.Drawing.Size(41, 31)
        Me.btnOpenPt_Play.TabIndex = 16
        Me.btnOpenPt_Play.Text = "Play"
        Me.btnOpenPt_Play.UseVisualStyleBackColor = True
        '
        'btnOpenPt
        '
        Me.btnOpenPt.BackgroundImage = CType(resources.GetObject("btnOpenPt.BackgroundImage"), System.Drawing.Image)
        Me.btnOpenPt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnOpenPt.Location = New System.Drawing.Point(414, 90)
        Me.btnOpenPt.Name = "btnOpenPt"
        Me.btnOpenPt.Size = New System.Drawing.Size(41, 31)
        Me.btnOpenPt.TabIndex = 15
        Me.btnOpenPt.UseVisualStyleBackColor = True
        '
        'btnStartup_Play
        '
        Me.btnStartup_Play.Location = New System.Drawing.Point(460, 49)
        Me.btnStartup_Play.Name = "btnStartup_Play"
        Me.btnStartup_Play.Size = New System.Drawing.Size(41, 31)
        Me.btnStartup_Play.TabIndex = 14
        Me.btnStartup_Play.Text = "Play"
        Me.btnStartup_Play.UseVisualStyleBackColor = True
        '
        'btnStartup
        '
        Me.btnStartup.BackgroundImage = CType(resources.GetObject("btnStartup.BackgroundImage"), System.Drawing.Image)
        Me.btnStartup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnStartup.Location = New System.Drawing.Point(413, 49)
        Me.btnStartup.Name = "btnStartup"
        Me.btnStartup.Size = New System.Drawing.Size(41, 31)
        Me.btnStartup.TabIndex = 13
        Me.btnStartup.UseVisualStyleBackColor = True
        '
        'txtExpose
        '
        Me.txtExpose.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtExpose.Location = New System.Drawing.Point(166, 245)
        Me.txtExpose.Name = "txtExpose"
        Me.txtExpose.Size = New System.Drawing.Size(242, 22)
        Me.txtExpose.TabIndex = 12
        '
        'txtLoadPhoto
        '
        Me.txtLoadPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLoadPhoto.Location = New System.Drawing.Point(166, 209)
        Me.txtLoadPhoto.Name = "txtLoadPhoto"
        Me.txtLoadPhoto.Size = New System.Drawing.Size(242, 22)
        Me.txtLoadPhoto.TabIndex = 11
        '
        'txtNewPhoto
        '
        Me.txtNewPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewPhoto.Location = New System.Drawing.Point(165, 169)
        Me.txtNewPhoto.Name = "txtNewPhoto"
        Me.txtNewPhoto.Size = New System.Drawing.Size(243, 22)
        Me.txtNewPhoto.TabIndex = 10
        '
        'txtNewPatient
        '
        Me.txtNewPatient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNewPatient.Location = New System.Drawing.Point(165, 131)
        Me.txtNewPatient.Name = "txtNewPatient"
        Me.txtNewPatient.Size = New System.Drawing.Size(242, 22)
        Me.txtNewPatient.TabIndex = 9
        '
        'txtSoundOpenPt
        '
        Me.txtSoundOpenPt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSoundOpenPt.Location = New System.Drawing.Point(165, 94)
        Me.txtSoundOpenPt.Name = "txtSoundOpenPt"
        Me.txtSoundOpenPt.Size = New System.Drawing.Size(243, 22)
        Me.txtSoundOpenPt.TabIndex = 8
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(37, 247)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(118, 14)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "Ready to expose:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(37, 211)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(84, 14)
        Me.Label32.TabIndex = 6
        Me.Label32.Text = "Load photo:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(37, 173)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(81, 14)
        Me.Label31.TabIndex = 5
        Me.Label31.Text = "New photo:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(37, 134)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(89, 14)
        Me.Label30.TabIndex = 4
        Me.Label30.Text = "New patient:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(37, 95)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(95, 14)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "Open patient:"
        '
        'txtSound_StartUp
        '
        Me.txtSound_StartUp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSound_StartUp.Location = New System.Drawing.Point(165, 55)
        Me.txtSound_StartUp.Name = "txtSound_StartUp"
        Me.txtSound_StartUp.Size = New System.Drawing.Size(242, 22)
        Me.txtSound_StartUp.TabIndex = 2
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(37, 58)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(64, 14)
        Me.Label28.TabIndex = 1
        Me.Label28.Text = "Start-up:"
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(8, 8)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(86, 18)
        Me.CheckBox11.TabIndex = 0
        Me.CheckBox11.Text = "Sound on"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.dtpRegDate)
        Me.TabPage7.Controls.Add(Me.Label39)
        Me.TabPage7.Controls.Add(Me.chkLstModules)
        Me.TabPage7.Controls.Add(Me.btnFromDisk)
        Me.TabPage7.Controls.Add(Me.txtMaxUsers)
        Me.TabPage7.Controls.Add(Me.txtLicenseCode)
        Me.TabPage7.Controls.Add(Me.txtLicenseName)
        Me.TabPage7.Controls.Add(Me.Label37)
        Me.TabPage7.Controls.Add(Me.Label36)
        Me.TabPage7.Controls.Add(Me.Label35)
        Me.TabPage7.Controls.Add(Me.Label34)
        Me.TabPage7.Location = New System.Drawing.Point(4, 23)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(768, 406)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "License"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'dtpRegDate
        '
        Me.dtpRegDate.CalendarFont = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpRegDate.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpRegDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpRegDate.Location = New System.Drawing.Point(178, 131)
        Me.dtpRegDate.Name = "dtpRegDate"
        Me.dtpRegDate.Size = New System.Drawing.Size(140, 23)
        Me.dtpRegDate.TabIndex = 34
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(11, 173)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(64, 14)
        Me.Label39.TabIndex = 33
        Me.Label39.Text = "Modules:"
        '
        'chkLstModules
        '
        Me.chkLstModules.ColumnWidth = 200
        Me.chkLstModules.FormattingEnabled = True
        Me.chkLstModules.Items.AddRange(New Object() {"Multi database", "Laboratory version", "Waiting room", "Replication", "XO POS plugin", "CT-link", "Trial version", "X-ray Cygnus", "X-ray Dexis", "X-ray Digident", "X-ray Digora", "X-ray Durr VistaRay", "X-ray Durr VistaScan", "X-ray E2V", "X-ray RSV", "X-ray EVA", "X-ray Ewoo", "X-ray Fimet", "X-ray Gendex GxPicture", "X-ray Gendex CCD", "X-ray Gendex Denoptix", "X-ray Hamamatsu", "X-ray Instrumentarium", "X-ray Morita", "X-ray Owandy", "X-ray Planmeca", "X-ray Schick", "X-ray Sirona", "X-ray MPDx", "X-ray Acteon", "X-ray Suni", "X-ray Kodak/Trophy", "X-ray Vatech", "X-ray NewTom", "X-ray Leutron", "X-ray Remote", "X-ray MyRay"})
        Me.chkLstModules.Location = New System.Drawing.Point(14, 190)
        Me.chkLstModules.MultiColumn = True
        Me.chkLstModules.Name = "chkLstModules"
        Me.chkLstModules.Size = New System.Drawing.Size(634, 208)
        Me.chkLstModules.TabIndex = 32
        '
        'btnFromDisk
        '
        Me.btnFromDisk.Location = New System.Drawing.Point(335, 101)
        Me.btnFromDisk.Name = "btnFromDisk"
        Me.btnFromDisk.Size = New System.Drawing.Size(113, 23)
        Me.btnFromDisk.TabIndex = 8
        Me.btnFromDisk.Text = "Read from disk"
        Me.btnFromDisk.UseVisualStyleBackColor = True
        '
        'txtMaxUsers
        '
        Me.txtMaxUsers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMaxUsers.Location = New System.Drawing.Point(178, 101)
        Me.txtMaxUsers.Name = "txtMaxUsers"
        Me.txtMaxUsers.Size = New System.Drawing.Size(140, 22)
        Me.txtMaxUsers.TabIndex = 6
        '
        'txtLicenseCode
        '
        Me.txtLicenseCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLicenseCode.Location = New System.Drawing.Point(178, 74)
        Me.txtLicenseCode.Name = "txtLicenseCode"
        Me.txtLicenseCode.Size = New System.Drawing.Size(270, 22)
        Me.txtLicenseCode.TabIndex = 5
        '
        'txtLicenseName
        '
        Me.txtLicenseName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLicenseName.Location = New System.Drawing.Point(178, 44)
        Me.txtLicenseName.Name = "txtLicenseName"
        Me.txtLicenseName.Size = New System.Drawing.Size(270, 22)
        Me.txtLicenseName.TabIndex = 4
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(64, 131)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(108, 14)
        Me.Label37.TabIndex = 3
        Me.Label37.Text = "Expiration date:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(96, 101)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(76, 14)
        Me.Label36.TabIndex = 2
        Me.Label36.Text = "Max users:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(79, 74)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(93, 14)
        Me.Label35.TabIndex = 1
        Me.Label35.Text = "License code:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(74, 47)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(98, 14)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "License name:"
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(657, 133)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(94, 31)
        Me.btnHelp.TabIndex = 14
        Me.btnHelp.Text = "&Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(657, 85)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(94, 31)
        Me.btnCancel.TabIndex = 13
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOk
        '
        Me.btnOk.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOk.Location = New System.Drawing.Point(657, 39)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(94, 31)
        Me.btnOk.TabIndex = 12
        Me.btnOk.Text = "&Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(653, 247)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(66, 36)
        Me.AxWindowsMediaPlayer1.TabIndex = 25
        Me.AxWindowsMediaPlayer1.Visible = False
        '
        'frm_applicationSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 433)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frm_applicationSettings"
        Me.Text = "Application Settings"
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.Track_Smooth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.Track_Sharp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.Track_Gamma, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Track_Histogram, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.trkThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkPixel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        CType(Me.outside_edge, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        CType(Me.Normal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Active, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Selected, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents chkWithImage As System.Windows.Forms.CheckBox
    Friend WithEvents cmbSplitMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents rbFiles As System.Windows.Forms.RadioButton
    Friend WithEvents rbDoc As System.Windows.Forms.RadioButton
    Friend WithEvents rbProfile As System.Windows.Forms.RadioButton
    Friend WithEvents rbpanoramic As System.Windows.Forms.RadioButton
    Friend WithEvents rbColors As System.Windows.Forms.RadioButton
    Friend WithEvents rbXray As System.Windows.Forms.RadioButton
    Friend WithEvents rbCompare As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents chkPositions2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageNotes2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCreationDate2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageid2 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents chkPositions1 As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageNotes1 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCreationDate1 As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageID1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents chkPositions As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageNotes As System.Windows.Forms.CheckBox
    Friend WithEvents chkCreationDate As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageid As System.Windows.Forms.CheckBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents cmbMonitor As System.Windows.Forms.ComboBox
    Friend WithEvents cmbLanguage As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkOpenDentist As System.Windows.Forms.CheckBox
    Friend WithEvents chkadmnID As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtLabel As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents chkSSNNo As System.Windows.Forms.CheckBox
    Friend WithEvents chkOrderNo As System.Windows.Forms.CheckBox
    Friend WithEvents chkptName As System.Windows.Forms.CheckBox
    Friend WithEvents chkPtID As System.Windows.Forms.CheckBox
    Friend WithEvents chkDentist As System.Windows.Forms.CheckBox
    Friend WithEvents chkmultiple As System.Windows.Forms.CheckBox
    Friend WithEvents chkReopen As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnContrast As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSmoothing As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btnSharpness As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Track_Smooth As System.Windows.Forms.TrackBar
    Friend WithEvents Track_Sharp As System.Windows.Forms.TrackBar
    Friend WithEvents Track_Gamma As System.Windows.Forms.TrackBar
    Friend WithEvents Track_Histogram As System.Windows.Forms.TrackBar
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents txtComputerName As System.Windows.Forms.TextBox
    Friend WithEvents Normal As System.Windows.Forms.PictureBox
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents Active As System.Windows.Forms.PictureBox
    Friend WithEvents Selected As System.Windows.Forms.PictureBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents outside_edge As System.Windows.Forms.PictureBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents txtExpose As System.Windows.Forms.TextBox
    Friend WithEvents txtLoadPhoto As System.Windows.Forms.TextBox
    Friend WithEvents txtNewPhoto As System.Windows.Forms.TextBox
    Friend WithEvents txtNewPatient As System.Windows.Forms.TextBox
    Friend WithEvents txtSoundOpenPt As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtSound_StartUp As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents btnReady_Play As System.Windows.Forms.Button
    Friend WithEvents btnLoadPhoto_Play As System.Windows.Forms.Button
    Friend WithEvents btnOpenPhoto_Play As System.Windows.Forms.Button
    Friend WithEvents btnOpenNewPt_Play As System.Windows.Forms.Button
    Friend WithEvents btnOpenPt_Play As System.Windows.Forms.Button
    Friend WithEvents btnStartup_Play As System.Windows.Forms.Button
    Friend WithEvents btnFromDisk As System.Windows.Forms.Button
    Friend WithEvents txtMaxUsers As System.Windows.Forms.TextBox
    Friend WithEvents txtLicenseCode As System.Windows.Forms.TextBox
    Friend WithEvents txtLicenseName As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents chkLstModules As System.Windows.Forms.CheckedListBox
    Friend WithEvents btnReady As System.Windows.Forms.Button
    Friend WithEvents btnLoadPhoto As System.Windows.Forms.Button
    Friend WithEvents btnOpenPhoto As System.Windows.Forms.Button
    Friend WithEvents btnOpenNewPt As System.Windows.Forms.Button
    Friend WithEvents btnOpenPt As System.Windows.Forms.Button
    Friend WithEvents btnStartup As System.Windows.Forms.Button
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents btnD As System.Windows.Forms.Button
    Friend WithEvents btnC As System.Windows.Forms.Button
    Friend WithEvents btnB As System.Windows.Forms.Button
    Friend WithEvents btnA As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents btnResetDefault As System.Windows.Forms.Button
    Friend WithEvents chkAutoUpdate As System.Windows.Forms.CheckBox
    Friend WithEvents btnResetFilter As System.Windows.Forms.Button
    Friend WithEvents btnTest As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents trkThreshold As System.Windows.Forms.TrackBar
    Friend WithEvents trkAmount As System.Windows.Forms.TrackBar
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents trkPixel As System.Windows.Forms.TrackBar
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents dtpRegDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents ColorDialog2 As System.Windows.Forms.ColorDialog
    Friend WithEvents ColorDialog3 As System.Windows.Forms.ColorDialog
    Friend WithEvents ColorDialog4 As System.Windows.Forms.ColorDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents btnStartup_Stop As System.Windows.Forms.Button
    Friend WithEvents btnReady_Stop As System.Windows.Forms.Button
    Friend WithEvents btnLoadPhoto_Stop As System.Windows.Forms.Button
    Friend WithEvents btnOpenPhoto_Stop As System.Windows.Forms.Button
    Friend WithEvents btnOpenNewPt_Stop As System.Windows.Forms.Button
    Friend WithEvents btnOpenPt_Stop As System.Windows.Forms.Button
End Class
