﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_deviceSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.chkDigital_XRay = New System.Windows.Forms.CheckBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.btnFile_Open = New System.Windows.Forms.Button()
        Me.txtFile = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chkLogoImage = New System.Windows.Forms.CheckBox()
        Me.chkImageNotes = New System.Windows.Forms.CheckBox()
        Me.chkPatientNotes = New System.Windows.Forms.CheckBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.chkOpenClose_Inverted = New System.Windows.Forms.CheckBox()
        Me.chkOpenClose_Triggered = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rbOpenClose_Port4 = New System.Windows.Forms.RadioButton()
        Me.rbOpenClose_Port3 = New System.Windows.Forms.RadioButton()
        Me.rbOpenClose_Port2 = New System.Windows.Forms.RadioButton()
        Me.rbOpenClose_Port1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rbJoystickPortSave4 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPortSave3 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPortSave2 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPortSave1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbJoystickPortFreeze4 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPortFreeze3 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPortFreeze2 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPortFreeze1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbJoystickPort4 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPort3 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPort2 = New System.Windows.Forms.RadioButton()
        Me.rbJoystickPort1 = New System.Windows.Forms.RadioButton()
        Me.cmbJoystick_Device = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.chkRTS_State = New System.Windows.Forms.CheckBox()
        Me.chkDTR_State = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.rbRI = New System.Windows.Forms.RadioButton()
        Me.rbRLSD = New System.Windows.Forms.RadioButton()
        Me.rbDSR = New System.Windows.Forms.RadioButton()
        Me.rbCTS = New System.Windows.Forms.RadioButton()
        Me.txtCommParameters = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.chkSave_Freeze = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumUpD1 = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.chkPedal_Input = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumUpD = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbPedalType = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.btnDefaultScanner = New System.Windows.Forms.Button()
        Me.btnScanEdit = New System.Windows.Forms.Button()
        Me.btnScanDelete = New System.Windows.Forms.Button()
        Me.btnScanAdd = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.btnHotkeyBrowse = New System.Windows.Forms.Button()
        Me.txtHotkey = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.chkGlobal_Hotkey = New System.Windows.Forms.CheckBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.txtAxisWebcam_URL4 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtAxisWebcam_URL3 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtAxisWebcam_URL2 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtAxisWebcam_URL1 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.btnImgFile_Open = New System.Windows.Forms.Button()
        Me.txtImgFileName = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rbAxis_webcam = New System.Windows.Forms.RadioButton()
        Me.rbVidCatch = New System.Windows.Forms.RadioButton()
        Me.rbNone = New System.Windows.Forms.RadioButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.NumericUpD = New System.Windows.Forms.NumericUpDown()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.chkRecompress = New System.Windows.Forms.CheckBox()
        Me.btnCameraBrowse = New System.Windows.Forms.Button()
        Me.txtCameraName = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.chkAutoOpen_Import = New System.Windows.Forms.CheckBox()
        Me.chkAuto_Import = New System.Windows.Forms.CheckBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.btnImport = New System.Windows.Forms.Button()
        Me.btnDetect = New System.Windows.Forms.Button()
        Me.btnSettings_Edit = New System.Windows.Forms.Button()
        Me.btnSettings_Delete = New System.Windows.Forms.Button()
        Me.btnSettings_Add = New System.Windows.Forms.Button()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NumUpD1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumUpD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        CType(Me.NumericUpD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(784, 482)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.chkDigital_XRay)
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(776, 455)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "General"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'chkDigital_XRay
        '
        Me.chkDigital_XRay.AutoSize = True
        Me.chkDigital_XRay.Location = New System.Drawing.Point(8, 24)
        Me.chkDigital_XRay.Name = "chkDigital_XRay"
        Me.chkDigital_XRay.Size = New System.Drawing.Size(197, 18)
        Me.chkDigital_XRay.TabIndex = 0
        Me.chkDigital_XRay.Text = "Disable digital x-ray drivers"
        Me.chkDigital_XRay.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btnFile_Open)
        Me.TabPage2.Controls.Add(Me.txtFile)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.chkLogoImage)
        Me.TabPage2.Controls.Add(Me.chkImageNotes)
        Me.TabPage2.Controls.Add(Me.chkPatientNotes)
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(776, 455)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Printing"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btnFile_Open
        '
        Me.btnFile_Open.Location = New System.Drawing.Point(420, 133)
        Me.btnFile_Open.Name = "btnFile_Open"
        Me.btnFile_Open.Size = New System.Drawing.Size(36, 23)
        Me.btnFile_Open.TabIndex = 26
        Me.btnFile_Open.UseVisualStyleBackColor = True
        '
        'txtFile
        '
        Me.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFile.Location = New System.Drawing.Point(128, 134)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.Size = New System.Drawing.Size(286, 22)
        Me.txtFile.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(95, 138)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 14)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "File:"
        '
        'chkLogoImage
        '
        Me.chkLogoImage.AutoSize = True
        Me.chkLogoImage.Location = New System.Drawing.Point(34, 91)
        Me.chkLogoImage.Name = "chkLogoImage"
        Me.chkLogoImage.Size = New System.Drawing.Size(321, 18)
        Me.chkLogoImage.TabIndex = 23
        Me.chkLogoImage.Text = "Use logo image when printing on photo printer"
        Me.chkLogoImage.UseVisualStyleBackColor = True
        '
        'chkImageNotes
        '
        Me.chkImageNotes.AutoSize = True
        Me.chkImageNotes.Location = New System.Drawing.Point(34, 67)
        Me.chkImageNotes.Name = "chkImageNotes"
        Me.chkImageNotes.Size = New System.Drawing.Size(137, 18)
        Me.chkImageNotes.TabIndex = 22
        Me.chkImageNotes.Text = "Print image notes"
        Me.chkImageNotes.UseVisualStyleBackColor = True
        '
        'chkPatientNotes
        '
        Me.chkPatientNotes.AutoSize = True
        Me.chkPatientNotes.Location = New System.Drawing.Point(34, 43)
        Me.chkPatientNotes.Name = "chkPatientNotes"
        Me.chkPatientNotes.Size = New System.Drawing.Size(144, 18)
        Me.chkPatientNotes.TabIndex = 21
        Me.chkPatientNotes.Text = "Print patient notes"
        Me.chkPatientNotes.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.btnEdit)
        Me.TabPage3.Controls.Add(Me.btnDelete)
        Me.TabPage3.Controls.Add(Me.btnAdd)
        Me.TabPage3.Controls.Add(Me.DataGridView1)
        Me.TabPage3.Controls.Add(Me.Label2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 23)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(776, 455)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Printing profiles"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(324, 103)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(107, 23)
        Me.btnEdit.TabIndex = 4
        Me.btnEdit.Text = "Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(324, 74)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(107, 23)
        Me.btnDelete.TabIndex = 3
        Me.btnDelete.Text = "-    Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(324, 45)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(107, 23)
        Me.btnAdd.TabIndex = 2
        Me.btnAdd.Text = "+    Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(25, 45)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(278, 382)
        Me.DataGridView1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 14)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Printer profiles:"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.TabControl2)
        Me.TabPage4.Controls.Add(Me.ListBox1)
        Me.TabPage4.Controls.Add(Me.Label8)
        Me.TabPage4.Controls.Add(Me.chkSave_Freeze)
        Me.TabPage4.Controls.Add(Me.Label6)
        Me.TabPage4.Controls.Add(Me.NumUpD1)
        Me.TabPage4.Controls.Add(Me.Label7)
        Me.TabPage4.Controls.Add(Me.chkPedal_Input)
        Me.TabPage4.Controls.Add(Me.Label5)
        Me.TabPage4.Controls.Add(Me.NumUpD)
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Controls.Add(Me.cmbPedalType)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(776, 455)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Foot pedal"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage9)
        Me.TabControl2.Controls.Add(Me.TabPage10)
        Me.TabControl2.Location = New System.Drawing.Point(339, 29)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(289, 413)
        Me.TabControl2.TabIndex = 12
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.chkOpenClose_Inverted)
        Me.TabPage9.Controls.Add(Me.chkOpenClose_Triggered)
        Me.TabPage9.Controls.Add(Me.GroupBox4)
        Me.TabPage9.Controls.Add(Me.GroupBox3)
        Me.TabPage9.Controls.Add(Me.GroupBox2)
        Me.TabPage9.Controls.Add(Me.GroupBox1)
        Me.TabPage9.Controls.Add(Me.cmbJoystick_Device)
        Me.TabPage9.Controls.Add(Me.Label9)
        Me.TabPage9.Location = New System.Drawing.Point(4, 23)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(281, 386)
        Me.TabPage9.TabIndex = 0
        Me.TabPage9.Text = "Joystick port"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'chkOpenClose_Inverted
        '
        Me.chkOpenClose_Inverted.AutoSize = True
        Me.chkOpenClose_Inverted.Location = New System.Drawing.Point(6, 338)
        Me.chkOpenClose_Inverted.Name = "chkOpenClose_Inverted"
        Me.chkOpenClose_Inverted.Size = New System.Drawing.Size(156, 18)
        Me.chkOpenClose_Inverted.TabIndex = 7
        Me.chkOpenClose_Inverted.Text = "Open/Close inverted"
        Me.chkOpenClose_Inverted.UseVisualStyleBackColor = True
        '
        'chkOpenClose_Triggered
        '
        Me.chkOpenClose_Triggered.AutoSize = True
        Me.chkOpenClose_Triggered.Location = New System.Drawing.Point(6, 318)
        Me.chkOpenClose_Triggered.Name = "chkOpenClose_Triggered"
        Me.chkOpenClose_Triggered.Size = New System.Drawing.Size(209, 18)
        Me.chkOpenClose_Triggered.TabIndex = 6
        Me.chkOpenClose_Triggered.Text = "Open/Close is level triggered"
        Me.chkOpenClose_Triggered.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rbOpenClose_Port4)
        Me.GroupBox4.Controls.Add(Me.rbOpenClose_Port3)
        Me.GroupBox4.Controls.Add(Me.rbOpenClose_Port2)
        Me.GroupBox4.Controls.Add(Me.rbOpenClose_Port1)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 247)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(269, 49)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Open/Close function:"
        '
        'rbOpenClose_Port4
        '
        Me.rbOpenClose_Port4.AutoSize = True
        Me.rbOpenClose_Port4.Location = New System.Drawing.Point(198, 18)
        Me.rbOpenClose_Port4.Name = "rbOpenClose_Port4"
        Me.rbOpenClose_Port4.Size = New System.Drawing.Size(63, 18)
        Me.rbOpenClose_Port4.TabIndex = 3
        Me.rbOpenClose_Port4.TabStop = True
        Me.rbOpenClose_Port4.Text = "Port 4"
        Me.rbOpenClose_Port4.UseVisualStyleBackColor = True
        '
        'rbOpenClose_Port3
        '
        Me.rbOpenClose_Port3.AutoSize = True
        Me.rbOpenClose_Port3.Location = New System.Drawing.Point(133, 18)
        Me.rbOpenClose_Port3.Name = "rbOpenClose_Port3"
        Me.rbOpenClose_Port3.Size = New System.Drawing.Size(63, 18)
        Me.rbOpenClose_Port3.TabIndex = 2
        Me.rbOpenClose_Port3.TabStop = True
        Me.rbOpenClose_Port3.Text = "Port 3"
        Me.rbOpenClose_Port3.UseVisualStyleBackColor = True
        '
        'rbOpenClose_Port2
        '
        Me.rbOpenClose_Port2.AutoSize = True
        Me.rbOpenClose_Port2.Location = New System.Drawing.Point(68, 18)
        Me.rbOpenClose_Port2.Name = "rbOpenClose_Port2"
        Me.rbOpenClose_Port2.Size = New System.Drawing.Size(63, 18)
        Me.rbOpenClose_Port2.TabIndex = 1
        Me.rbOpenClose_Port2.TabStop = True
        Me.rbOpenClose_Port2.Text = "Port 2"
        Me.rbOpenClose_Port2.UseVisualStyleBackColor = True
        '
        'rbOpenClose_Port1
        '
        Me.rbOpenClose_Port1.AutoSize = True
        Me.rbOpenClose_Port1.Location = New System.Drawing.Point(3, 18)
        Me.rbOpenClose_Port1.Name = "rbOpenClose_Port1"
        Me.rbOpenClose_Port1.Size = New System.Drawing.Size(63, 18)
        Me.rbOpenClose_Port1.TabIndex = 0
        Me.rbOpenClose_Port1.TabStop = True
        Me.rbOpenClose_Port1.Text = "Port 1"
        Me.rbOpenClose_Port1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbJoystickPortSave4)
        Me.GroupBox3.Controls.Add(Me.rbJoystickPortSave3)
        Me.GroupBox3.Controls.Add(Me.rbJoystickPortSave2)
        Me.GroupBox3.Controls.Add(Me.rbJoystickPortSave1)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 186)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(269, 49)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Joystick port Save:"
        '
        'rbJoystickPortSave4
        '
        Me.rbJoystickPortSave4.AutoSize = True
        Me.rbJoystickPortSave4.Location = New System.Drawing.Point(198, 18)
        Me.rbJoystickPortSave4.Name = "rbJoystickPortSave4"
        Me.rbJoystickPortSave4.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortSave4.TabIndex = 3
        Me.rbJoystickPortSave4.TabStop = True
        Me.rbJoystickPortSave4.Text = "Port 4"
        Me.rbJoystickPortSave4.UseVisualStyleBackColor = True
        '
        'rbJoystickPortSave3
        '
        Me.rbJoystickPortSave3.AutoSize = True
        Me.rbJoystickPortSave3.Location = New System.Drawing.Point(133, 18)
        Me.rbJoystickPortSave3.Name = "rbJoystickPortSave3"
        Me.rbJoystickPortSave3.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortSave3.TabIndex = 2
        Me.rbJoystickPortSave3.TabStop = True
        Me.rbJoystickPortSave3.Text = "Port 3"
        Me.rbJoystickPortSave3.UseVisualStyleBackColor = True
        '
        'rbJoystickPortSave2
        '
        Me.rbJoystickPortSave2.AutoSize = True
        Me.rbJoystickPortSave2.Location = New System.Drawing.Point(68, 18)
        Me.rbJoystickPortSave2.Name = "rbJoystickPortSave2"
        Me.rbJoystickPortSave2.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortSave2.TabIndex = 1
        Me.rbJoystickPortSave2.TabStop = True
        Me.rbJoystickPortSave2.Text = "Port 2"
        Me.rbJoystickPortSave2.UseVisualStyleBackColor = True
        '
        'rbJoystickPortSave1
        '
        Me.rbJoystickPortSave1.AutoSize = True
        Me.rbJoystickPortSave1.Location = New System.Drawing.Point(3, 18)
        Me.rbJoystickPortSave1.Name = "rbJoystickPortSave1"
        Me.rbJoystickPortSave1.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortSave1.TabIndex = 0
        Me.rbJoystickPortSave1.TabStop = True
        Me.rbJoystickPortSave1.Text = "Port 1"
        Me.rbJoystickPortSave1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbJoystickPortFreeze4)
        Me.GroupBox2.Controls.Add(Me.rbJoystickPortFreeze3)
        Me.GroupBox2.Controls.Add(Me.rbJoystickPortFreeze2)
        Me.GroupBox2.Controls.Add(Me.rbJoystickPortFreeze1)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 125)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(269, 49)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Joystick port Freeze:"
        '
        'rbJoystickPortFreeze4
        '
        Me.rbJoystickPortFreeze4.AutoSize = True
        Me.rbJoystickPortFreeze4.Location = New System.Drawing.Point(198, 18)
        Me.rbJoystickPortFreeze4.Name = "rbJoystickPortFreeze4"
        Me.rbJoystickPortFreeze4.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortFreeze4.TabIndex = 3
        Me.rbJoystickPortFreeze4.TabStop = True
        Me.rbJoystickPortFreeze4.Text = "Port 4"
        Me.rbJoystickPortFreeze4.UseVisualStyleBackColor = True
        '
        'rbJoystickPortFreeze3
        '
        Me.rbJoystickPortFreeze3.AutoSize = True
        Me.rbJoystickPortFreeze3.Location = New System.Drawing.Point(133, 18)
        Me.rbJoystickPortFreeze3.Name = "rbJoystickPortFreeze3"
        Me.rbJoystickPortFreeze3.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortFreeze3.TabIndex = 2
        Me.rbJoystickPortFreeze3.TabStop = True
        Me.rbJoystickPortFreeze3.Text = "Port 3"
        Me.rbJoystickPortFreeze3.UseVisualStyleBackColor = True
        '
        'rbJoystickPortFreeze2
        '
        Me.rbJoystickPortFreeze2.AutoSize = True
        Me.rbJoystickPortFreeze2.Location = New System.Drawing.Point(68, 18)
        Me.rbJoystickPortFreeze2.Name = "rbJoystickPortFreeze2"
        Me.rbJoystickPortFreeze2.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortFreeze2.TabIndex = 1
        Me.rbJoystickPortFreeze2.TabStop = True
        Me.rbJoystickPortFreeze2.Text = "Port 2"
        Me.rbJoystickPortFreeze2.UseVisualStyleBackColor = True
        '
        'rbJoystickPortFreeze1
        '
        Me.rbJoystickPortFreeze1.AutoSize = True
        Me.rbJoystickPortFreeze1.Location = New System.Drawing.Point(3, 18)
        Me.rbJoystickPortFreeze1.Name = "rbJoystickPortFreeze1"
        Me.rbJoystickPortFreeze1.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPortFreeze1.TabIndex = 0
        Me.rbJoystickPortFreeze1.TabStop = True
        Me.rbJoystickPortFreeze1.Text = "Port 1"
        Me.rbJoystickPortFreeze1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbJoystickPort4)
        Me.GroupBox1.Controls.Add(Me.rbJoystickPort3)
        Me.GroupBox1.Controls.Add(Me.rbJoystickPort2)
        Me.GroupBox1.Controls.Add(Me.rbJoystickPort1)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 65)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(269, 49)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Test joystick ports:"
        '
        'rbJoystickPort4
        '
        Me.rbJoystickPort4.AutoSize = True
        Me.rbJoystickPort4.Location = New System.Drawing.Point(198, 18)
        Me.rbJoystickPort4.Name = "rbJoystickPort4"
        Me.rbJoystickPort4.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPort4.TabIndex = 3
        Me.rbJoystickPort4.TabStop = True
        Me.rbJoystickPort4.Text = "Port 4"
        Me.rbJoystickPort4.UseVisualStyleBackColor = True
        '
        'rbJoystickPort3
        '
        Me.rbJoystickPort3.AutoSize = True
        Me.rbJoystickPort3.Location = New System.Drawing.Point(133, 18)
        Me.rbJoystickPort3.Name = "rbJoystickPort3"
        Me.rbJoystickPort3.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPort3.TabIndex = 2
        Me.rbJoystickPort3.TabStop = True
        Me.rbJoystickPort3.Text = "Port 3"
        Me.rbJoystickPort3.UseVisualStyleBackColor = True
        '
        'rbJoystickPort2
        '
        Me.rbJoystickPort2.AutoSize = True
        Me.rbJoystickPort2.Location = New System.Drawing.Point(68, 18)
        Me.rbJoystickPort2.Name = "rbJoystickPort2"
        Me.rbJoystickPort2.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPort2.TabIndex = 1
        Me.rbJoystickPort2.TabStop = True
        Me.rbJoystickPort2.Text = "Port 2"
        Me.rbJoystickPort2.UseVisualStyleBackColor = True
        '
        'rbJoystickPort1
        '
        Me.rbJoystickPort1.AutoSize = True
        Me.rbJoystickPort1.Location = New System.Drawing.Point(3, 18)
        Me.rbJoystickPort1.Name = "rbJoystickPort1"
        Me.rbJoystickPort1.Size = New System.Drawing.Size(63, 18)
        Me.rbJoystickPort1.TabIndex = 0
        Me.rbJoystickPort1.TabStop = True
        Me.rbJoystickPort1.Text = "Port 1"
        Me.rbJoystickPort1.UseVisualStyleBackColor = True
        '
        'cmbJoystick_Device
        '
        Me.cmbJoystick_Device.FormattingEnabled = True
        Me.cmbJoystick_Device.Items.AddRange(New Object() {"IBM compatible(not NT/2000/XP)"})
        Me.cmbJoystick_Device.Location = New System.Drawing.Point(6, 22)
        Me.cmbJoystick_Device.Name = "cmbJoystick_Device"
        Me.cmbJoystick_Device.Size = New System.Drawing.Size(269, 22)
        Me.cmbJoystick_Device.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 14)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Joystick device:"
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.chkRTS_State)
        Me.TabPage10.Controls.Add(Me.chkDTR_State)
        Me.TabPage10.Controls.Add(Me.GroupBox5)
        Me.TabPage10.Controls.Add(Me.txtCommParameters)
        Me.TabPage10.Controls.Add(Me.Label11)
        Me.TabPage10.Controls.Add(Me.Label10)
        Me.TabPage10.Location = New System.Drawing.Point(4, 23)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(281, 386)
        Me.TabPage10.TabIndex = 1
        Me.TabPage10.Text = "Communication port"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'chkRTS_State
        '
        Me.chkRTS_State.AutoSize = True
        Me.chkRTS_State.Location = New System.Drawing.Point(15, 208)
        Me.chkRTS_State.Name = "chkRTS_State"
        Me.chkRTS_State.Size = New System.Drawing.Size(127, 18)
        Me.chkRTS_State.TabIndex = 29
        Me.chkRTS_State.Text = "RTS state (pin7)"
        Me.chkRTS_State.UseVisualStyleBackColor = True
        '
        'chkDTR_State
        '
        Me.chkDTR_State.AutoSize = True
        Me.chkDTR_State.Location = New System.Drawing.Point(15, 187)
        Me.chkDTR_State.Name = "chkDTR_State"
        Me.chkDTR_State.Size = New System.Drawing.Size(128, 18)
        Me.chkDTR_State.TabIndex = 28
        Me.chkDTR_State.Text = "DTR state (pin4)"
        Me.chkDTR_State.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.rbRI)
        Me.GroupBox5.Controls.Add(Me.rbRLSD)
        Me.GroupBox5.Controls.Add(Me.rbDSR)
        Me.GroupBox5.Controls.Add(Me.rbCTS)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 120)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(263, 49)
        Me.GroupBox5.TabIndex = 27
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Test comm port inputs:"
        '
        'rbRI
        '
        Me.rbRI.AutoSize = True
        Me.rbRI.Location = New System.Drawing.Point(198, 18)
        Me.rbRI.Name = "rbRI"
        Me.rbRI.Size = New System.Drawing.Size(38, 18)
        Me.rbRI.TabIndex = 3
        Me.rbRI.TabStop = True
        Me.rbRI.Text = "RI"
        Me.rbRI.UseVisualStyleBackColor = True
        '
        'rbRLSD
        '
        Me.rbRLSD.AutoSize = True
        Me.rbRLSD.Location = New System.Drawing.Point(133, 18)
        Me.rbRLSD.Name = "rbRLSD"
        Me.rbRLSD.Size = New System.Drawing.Size(57, 18)
        Me.rbRLSD.TabIndex = 2
        Me.rbRLSD.TabStop = True
        Me.rbRLSD.Text = "RLSD"
        Me.rbRLSD.UseVisualStyleBackColor = True
        '
        'rbDSR
        '
        Me.rbDSR.AutoSize = True
        Me.rbDSR.Location = New System.Drawing.Point(68, 18)
        Me.rbDSR.Name = "rbDSR"
        Me.rbDSR.Size = New System.Drawing.Size(50, 18)
        Me.rbDSR.TabIndex = 1
        Me.rbDSR.TabStop = True
        Me.rbDSR.Text = "DSR"
        Me.rbDSR.UseVisualStyleBackColor = True
        '
        'rbCTS
        '
        Me.rbCTS.AutoSize = True
        Me.rbCTS.Location = New System.Drawing.Point(3, 18)
        Me.rbCTS.Name = "rbCTS"
        Me.rbCTS.Size = New System.Drawing.Size(49, 18)
        Me.rbCTS.TabIndex = 0
        Me.rbCTS.TabStop = True
        Me.rbCTS.Text = "CTS"
        Me.rbCTS.UseVisualStyleBackColor = True
        '
        'txtCommParameters
        '
        Me.txtCommParameters.Location = New System.Drawing.Point(12, 88)
        Me.txtCommParameters.Name = "txtCommParameters"
        Me.txtCommParameters.Size = New System.Drawing.Size(239, 22)
        Me.txtCommParameters.TabIndex = 26
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(9, 71)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(128, 14)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Comm parameters:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(77, 38)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(145, 14)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Comm port connected"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 14
        Me.ListBox1.Location = New System.Drawing.Point(13, 256)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(302, 186)
        Me.ListBox1.TabIndex = 11
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 239)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(161, 14)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Press foot pedal to test:"
        '
        'chkSave_Freeze
        '
        Me.chkSave_Freeze.AutoSize = True
        Me.chkSave_Freeze.Location = New System.Drawing.Point(13, 203)
        Me.chkSave_Freeze.Name = "chkSave_Freeze"
        Me.chkSave_Freeze.Size = New System.Drawing.Size(159, 18)
        Me.chkSave_Freeze.TabIndex = 9
        Me.chkSave_Freeze.Text = "Reverse save/Freeze"
        Me.chkSave_Freeze.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(280, 164)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 14)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "(ms)"
        '
        'NumUpD1
        '
        Me.NumUpD1.Location = New System.Drawing.Point(205, 162)
        Me.NumUpD1.Name = "NumUpD1"
        Me.NumUpD1.Size = New System.Drawing.Size(69, 22)
        Me.NumUpD1.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(75, 164)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(124, 14)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Save waiting time:"
        '
        'chkPedal_Input
        '
        Me.chkPedal_Input.AutoSize = True
        Me.chkPedal_Input.Location = New System.Drawing.Point(13, 133)
        Me.chkPedal_Input.Name = "chkPedal_Input"
        Me.chkPedal_Input.Size = New System.Drawing.Size(139, 18)
        Me.chkPedal_Input.TabIndex = 5
        Me.chkPedal_Input.Text = "Invert pedal input"
        Me.chkPedal_Input.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(280, 86)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 14)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "(ms)"
        '
        'NumUpD
        '
        Me.NumUpD.Location = New System.Drawing.Point(205, 82)
        Me.NumUpD.Name = "NumUpD"
        Me.NumUpD.Size = New System.Drawing.Size(69, 22)
        Me.NumUpD.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(64, 84)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(135, 14)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Press-time for Save:"
        '
        'cmbPedalType
        '
        Me.cmbPedalType.FormattingEnabled = True
        Me.cmbPedalType.Location = New System.Drawing.Point(13, 46)
        Me.cmbPedalType.Name = "cmbPedalType"
        Me.cmbPedalType.Size = New System.Drawing.Size(261, 22)
        Me.cmbPedalType.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 14)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Pedal type:"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.btnDefaultScanner)
        Me.TabPage5.Controls.Add(Me.btnScanEdit)
        Me.TabPage5.Controls.Add(Me.btnScanDelete)
        Me.TabPage5.Controls.Add(Me.btnScanAdd)
        Me.TabPage5.Controls.Add(Me.DataGridView2)
        Me.TabPage5.Controls.Add(Me.Label12)
        Me.TabPage5.Location = New System.Drawing.Point(4, 23)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(776, 455)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Scanners"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'btnDefaultScanner
        '
        Me.btnDefaultScanner.Location = New System.Drawing.Point(327, 132)
        Me.btnDefaultScanner.Name = "btnDefaultScanner"
        Me.btnDefaultScanner.Size = New System.Drawing.Size(220, 23)
        Me.btnDefaultScanner.TabIndex = 32
        Me.btnDefaultScanner.Text = "Set default scanner..."
        Me.btnDefaultScanner.UseVisualStyleBackColor = True
        '
        'btnScanEdit
        '
        Me.btnScanEdit.Location = New System.Drawing.Point(327, 103)
        Me.btnScanEdit.Name = "btnScanEdit"
        Me.btnScanEdit.Size = New System.Drawing.Size(107, 23)
        Me.btnScanEdit.TabIndex = 28
        Me.btnScanEdit.Text = "Edit"
        Me.btnScanEdit.UseVisualStyleBackColor = True
        '
        'btnScanDelete
        '
        Me.btnScanDelete.Location = New System.Drawing.Point(327, 74)
        Me.btnScanDelete.Name = "btnScanDelete"
        Me.btnScanDelete.Size = New System.Drawing.Size(107, 23)
        Me.btnScanDelete.TabIndex = 27
        Me.btnScanDelete.Text = "-    Delete"
        Me.btnScanDelete.UseVisualStyleBackColor = True
        '
        'btnScanAdd
        '
        Me.btnScanAdd.Location = New System.Drawing.Point(327, 45)
        Me.btnScanAdd.Name = "btnScanAdd"
        Me.btnScanAdd.Size = New System.Drawing.Size(107, 23)
        Me.btnScanAdd.TabIndex = 26
        Me.btnScanAdd.Text = "+    Add"
        Me.btnScanAdd.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(28, 45)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(278, 382)
        Me.DataGridView2.TabIndex = 25
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(25, 28)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(113, 14)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Scanner profiles:"
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.btnHotkeyBrowse)
        Me.TabPage6.Controls.Add(Me.txtHotkey)
        Me.TabPage6.Controls.Add(Me.Label18)
        Me.TabPage6.Controls.Add(Me.chkGlobal_Hotkey)
        Me.TabPage6.Controls.Add(Me.GroupBox8)
        Me.TabPage6.Controls.Add(Me.GroupBox7)
        Me.TabPage6.Controls.Add(Me.GroupBox6)
        Me.TabPage6.Location = New System.Drawing.Point(4, 23)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(776, 455)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Waiting room"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'btnHotkeyBrowse
        '
        Me.btnHotkeyBrowse.Location = New System.Drawing.Point(303, 417)
        Me.btnHotkeyBrowse.Name = "btnHotkeyBrowse"
        Me.btnHotkeyBrowse.Size = New System.Drawing.Size(42, 23)
        Me.btnHotkeyBrowse.TabIndex = 9
        Me.btnHotkeyBrowse.Text = "..."
        Me.btnHotkeyBrowse.UseVisualStyleBackColor = True
        '
        'txtHotkey
        '
        Me.txtHotkey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtHotkey.Location = New System.Drawing.Point(150, 418)
        Me.txtHotkey.Name = "txtHotkey"
        Me.txtHotkey.Size = New System.Drawing.Size(139, 22)
        Me.txtHotkey.TabIndex = 8
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(90, 421)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(56, 14)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Hotkey:"
        '
        'chkGlobal_Hotkey
        '
        Me.chkGlobal_Hotkey.AutoSize = True
        Me.chkGlobal_Hotkey.Location = New System.Drawing.Point(16, 388)
        Me.chkGlobal_Hotkey.Name = "chkGlobal_Hotkey"
        Me.chkGlobal_Hotkey.Size = New System.Drawing.Size(158, 18)
        Me.chkGlobal_Hotkey.TabIndex = 5
        Me.chkGlobal_Hotkey.Text = "Enable global hotkey"
        Me.chkGlobal_Hotkey.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.txtAxisWebcam_URL4)
        Me.GroupBox8.Controls.Add(Me.Label17)
        Me.GroupBox8.Controls.Add(Me.txtAxisWebcam_URL3)
        Me.GroupBox8.Controls.Add(Me.Label16)
        Me.GroupBox8.Controls.Add(Me.txtAxisWebcam_URL2)
        Me.GroupBox8.Controls.Add(Me.Label15)
        Me.GroupBox8.Controls.Add(Me.txtAxisWebcam_URL1)
        Me.GroupBox8.Controls.Add(Me.Label14)
        Me.GroupBox8.Location = New System.Drawing.Point(16, 218)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(545, 150)
        Me.GroupBox8.TabIndex = 4
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Axis webcam settings"
        '
        'txtAxisWebcam_URL4
        '
        Me.txtAxisWebcam_URL4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAxisWebcam_URL4.Location = New System.Drawing.Point(98, 111)
        Me.txtAxisWebcam_URL4.Name = "txtAxisWebcam_URL4"
        Me.txtAxisWebcam_URL4.Size = New System.Drawing.Size(432, 22)
        Me.txtAxisWebcam_URL4.TabIndex = 7
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(43, 114)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(48, 14)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "URL 4:"
        '
        'txtAxisWebcam_URL3
        '
        Me.txtAxisWebcam_URL3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAxisWebcam_URL3.Location = New System.Drawing.Point(98, 83)
        Me.txtAxisWebcam_URL3.Name = "txtAxisWebcam_URL3"
        Me.txtAxisWebcam_URL3.Size = New System.Drawing.Size(432, 22)
        Me.txtAxisWebcam_URL3.TabIndex = 5
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(43, 86)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(48, 14)
        Me.Label16.TabIndex = 4
        Me.Label16.Text = "URL 3:"
        '
        'txtAxisWebcam_URL2
        '
        Me.txtAxisWebcam_URL2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAxisWebcam_URL2.Location = New System.Drawing.Point(98, 54)
        Me.txtAxisWebcam_URL2.Name = "txtAxisWebcam_URL2"
        Me.txtAxisWebcam_URL2.Size = New System.Drawing.Size(432, 22)
        Me.txtAxisWebcam_URL2.TabIndex = 3
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(43, 57)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(48, 14)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "URL 2:"
        '
        'txtAxisWebcam_URL1
        '
        Me.txtAxisWebcam_URL1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAxisWebcam_URL1.Location = New System.Drawing.Point(98, 24)
        Me.txtAxisWebcam_URL1.Name = "txtAxisWebcam_URL1"
        Me.txtAxisWebcam_URL1.Size = New System.Drawing.Size(432, 22)
        Me.txtAxisWebcam_URL1.TabIndex = 1
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(43, 27)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(48, 14)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "URL 1:"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.btnImgFile_Open)
        Me.GroupBox7.Controls.Add(Me.txtImgFileName)
        Me.GroupBox7.Controls.Add(Me.Label13)
        Me.GroupBox7.Location = New System.Drawing.Point(16, 110)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(545, 100)
        Me.GroupBox7.TabIndex = 3
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "VidCatch settings"
        '
        'btnImgFile_Open
        '
        Me.btnImgFile_Open.Location = New System.Drawing.Point(484, 42)
        Me.btnImgFile_Open.Name = "btnImgFile_Open"
        Me.btnImgFile_Open.Size = New System.Drawing.Size(46, 23)
        Me.btnImgFile_Open.TabIndex = 2
        Me.btnImgFile_Open.UseVisualStyleBackColor = True
        '
        'txtImgFileName
        '
        Me.txtImgFileName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtImgFileName.Location = New System.Drawing.Point(185, 41)
        Me.txtImgFileName.Name = "txtImgFileName"
        Me.txtImgFileName.Size = New System.Drawing.Size(293, 22)
        Me.txtImgFileName.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(69, 43)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(113, 14)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Image file name:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rbAxis_webcam)
        Me.GroupBox6.Controls.Add(Me.rbVidCatch)
        Me.GroupBox6.Controls.Add(Me.rbNone)
        Me.GroupBox6.Location = New System.Drawing.Point(16, 13)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(200, 90)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Waiting room interface"
        '
        'rbAxis_webcam
        '
        Me.rbAxis_webcam.AutoSize = True
        Me.rbAxis_webcam.Location = New System.Drawing.Point(3, 66)
        Me.rbAxis_webcam.Name = "rbAxis_webcam"
        Me.rbAxis_webcam.Size = New System.Drawing.Size(106, 18)
        Me.rbAxis_webcam.TabIndex = 2
        Me.rbAxis_webcam.TabStop = True
        Me.rbAxis_webcam.Text = "Axis webcam"
        Me.rbAxis_webcam.UseVisualStyleBackColor = True
        '
        'rbVidCatch
        '
        Me.rbVidCatch.AutoSize = True
        Me.rbVidCatch.Location = New System.Drawing.Point(3, 42)
        Me.rbVidCatch.Name = "rbVidCatch"
        Me.rbVidCatch.Size = New System.Drawing.Size(80, 18)
        Me.rbVidCatch.TabIndex = 1
        Me.rbVidCatch.TabStop = True
        Me.rbVidCatch.Text = "VidCatch"
        Me.rbVidCatch.UseVisualStyleBackColor = True
        '
        'rbNone
        '
        Me.rbNone.AutoSize = True
        Me.rbNone.Location = New System.Drawing.Point(3, 18)
        Me.rbNone.Name = "rbNone"
        Me.rbNone.Size = New System.Drawing.Size(58, 18)
        Me.rbNone.TabIndex = 0
        Me.rbNone.TabStop = True
        Me.rbNone.Text = "None"
        Me.rbNone.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.NumericUpD)
        Me.TabPage7.Controls.Add(Me.Label20)
        Me.TabPage7.Controls.Add(Me.chkRecompress)
        Me.TabPage7.Controls.Add(Me.btnCameraBrowse)
        Me.TabPage7.Controls.Add(Me.txtCameraName)
        Me.TabPage7.Controls.Add(Me.Label19)
        Me.TabPage7.Controls.Add(Me.chkAutoOpen_Import)
        Me.TabPage7.Controls.Add(Me.chkAuto_Import)
        Me.TabPage7.Location = New System.Drawing.Point(4, 23)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(776, 455)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Auto-import"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'NumericUpD
        '
        Me.NumericUpD.Location = New System.Drawing.Point(152, 156)
        Me.NumericUpD.Name = "NumericUpD"
        Me.NumericUpD.Size = New System.Drawing.Size(69, 22)
        Me.NumericUpD.TabIndex = 7
        Me.NumericUpD.Value = New Decimal(New Integer() {80, 0, 0, 0})
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(18, 158)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(128, 14)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "JPEG quality factor:"
        '
        'chkRecompress
        '
        Me.chkRecompress.AutoSize = True
        Me.chkRecompress.Location = New System.Drawing.Point(8, 126)
        Me.chkRecompress.Name = "chkRecompress"
        Me.chkRecompress.Size = New System.Drawing.Size(185, 18)
        Me.chkRecompress.TabIndex = 5
        Me.chkRecompress.Text = "Recompress JPEG images"
        Me.chkRecompress.UseVisualStyleBackColor = True
        '
        'btnCameraBrowse
        '
        Me.btnCameraBrowse.Location = New System.Drawing.Point(397, 80)
        Me.btnCameraBrowse.Name = "btnCameraBrowse"
        Me.btnCameraBrowse.Size = New System.Drawing.Size(36, 23)
        Me.btnCameraBrowse.TabIndex = 4
        Me.btnCameraBrowse.UseVisualStyleBackColor = True
        '
        'txtCameraName
        '
        Me.txtCameraName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCameraName.Location = New System.Drawing.Point(142, 81)
        Me.txtCameraName.Name = "txtCameraName"
        Me.txtCameraName.Size = New System.Drawing.Size(249, 22)
        Me.txtCameraName.TabIndex = 3
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(36, 84)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(100, 14)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Camera name:"
        '
        'chkAutoOpen_Import
        '
        Me.chkAutoOpen_Import.AutoSize = True
        Me.chkAutoOpen_Import.Location = New System.Drawing.Point(8, 34)
        Me.chkAutoOpen_Import.Name = "chkAutoOpen_Import"
        Me.chkAutoOpen_Import.Size = New System.Drawing.Size(305, 18)
        Me.chkAutoOpen_Import.TabIndex = 1
        Me.chkAutoOpen_Import.Text = "Auto-open import when camera is turned on"
        Me.chkAutoOpen_Import.UseVisualStyleBackColor = True
        '
        'chkAuto_Import
        '
        Me.chkAuto_Import.AutoSize = True
        Me.chkAuto_Import.Location = New System.Drawing.Point(8, 14)
        Me.chkAuto_Import.Name = "chkAuto_Import"
        Me.chkAuto_Import.Size = New System.Drawing.Size(147, 18)
        Me.chkAuto_Import.TabIndex = 0
        Me.chkAuto_Import.Text = "Enable auto-import"
        Me.chkAuto_Import.UseVisualStyleBackColor = True
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.btnAbout)
        Me.TabPage8.Controls.Add(Me.btnExport)
        Me.TabPage8.Controls.Add(Me.btnImport)
        Me.TabPage8.Controls.Add(Me.btnDetect)
        Me.TabPage8.Controls.Add(Me.btnSettings_Edit)
        Me.TabPage8.Controls.Add(Me.btnSettings_Delete)
        Me.TabPage8.Controls.Add(Me.btnSettings_Add)
        Me.TabPage8.Controls.Add(Me.DataGridView3)
        Me.TabPage8.Controls.Add(Me.Label21)
        Me.TabPage8.Location = New System.Drawing.Point(4, 23)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(776, 455)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Video"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'btnAbout
        '
        Me.btnAbout.Location = New System.Drawing.Point(658, 411)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(107, 23)
        Me.btnAbout.TabIndex = 54
        Me.btnAbout.Text = "About"
        Me.btnAbout.UseVisualStyleBackColor = True
        '
        'btnExport
        '
        Me.btnExport.Location = New System.Drawing.Point(658, 382)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(107, 23)
        Me.btnExport.TabIndex = 53
        Me.btnExport.Text = "Export"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'btnImport
        '
        Me.btnImport.Location = New System.Drawing.Point(658, 353)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(107, 23)
        Me.btnImport.TabIndex = 52
        Me.btnImport.Text = "Import"
        Me.btnImport.UseVisualStyleBackColor = True
        '
        'btnDetect
        '
        Me.btnDetect.Location = New System.Drawing.Point(658, 324)
        Me.btnDetect.Name = "btnDetect"
        Me.btnDetect.Size = New System.Drawing.Size(107, 23)
        Me.btnDetect.TabIndex = 51
        Me.btnDetect.Text = "Detect"
        Me.btnDetect.UseVisualStyleBackColor = True
        '
        'btnSettings_Edit
        '
        Me.btnSettings_Edit.Location = New System.Drawing.Point(275, 395)
        Me.btnSettings_Edit.Name = "btnSettings_Edit"
        Me.btnSettings_Edit.Size = New System.Drawing.Size(107, 23)
        Me.btnSettings_Edit.TabIndex = 37
        Me.btnSettings_Edit.Text = "Edit"
        Me.btnSettings_Edit.UseVisualStyleBackColor = True
        '
        'btnSettings_Delete
        '
        Me.btnSettings_Delete.Location = New System.Drawing.Point(150, 395)
        Me.btnSettings_Delete.Name = "btnSettings_Delete"
        Me.btnSettings_Delete.Size = New System.Drawing.Size(107, 23)
        Me.btnSettings_Delete.TabIndex = 36
        Me.btnSettings_Delete.Text = "-    Delete"
        Me.btnSettings_Delete.UseVisualStyleBackColor = True
        '
        'btnSettings_Add
        '
        Me.btnSettings_Add.Location = New System.Drawing.Point(28, 395)
        Me.btnSettings_Add.Name = "btnSettings_Add"
        Me.btnSettings_Add.Size = New System.Drawing.Size(107, 23)
        Me.btnSettings_Add.TabIndex = 35
        Me.btnSettings_Add.Text = "+    Add"
        Me.btnSettings_Add.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(28, 45)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(354, 344)
        Me.DataGridView3.TabIndex = 34
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(25, 28)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(64, 14)
        Me.Label21.TabIndex = 33
        Me.Label21.Text = "Settings:"
        '
        'btnHelp
        '
        Me.btnHelp.Location = New System.Drawing.Point(659, 166)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(94, 31)
        Me.btnHelp.TabIndex = 43
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.Location = New System.Drawing.Point(659, 118)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(94, 31)
        Me.btncancel.TabIndex = 42
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(659, 72)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(94, 31)
        Me.btnOK.TabIndex = 41
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'frm_deviceSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(786, 478)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frm_deviceSettings"
        Me.Text = "frm_deviceSettings"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.NumUpD1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumUpD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        CType(Me.NumericUpD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents chkDigital_XRay As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents btnFile_Open As System.Windows.Forms.Button
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkLogoImage As System.Windows.Forms.CheckBox
    Friend WithEvents chkImageNotes As System.Windows.Forms.CheckBox
    Friend WithEvents chkPatientNotes As System.Windows.Forms.CheckBox
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbPedalType As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chkPedal_Input As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumUpD As System.Windows.Forms.NumericUpDown
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents cmbJoystick_Device As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chkSave_Freeze As System.Windows.Forms.CheckBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumUpD1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkOpenClose_Inverted As System.Windows.Forms.CheckBox
    Friend WithEvents chkOpenClose_Triggered As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents rbOpenClose_Port4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbOpenClose_Port3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbOpenClose_Port2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbOpenClose_Port1 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbJoystickPortSave4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPortSave3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPortSave2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPortSave1 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbJoystickPortFreeze4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPortFreeze3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPortFreeze2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPortFreeze1 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbJoystickPort4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPort3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPort2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbJoystickPort1 As System.Windows.Forms.RadioButton
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents rbRI As System.Windows.Forms.RadioButton
    Friend WithEvents rbRLSD As System.Windows.Forms.RadioButton
    Friend WithEvents rbDSR As System.Windows.Forms.RadioButton
    Friend WithEvents rbCTS As System.Windows.Forms.RadioButton
    Friend WithEvents txtCommParameters As System.Windows.Forms.TextBox
    Friend WithEvents chkRTS_State As System.Windows.Forms.CheckBox
    Friend WithEvents chkDTR_State As System.Windows.Forms.CheckBox
    Friend WithEvents btnDefaultScanner As System.Windows.Forms.Button
    Friend WithEvents btnScanEdit As System.Windows.Forms.Button
    Friend WithEvents btnScanDelete As System.Windows.Forms.Button
    Friend WithEvents btnScanAdd As System.Windows.Forms.Button
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnHotkeyBrowse As System.Windows.Forms.Button
    Friend WithEvents txtHotkey As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents chkGlobal_Hotkey As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAxisWebcam_URL4 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtAxisWebcam_URL3 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtAxisWebcam_URL2 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtAxisWebcam_URL1 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents btnImgFile_Open As System.Windows.Forms.Button
    Friend WithEvents txtImgFileName As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents rbAxis_webcam As System.Windows.Forms.RadioButton
    Friend WithEvents rbVidCatch As System.Windows.Forms.RadioButton
    Friend WithEvents rbNone As System.Windows.Forms.RadioButton
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents chkAutoOpen_Import As System.Windows.Forms.CheckBox
    Friend WithEvents chkAuto_Import As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpD As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents chkRecompress As System.Windows.Forms.CheckBox
    Friend WithEvents btnCameraBrowse As System.Windows.Forms.Button
    Friend WithEvents txtCameraName As System.Windows.Forms.TextBox
    Friend WithEvents btnSettings_Edit As System.Windows.Forms.Button
    Friend WithEvents btnSettings_Delete As System.Windows.Forms.Button
    Friend WithEvents btnSettings_Add As System.Windows.Forms.Button
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btnAbout As System.Windows.Forms.Button
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents btnImport As System.Windows.Forms.Button
    Friend WithEvents btnDetect As System.Windows.Forms.Button
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
End Class
