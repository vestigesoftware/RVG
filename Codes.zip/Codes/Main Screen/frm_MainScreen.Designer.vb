﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_MainScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_MainScreen))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.PatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClosePatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreatedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UntreatedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DiagnosedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndiagnosedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitewingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TodaysImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SpecificImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SynchronizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DentistToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatisticsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NormalPrinterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImagePrinterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TestPrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SplitScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScreenToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.X4GridToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullMouthSeriesViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullViewAreaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToOtherMonitorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MeasurementsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewMakersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlinkMakersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VideoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScannerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportOriginalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportProcessedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DuplicateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToothWhitenerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RotateMirrirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate90ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate180ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate270ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MirrorXToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MirrorYToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EffectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NegativeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PseudoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SharpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmoothenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MediaFilterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SofttissueFilterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InteractiveContrastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContrastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HistogramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubtractToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImagePropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplicationSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DatabaseSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExternalApplicationSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommunicationSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeviceSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XRaySettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserWithPrivateSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaitingRoomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendNotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenMeasurementsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.FullScreenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ResetAllToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetContrastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetZoomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.Rotate90ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate180ºToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate270ºToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MirrorXToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MirrorYToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ColorBrandingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorDiferencingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SofttissueFilterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.HistogramToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.PropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton9 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton11 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton12 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton13 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton14 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton19 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton15 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton16 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton17 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton18 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton21 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton20 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton22 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton23 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton24 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton26 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnImport = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.grp1X = New System.Windows.Forms.GroupBox()
        Me.Pnl_1X1 = New System.Windows.Forms.Panel()
        Me.Pic_1_grp1X = New System.Windows.Forms.PictureBox()
        Me.grp2X = New System.Windows.Forms.GroupBox()
        Me.Pnl_2X2 = New System.Windows.Forms.Panel()
        Me.pic_2_grp2X = New System.Windows.Forms.PictureBox()
        Me.Pnl_2X1 = New System.Windows.Forms.Panel()
        Me.pic_1_grp2X = New System.Windows.Forms.PictureBox()
        Me.grp9X = New System.Windows.Forms.GroupBox()
        Me.Pnl_9X9 = New System.Windows.Forms.Panel()
        Me.pic_9_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X6 = New System.Windows.Forms.Panel()
        Me.pic_6_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X3 = New System.Windows.Forms.Panel()
        Me.pic_3_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X8 = New System.Windows.Forms.Panel()
        Me.pic_8_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X5 = New System.Windows.Forms.Panel()
        Me.pic_5_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X2 = New System.Windows.Forms.Panel()
        Me.pic_2_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X7 = New System.Windows.Forms.Panel()
        Me.pic_7_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X4 = New System.Windows.Forms.Panel()
        Me.pic_4_grp9x = New System.Windows.Forms.PictureBox()
        Me.Pnl_9X1 = New System.Windows.Forms.Panel()
        Me.pic_1_grp9x = New System.Windows.Forms.PictureBox()
        Me.grp4X = New System.Windows.Forms.GroupBox()
        Me.Pnl_4X2 = New System.Windows.Forms.Panel()
        Me.Pic_2_grp4X = New System.Windows.Forms.PictureBox()
        Me.Pnl_4X4 = New System.Windows.Forms.Panel()
        Me.Pic_4_grp4X = New System.Windows.Forms.PictureBox()
        Me.Pnl_4X3 = New System.Windows.Forms.Panel()
        Me.Pic_3_grp4X = New System.Windows.Forms.PictureBox()
        Me.Pnl_4X1 = New System.Windows.Forms.Panel()
        Me.Pic_1_grp4X = New System.Windows.Forms.PictureBox()
        Me.grpViewer = New System.Windows.Forms.GroupBox()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.grp16X = New System.Windows.Forms.GroupBox()
        Me.pic_16_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_15_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_14_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_13_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_12_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_8_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_4_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_11_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_7_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_3_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_10_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_9_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_6_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_5_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_2_grp16X = New System.Windows.Forms.PictureBox()
        Me.pic_1_grp16X = New System.Windows.Forms.PictureBox()
        Me.grpFullMouth = New System.Windows.Forms.GroupBox()
        Me.pic_18_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_17_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_16_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_15_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_14_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_13_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_12_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_11_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_10_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_9_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_8_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_7_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_6_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_5_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_4_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_3_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_2_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.pic_1_grpFullMouth = New System.Windows.Forms.PictureBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ExportOriginalToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportProcessedToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintTheCurrentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeleteToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomeViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FullMouthSeriesViewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PatientFileVewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitewingViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.PropertiesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnCloseMeasurement = New System.Windows.Forms.Button()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Measure_Text = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.pic_distance_measure = New System.Windows.Forms.PictureBox()
        Me.Measure_Move = New System.Windows.Forms.PictureBox()
        Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.MenuStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.grp1X.SuspendLayout()
        Me.Pnl_1X1.SuspendLayout()
        CType(Me.Pic_1_grp1X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp2X.SuspendLayout()
        Me.Pnl_2X2.SuspendLayout()
        CType(Me.pic_2_grp2X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_2X1.SuspendLayout()
        CType(Me.pic_1_grp2X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp9X.SuspendLayout()
        Me.Pnl_9X9.SuspendLayout()
        CType(Me.pic_9_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X6.SuspendLayout()
        CType(Me.pic_6_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X3.SuspendLayout()
        CType(Me.pic_3_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X8.SuspendLayout()
        CType(Me.pic_8_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X5.SuspendLayout()
        CType(Me.pic_5_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X2.SuspendLayout()
        CType(Me.pic_2_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X7.SuspendLayout()
        CType(Me.pic_7_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X4.SuspendLayout()
        CType(Me.pic_4_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_9X1.SuspendLayout()
        CType(Me.pic_1_grp9x, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp4X.SuspendLayout()
        Me.Pnl_4X2.SuspendLayout()
        CType(Me.Pic_2_grp4X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_4X4.SuspendLayout()
        CType(Me.Pic_4_grp4X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_4X3.SuspendLayout()
        CType(Me.Pic_3_grp4X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_4X1.SuspendLayout()
        CType(Me.Pic_1_grp4X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpViewer.SuspendLayout()
        Me.grp16X.SuspendLayout()
        CType(Me.pic_16_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_15_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_14_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_13_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_12_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_8_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_4_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_11_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_7_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_3_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_10_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_9_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_6_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_5_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_2_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_1_grp16X, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpFullMouth.SuspendLayout()
        CType(Me.pic_18_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_17_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_16_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_15_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_14_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_13_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_12_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_11_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_10_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_9_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_8_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_7_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_6_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_5_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_4_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_3_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_2_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_1_grpFullMouth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Measure_Text, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_distance_measure, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Measure_Move, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PatientToolStripMenuItem, Me.ViewToolStripMenuItem, Me.ImageToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'PatientToolStripMenuItem
        '
        Me.PatientToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.SelectToolStripMenuItem, Me.ClosePatientToolStripMenuItem, Me.DeleteToolStripMenuItem, Me.StatusToolStripMenuItem, Me.SaveToolStripMenuItem, Me.BitewingToolStripMenuItem, Me.TodaysImageToolStripMenuItem, Me.SpecificImageToolStripMenuItem, Me.SynchronizeToolStripMenuItem, Me.DentistToolStripMenuItem1, Me.ToolStripMenuItem1, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4, Me.ToolStripMenuItem5})
        Me.PatientToolStripMenuItem.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientToolStripMenuItem.Name = "PatientToolStripMenuItem"
        Me.PatientToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.PatientToolStripMenuItem.Text = "&File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.NewToolStripMenuItem.Text = "New Patient"
        '
        'SelectToolStripMenuItem
        '
        Me.SelectToolStripMenuItem.Name = "SelectToolStripMenuItem"
        Me.SelectToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SelectToolStripMenuItem.Text = "Select Patient"
        '
        'ClosePatientToolStripMenuItem
        '
        Me.ClosePatientToolStripMenuItem.Enabled = False
        Me.ClosePatientToolStripMenuItem.Name = "ClosePatientToolStripMenuItem"
        Me.ClosePatientToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.ClosePatientToolStripMenuItem.Text = "Close Patient"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete Patient"
        '
        'StatusToolStripMenuItem
        '
        Me.StatusToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TreatedToolStripMenuItem, Me.UntreatedToolStripMenuItem, Me.DiagnosedToolStripMenuItem, Me.UndiagnosedToolStripMenuItem, Me.AttenToolStripMenuItem})
        Me.StatusToolStripMenuItem.Enabled = False
        Me.StatusToolStripMenuItem.Name = "StatusToolStripMenuItem"
        Me.StatusToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.StatusToolStripMenuItem.Text = "Patient Status"
        '
        'TreatedToolStripMenuItem
        '
        Me.TreatedToolStripMenuItem.Name = "TreatedToolStripMenuItem"
        Me.TreatedToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.TreatedToolStripMenuItem.Text = "Treated"
        '
        'UntreatedToolStripMenuItem
        '
        Me.UntreatedToolStripMenuItem.Name = "UntreatedToolStripMenuItem"
        Me.UntreatedToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.UntreatedToolStripMenuItem.Text = "Untreated"
        '
        'DiagnosedToolStripMenuItem
        '
        Me.DiagnosedToolStripMenuItem.Name = "DiagnosedToolStripMenuItem"
        Me.DiagnosedToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.DiagnosedToolStripMenuItem.Text = "Diagnosed"
        '
        'UndiagnosedToolStripMenuItem
        '
        Me.UndiagnosedToolStripMenuItem.Name = "UndiagnosedToolStripMenuItem"
        Me.UndiagnosedToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.UndiagnosedToolStripMenuItem.Text = "Undiagnosed"
        '
        'AttenToolStripMenuItem
        '
        Me.AttenToolStripMenuItem.Name = "AttenToolStripMenuItem"
        Me.AttenToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.AttenToolStripMenuItem.Text = "Attention"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Enabled = False
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SaveToolStripMenuItem.Text = "Export Patient"
        '
        'BitewingToolStripMenuItem
        '
        Me.BitewingToolStripMenuItem.Name = "BitewingToolStripMenuItem"
        Me.BitewingToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.BitewingToolStripMenuItem.Text = "Bitewing View"
        '
        'TodaysImageToolStripMenuItem
        '
        Me.TodaysImageToolStripMenuItem.Name = "TodaysImageToolStripMenuItem"
        Me.TodaysImageToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.TodaysImageToolStripMenuItem.Text = "Recent Images"
        '
        'SpecificImageToolStripMenuItem
        '
        Me.SpecificImageToolStripMenuItem.Name = "SpecificImageToolStripMenuItem"
        Me.SpecificImageToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SpecificImageToolStripMenuItem.Text = "All Images"
        '
        'SynchronizeToolStripMenuItem
        '
        Me.SynchronizeToolStripMenuItem.Enabled = False
        Me.SynchronizeToolStripMenuItem.Name = "SynchronizeToolStripMenuItem"
        Me.SynchronizeToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SynchronizeToolStripMenuItem.Text = "Patient Properties"
        '
        'DentistToolStripMenuItem1
        '
        Me.DentistToolStripMenuItem1.Name = "DentistToolStripMenuItem1"
        Me.DentistToolStripMenuItem1.Size = New System.Drawing.Size(188, 22)
        Me.DentistToolStripMenuItem1.Text = "Dentist"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatisticsToolStripMenuItem, Me.UsersToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(188, 22)
        Me.ToolStripMenuItem1.Text = "Database"
        '
        'StatisticsToolStripMenuItem
        '
        Me.StatisticsToolStripMenuItem.Name = "StatisticsToolStripMenuItem"
        Me.StatisticsToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.StatisticsToolStripMenuItem.Text = "Statistics..."
        '
        'UsersToolStripMenuItem
        '
        Me.UsersToolStripMenuItem.Name = "UsersToolStripMenuItem"
        Me.UsersToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.UsersToolStripMenuItem.Text = "Users..."
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Enabled = False
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(188, 22)
        Me.ToolStripMenuItem3.Text = "Print"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NormalPrinterToolStripMenuItem, Me.ImagePrinterToolStripMenuItem, Me.TestPrintToolStripMenuItem})
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(188, 22)
        Me.ToolStripMenuItem4.Text = "Print Setup"
        '
        'NormalPrinterToolStripMenuItem
        '
        Me.NormalPrinterToolStripMenuItem.Name = "NormalPrinterToolStripMenuItem"
        Me.NormalPrinterToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.NormalPrinterToolStripMenuItem.Text = "Normal Printer"
        '
        'ImagePrinterToolStripMenuItem
        '
        Me.ImagePrinterToolStripMenuItem.Name = "ImagePrinterToolStripMenuItem"
        Me.ImagePrinterToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ImagePrinterToolStripMenuItem.Text = "Image Printer"
        '
        'TestPrintToolStripMenuItem
        '
        Me.TestPrintToolStripMenuItem.Name = "TestPrintToolStripMenuItem"
        Me.TestPrintToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.TestPrintToolStripMenuItem.Text = "Test Print"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(188, 22)
        Me.ToolStripMenuItem5.Text = "Shut Down"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusViewToolStripMenuItem, Me.SplitScreenToolStripMenuItem, Me.FullViewAreaToolStripMenuItem, Me.FullScreenToolStripMenuItem, Me.ToOtherMonitorToolStripMenuItem, Me.MeasurementsToolStripMenuItem, Me.ViewMakersToolStripMenuItem, Me.BlinkMakersToolStripMenuItem})
        Me.ViewToolStripMenuItem.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.ViewToolStripMenuItem.Text = "&View"
        '
        'StatusViewToolStripMenuItem
        '
        Me.StatusViewToolStripMenuItem.Name = "StatusViewToolStripMenuItem"
        Me.StatusViewToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.StatusViewToolStripMenuItem.Text = "Home View"
        '
        'SplitScreenToolStripMenuItem
        '
        Me.SplitScreenToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ScreenToolStripMenuItem, Me.ScreenToolStripMenuItem2, Me.X4GridToolStripMenuItem, Me.FullMouthSeriesViewToolStripMenuItem})
        Me.SplitScreenToolStripMenuItem.Name = "SplitScreenToolStripMenuItem"
        Me.SplitScreenToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.SplitScreenToolStripMenuItem.Text = "Image Layout"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(215, 22)
        Me.ToolStripMenuItem2.Text = "2 Horizontal"
        '
        'ScreenToolStripMenuItem
        '
        Me.ScreenToolStripMenuItem.Name = "ScreenToolStripMenuItem"
        Me.ScreenToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.ScreenToolStripMenuItem.Text = "2 x 2 Grid"
        '
        'ScreenToolStripMenuItem2
        '
        Me.ScreenToolStripMenuItem2.Name = "ScreenToolStripMenuItem2"
        Me.ScreenToolStripMenuItem2.Size = New System.Drawing.Size(215, 22)
        Me.ScreenToolStripMenuItem2.Text = "3 X 3 Grid"
        '
        'X4GridToolStripMenuItem
        '
        Me.X4GridToolStripMenuItem.Name = "X4GridToolStripMenuItem"
        Me.X4GridToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.X4GridToolStripMenuItem.Text = "4 X 4 Grid"
        '
        'FullMouthSeriesViewToolStripMenuItem
        '
        Me.FullMouthSeriesViewToolStripMenuItem.Name = "FullMouthSeriesViewToolStripMenuItem"
        Me.FullMouthSeriesViewToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.FullMouthSeriesViewToolStripMenuItem.Text = "Full Mouth Series View"
        '
        'FullViewAreaToolStripMenuItem
        '
        Me.FullViewAreaToolStripMenuItem.Name = "FullViewAreaToolStripMenuItem"
        Me.FullViewAreaToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.FullViewAreaToolStripMenuItem.Text = "Larger View"
        '
        'FullScreenToolStripMenuItem
        '
        Me.FullScreenToolStripMenuItem.Name = "FullScreenToolStripMenuItem"
        Me.FullScreenToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.FullScreenToolStripMenuItem.Text = "Full Screen"
        '
        'ToOtherMonitorToolStripMenuItem
        '
        Me.ToOtherMonitorToolStripMenuItem.Name = "ToOtherMonitorToolStripMenuItem"
        Me.ToOtherMonitorToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ToOtherMonitorToolStripMenuItem.Text = "Swap Monitor"
        '
        'MeasurementsToolStripMenuItem
        '
        Me.MeasurementsToolStripMenuItem.Enabled = False
        Me.MeasurementsToolStripMenuItem.Name = "MeasurementsToolStripMenuItem"
        Me.MeasurementsToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.MeasurementsToolStripMenuItem.Text = "Show Measurements"
        '
        'ViewMakersToolStripMenuItem
        '
        Me.ViewMakersToolStripMenuItem.Enabled = False
        Me.ViewMakersToolStripMenuItem.Name = "ViewMakersToolStripMenuItem"
        Me.ViewMakersToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ViewMakersToolStripMenuItem.Text = "Show Pins"
        '
        'BlinkMakersToolStripMenuItem
        '
        Me.BlinkMakersToolStripMenuItem.Enabled = False
        Me.BlinkMakersToolStripMenuItem.Name = "BlinkMakersToolStripMenuItem"
        Me.BlinkMakersToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.BlinkMakersToolStripMenuItem.Text = "Flashing Pins"
        '
        'ImageToolStripMenuItem
        '
        Me.ImageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewImageToolStripMenuItem, Me.VideoToolStripMenuItem, Me.ScannerToolStripMenuItem, Me.ImportToolStripMenuItem, Me.ExportOriginalToolStripMenuItem, Me.ExportProcessedToolStripMenuItem, Me.DeleteToolStripMenuItem1, Me.CopyToolStripMenuItem, Me.DuplicateToolStripMenuItem, Me.ToothWhitenerToolStripMenuItem, Me.ResetAllToolStripMenuItem, Me.RotateMirrirToolStripMenuItem, Me.EffectsToolStripMenuItem, Me.InteractiveContrastToolStripMenuItem, Me.ContrastToolStripMenuItem, Me.HistogramToolStripMenuItem, Me.SubtractToolStripMenuItem, Me.ImagePropertiesToolStripMenuItem})
        Me.ImageToolStripMenuItem.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ImageToolStripMenuItem.Name = "ImageToolStripMenuItem"
        Me.ImageToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.ImageToolStripMenuItem.Text = "&Image"
        '
        'NewImageToolStripMenuItem
        '
        Me.NewImageToolStripMenuItem.Name = "NewImageToolStripMenuItem"
        Me.NewImageToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.NewImageToolStripMenuItem.Text = "New Image"
        '
        'VideoToolStripMenuItem
        '
        Me.VideoToolStripMenuItem.Enabled = False
        Me.VideoToolStripMenuItem.Name = "VideoToolStripMenuItem"
        Me.VideoToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.VideoToolStripMenuItem.Text = "Video"
        '
        'ScannerToolStripMenuItem
        '
        Me.ScannerToolStripMenuItem.Enabled = False
        Me.ScannerToolStripMenuItem.Name = "ScannerToolStripMenuItem"
        Me.ScannerToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ScannerToolStripMenuItem.Text = "Scanner"
        '
        'ImportToolStripMenuItem
        '
        Me.ImportToolStripMenuItem.Name = "ImportToolStripMenuItem"
        Me.ImportToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ImportToolStripMenuItem.Text = "Import"
        '
        'ExportOriginalToolStripMenuItem
        '
        Me.ExportOriginalToolStripMenuItem.Enabled = False
        Me.ExportOriginalToolStripMenuItem.Name = "ExportOriginalToolStripMenuItem"
        Me.ExportOriginalToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ExportOriginalToolStripMenuItem.Text = "Export Image"
        '
        'ExportProcessedToolStripMenuItem
        '
        Me.ExportProcessedToolStripMenuItem.Enabled = False
        Me.ExportProcessedToolStripMenuItem.Name = "ExportProcessedToolStripMenuItem"
        Me.ExportProcessedToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ExportProcessedToolStripMenuItem.Text = "Export Image with Changes"
        '
        'DeleteToolStripMenuItem1
        '
        Me.DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1"
        Me.DeleteToolStripMenuItem1.Size = New System.Drawing.Size(250, 22)
        Me.DeleteToolStripMenuItem1.Text = "Delete"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Enabled = False
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'DuplicateToolStripMenuItem
        '
        Me.DuplicateToolStripMenuItem.Enabled = False
        Me.DuplicateToolStripMenuItem.Name = "DuplicateToolStripMenuItem"
        Me.DuplicateToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.DuplicateToolStripMenuItem.Text = "Duplicate"
        '
        'ToothWhitenerToolStripMenuItem
        '
        Me.ToothWhitenerToolStripMenuItem.Enabled = False
        Me.ToothWhitenerToolStripMenuItem.Name = "ToothWhitenerToolStripMenuItem"
        Me.ToothWhitenerToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ToothWhitenerToolStripMenuItem.Text = "Tooth Whitener"
        '
        'ResetAllToolStripMenuItem
        '
        Me.ResetAllToolStripMenuItem.Name = "ResetAllToolStripMenuItem"
        Me.ResetAllToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ResetAllToolStripMenuItem.Text = "Reset All"
        '
        'RotateMirrirToolStripMenuItem
        '
        Me.RotateMirrirToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Rotate90ToolStripMenuItem, Me.Rotate180ToolStripMenuItem, Me.Rotate270ToolStripMenuItem, Me.MirrorXToolStripMenuItem, Me.MirrorYToolStripMenuItem})
        Me.RotateMirrirToolStripMenuItem.Name = "RotateMirrirToolStripMenuItem"
        Me.RotateMirrirToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.RotateMirrirToolStripMenuItem.Text = "Rotate / Flip"
        '
        'Rotate90ToolStripMenuItem
        '
        Me.Rotate90ToolStripMenuItem.Name = "Rotate90ToolStripMenuItem"
        Me.Rotate90ToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.Rotate90ToolStripMenuItem.Text = "Rotate 90º"
        '
        'Rotate180ToolStripMenuItem
        '
        Me.Rotate180ToolStripMenuItem.Name = "Rotate180ToolStripMenuItem"
        Me.Rotate180ToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.Rotate180ToolStripMenuItem.Text = "Rotate 180º"
        '
        'Rotate270ToolStripMenuItem
        '
        Me.Rotate270ToolStripMenuItem.Name = "Rotate270ToolStripMenuItem"
        Me.Rotate270ToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.Rotate270ToolStripMenuItem.Text = "Rotate 270º"
        '
        'MirrorXToolStripMenuItem
        '
        Me.MirrorXToolStripMenuItem.Name = "MirrorXToolStripMenuItem"
        Me.MirrorXToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.MirrorXToolStripMenuItem.Text = "Flip Horizontal"
        '
        'MirrorYToolStripMenuItem
        '
        Me.MirrorYToolStripMenuItem.Name = "MirrorYToolStripMenuItem"
        Me.MirrorYToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.MirrorYToolStripMenuItem.Text = "Flip Vertical"
        '
        'EffectsToolStripMenuItem
        '
        Me.EffectsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NegativeToolStripMenuItem, Me.PseudoToolStripMenuItem, Me.SharpenToolStripMenuItem, Me.SmoothenToolStripMenuItem, Me.MediaFilterToolStripMenuItem, Me.SofttissueFilterToolStripMenuItem})
        Me.EffectsToolStripMenuItem.Name = "EffectsToolStripMenuItem"
        Me.EffectsToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.EffectsToolStripMenuItem.Text = "Effects"
        '
        'NegativeToolStripMenuItem
        '
        Me.NegativeToolStripMenuItem.Name = "NegativeToolStripMenuItem"
        Me.NegativeToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.NegativeToolStripMenuItem.Text = "Negative"
        '
        'PseudoToolStripMenuItem
        '
        Me.PseudoToolStripMenuItem.Enabled = False
        Me.PseudoToolStripMenuItem.Name = "PseudoToolStripMenuItem"
        Me.PseudoToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.PseudoToolStripMenuItem.Text = "Pseudo"
        '
        'SharpenToolStripMenuItem
        '
        Me.SharpenToolStripMenuItem.Name = "SharpenToolStripMenuItem"
        Me.SharpenToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.SharpenToolStripMenuItem.Text = "Sharpen"
        '
        'SmoothenToolStripMenuItem
        '
        Me.SmoothenToolStripMenuItem.Name = "SmoothenToolStripMenuItem"
        Me.SmoothenToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.SmoothenToolStripMenuItem.Text = "Smoothen"
        '
        'MediaFilterToolStripMenuItem
        '
        Me.MediaFilterToolStripMenuItem.Name = "MediaFilterToolStripMenuItem"
        Me.MediaFilterToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.MediaFilterToolStripMenuItem.Text = "Media Filter"
        '
        'SofttissueFilterToolStripMenuItem
        '
        Me.SofttissueFilterToolStripMenuItem.Enabled = False
        Me.SofttissueFilterToolStripMenuItem.Name = "SofttissueFilterToolStripMenuItem"
        Me.SofttissueFilterToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.SofttissueFilterToolStripMenuItem.Text = "Soft-tissue Filter"
        '
        'InteractiveContrastToolStripMenuItem
        '
        Me.InteractiveContrastToolStripMenuItem.Enabled = False
        Me.InteractiveContrastToolStripMenuItem.Name = "InteractiveContrastToolStripMenuItem"
        Me.InteractiveContrastToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.InteractiveContrastToolStripMenuItem.Text = "Interactive Contrast"
        '
        'ContrastToolStripMenuItem
        '
        Me.ContrastToolStripMenuItem.Name = "ContrastToolStripMenuItem"
        Me.ContrastToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ContrastToolStripMenuItem.Text = "Contrast"
        '
        'HistogramToolStripMenuItem
        '
        Me.HistogramToolStripMenuItem.Name = "HistogramToolStripMenuItem"
        Me.HistogramToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.HistogramToolStripMenuItem.Text = "Histogram"
        '
        'SubtractToolStripMenuItem
        '
        Me.SubtractToolStripMenuItem.Enabled = False
        Me.SubtractToolStripMenuItem.Name = "SubtractToolStripMenuItem"
        Me.SubtractToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.SubtractToolStripMenuItem.Text = "Subtract"
        '
        'ImagePropertiesToolStripMenuItem
        '
        Me.ImagePropertiesToolStripMenuItem.Name = "ImagePropertiesToolStripMenuItem"
        Me.ImagePropertiesToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.ImagePropertiesToolStripMenuItem.Text = "Image Properties"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationSettingsToolStripMenuItem, Me.DatabaseSettingsToolStripMenuItem, Me.ExternalApplicationSettingsToolStripMenuItem, Me.CommunicationSettingsToolStripMenuItem, Me.DeviceSettingsToolStripMenuItem, Me.XRaySettingsToolStripMenuItem, Me.UserWithPrivateSettingsToolStripMenuItem, Me.WaitingRoomToolStripMenuItem, Me.SendNotesToolStripMenuItem, Me.OpenMeasurementsToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.ToolsToolStripMenuItem.Text = "&Tools"
        '
        'ApplicationSettingsToolStripMenuItem
        '
        Me.ApplicationSettingsToolStripMenuItem.Name = "ApplicationSettingsToolStripMenuItem"
        Me.ApplicationSettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.ApplicationSettingsToolStripMenuItem.Text = "Application Settings"
        '
        'DatabaseSettingsToolStripMenuItem
        '
        Me.DatabaseSettingsToolStripMenuItem.Name = "DatabaseSettingsToolStripMenuItem"
        Me.DatabaseSettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.DatabaseSettingsToolStripMenuItem.Text = "Database Settings"
        '
        'ExternalApplicationSettingsToolStripMenuItem
        '
        Me.ExternalApplicationSettingsToolStripMenuItem.Name = "ExternalApplicationSettingsToolStripMenuItem"
        Me.ExternalApplicationSettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.ExternalApplicationSettingsToolStripMenuItem.Text = "External Application Settings"
        '
        'CommunicationSettingsToolStripMenuItem
        '
        Me.CommunicationSettingsToolStripMenuItem.Name = "CommunicationSettingsToolStripMenuItem"
        Me.CommunicationSettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.CommunicationSettingsToolStripMenuItem.Text = "Communication Settings"
        '
        'DeviceSettingsToolStripMenuItem
        '
        Me.DeviceSettingsToolStripMenuItem.Name = "DeviceSettingsToolStripMenuItem"
        Me.DeviceSettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.DeviceSettingsToolStripMenuItem.Text = "Device Settings"
        '
        'XRaySettingsToolStripMenuItem
        '
        Me.XRaySettingsToolStripMenuItem.Name = "XRaySettingsToolStripMenuItem"
        Me.XRaySettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.XRaySettingsToolStripMenuItem.Text = "X-Ray Settings"
        '
        'UserWithPrivateSettingsToolStripMenuItem
        '
        Me.UserWithPrivateSettingsToolStripMenuItem.Name = "UserWithPrivateSettingsToolStripMenuItem"
        Me.UserWithPrivateSettingsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.UserWithPrivateSettingsToolStripMenuItem.Text = "User with Private Settings"
        '
        'WaitingRoomToolStripMenuItem
        '
        Me.WaitingRoomToolStripMenuItem.Enabled = False
        Me.WaitingRoomToolStripMenuItem.Name = "WaitingRoomToolStripMenuItem"
        Me.WaitingRoomToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.WaitingRoomToolStripMenuItem.Text = "Waiting Room"
        '
        'SendNotesToolStripMenuItem
        '
        Me.SendNotesToolStripMenuItem.Enabled = False
        Me.SendNotesToolStripMenuItem.Name = "SendNotesToolStripMenuItem"
        Me.SendNotesToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.SendNotesToolStripMenuItem.Text = "Send Notes"
        '
        'OpenMeasurementsToolStripMenuItem
        '
        Me.OpenMeasurementsToolStripMenuItem.Enabled = False
        Me.OpenMeasurementsToolStripMenuItem.Name = "OpenMeasurementsToolStripMenuItem"
        Me.OpenMeasurementsToolStripMenuItem.Size = New System.Drawing.Size(254, 22)
        Me.OpenMeasurementsToolStripMenuItem.Text = "Open Measurements"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem, Me.CloseAllToolStripMenuItem, Me.ToolStripSeparator1, Me.FullScreenToolStripMenuItem1, Me.ToolStripSeparator2, Me.ResetAllToolStripMenuItem1, Me.ResetContrastToolStripMenuItem, Me.ResetZoomToolStripMenuItem, Me.ToolStripSeparator3, Me.Rotate90ToolStripMenuItem1, Me.Rotate180ºToolStripMenuItem, Me.Rotate270ºToolStripMenuItem, Me.MirrorXToolStripMenuItem1, Me.MirrorYToolStripMenuItem1, Me.ToolStripSeparator4, Me.ColorBrandingToolStripMenuItem, Me.ColorDiferencingToolStripMenuItem, Me.SofttissueFilterToolStripMenuItem1, Me.ToolStripSeparator5, Me.HistogramToolStripMenuItem1, Me.ToolStripSeparator6, Me.PropertiesToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(187, 392)
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'CloseAllToolStripMenuItem
        '
        Me.CloseAllToolStripMenuItem.Name = "CloseAllToolStripMenuItem"
        Me.CloseAllToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.CloseAllToolStripMenuItem.Text = "Close All"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(183, 6)
        '
        'FullScreenToolStripMenuItem1
        '
        Me.FullScreenToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FullScreenToolStripMenuItem1.Name = "FullScreenToolStripMenuItem1"
        Me.FullScreenToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.FullScreenToolStripMenuItem1.Text = "Full Screen"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(183, 6)
        '
        'ResetAllToolStripMenuItem1
        '
        Me.ResetAllToolStripMenuItem1.Name = "ResetAllToolStripMenuItem1"
        Me.ResetAllToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.ResetAllToolStripMenuItem1.Text = "Reset All"
        '
        'ResetContrastToolStripMenuItem
        '
        Me.ResetContrastToolStripMenuItem.Name = "ResetContrastToolStripMenuItem"
        Me.ResetContrastToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ResetContrastToolStripMenuItem.Text = "Reset Contrast"
        '
        'ResetZoomToolStripMenuItem
        '
        Me.ResetZoomToolStripMenuItem.Name = "ResetZoomToolStripMenuItem"
        Me.ResetZoomToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ResetZoomToolStripMenuItem.Text = "Reset Zoom"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(183, 6)
        '
        'Rotate90ToolStripMenuItem1
        '
        Me.Rotate90ToolStripMenuItem1.Name = "Rotate90ToolStripMenuItem1"
        Me.Rotate90ToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.Rotate90ToolStripMenuItem1.Text = "Rotate 90º"
        '
        'Rotate180ºToolStripMenuItem
        '
        Me.Rotate180ºToolStripMenuItem.Name = "Rotate180ºToolStripMenuItem"
        Me.Rotate180ºToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.Rotate180ºToolStripMenuItem.Text = "Rotate 180º"
        '
        'Rotate270ºToolStripMenuItem
        '
        Me.Rotate270ºToolStripMenuItem.Name = "Rotate270ºToolStripMenuItem"
        Me.Rotate270ºToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.Rotate270ºToolStripMenuItem.Text = "Rotate 270º"
        '
        'MirrorXToolStripMenuItem1
        '
        Me.MirrorXToolStripMenuItem1.Name = "MirrorXToolStripMenuItem1"
        Me.MirrorXToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.MirrorXToolStripMenuItem1.Text = "Flip Horizontal"
        '
        'MirrorYToolStripMenuItem1
        '
        Me.MirrorYToolStripMenuItem1.Name = "MirrorYToolStripMenuItem1"
        Me.MirrorYToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.MirrorYToolStripMenuItem1.Text = "Flip Vertical"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(183, 6)
        '
        'ColorBrandingToolStripMenuItem
        '
        Me.ColorBrandingToolStripMenuItem.Name = "ColorBrandingToolStripMenuItem"
        Me.ColorBrandingToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ColorBrandingToolStripMenuItem.Text = "Color banding"
        '
        'ColorDiferencingToolStripMenuItem
        '
        Me.ColorDiferencingToolStripMenuItem.Name = "ColorDiferencingToolStripMenuItem"
        Me.ColorDiferencingToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ColorDiferencingToolStripMenuItem.Text = "Color Diferencing"
        '
        'SofttissueFilterToolStripMenuItem1
        '
        Me.SofttissueFilterToolStripMenuItem1.Name = "SofttissueFilterToolStripMenuItem1"
        Me.SofttissueFilterToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.SofttissueFilterToolStripMenuItem1.Text = "Soft-tissue filter..."
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(183, 6)
        '
        'HistogramToolStripMenuItem1
        '
        Me.HistogramToolStripMenuItem1.Name = "HistogramToolStripMenuItem1"
        Me.HistogramToolStripMenuItem1.Size = New System.Drawing.Size(186, 22)
        Me.HistogramToolStripMenuItem1.Text = "Histogram"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(183, 6)
        '
        'PropertiesToolStripMenuItem
        '
        Me.PropertiesToolStripMenuItem.Name = "PropertiesToolStripMenuItem"
        Me.PropertiesToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.PropertiesToolStripMenuItem.Text = "Properties"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(25, 25)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton6, Me.ToolStripButton2, Me.ToolStripButton3, Me.ToolStripButton4, Me.ToolStripButton5, Me.ToolStripButton1, Me.ToolStripButton7, Me.ToolStripButton8, Me.ToolStripButton9, Me.ToolStripButton11, Me.ToolStripButton12, Me.ToolStripButton13, Me.ToolStripButton14, Me.ToolStripButton19, Me.ToolStripButton15, Me.ToolStripButton16, Me.ToolStripButton17, Me.ToolStripButton18, Me.ToolStripButton21, Me.ToolStripButton20, Me.ToolStripButton22, Me.ToolStripButton23, Me.ToolStripButton24, Me.ToolStripButton26})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1370, 47)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton6.Text = "Home View"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton2.Text = "Full Mouth Series View"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton3.Text = "COLOR IMAGE STATUS"
        Me.ToolStripButton3.Visible = False
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton4.Text = "Implant View"
        Me.ToolStripButton4.Visible = False
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), System.Drawing.Image)
        Me.ToolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton5.Text = "Ortho View"
        Me.ToolStripButton5.Visible = False
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton1.Text = "Documents"
        Me.ToolStripButton1.Visible = False
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton7.Image = CType(resources.GetObject("ToolStripButton7.Image"), System.Drawing.Image)
        Me.ToolStripButton7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton7.Text = "Patient Files"
        '
        'ToolStripButton8
        '
        Me.ToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton8.Image = CType(resources.GetObject("ToolStripButton8.Image"), System.Drawing.Image)
        Me.ToolStripButton8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton8.Name = "ToolStripButton8"
        Me.ToolStripButton8.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton8.Text = "Bitewing View"
        '
        'ToolStripButton9
        '
        Me.ToolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton9.Image = CType(resources.GetObject("ToolStripButton9.Image"), System.Drawing.Image)
        Me.ToolStripButton9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton9.Name = "ToolStripButton9"
        Me.ToolStripButton9.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton9.Text = "Print"
        '
        'ToolStripButton11
        '
        Me.ToolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton11.Image = CType(resources.GetObject("ToolStripButton11.Image"), System.Drawing.Image)
        Me.ToolStripButton11.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton11.Name = "ToolStripButton11"
        Me.ToolStripButton11.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton11.Text = "Email"
        '
        'ToolStripButton12
        '
        Me.ToolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton12.Image = CType(resources.GetObject("ToolStripButton12.Image"), System.Drawing.Image)
        Me.ToolStripButton12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton12.Name = "ToolStripButton12"
        Me.ToolStripButton12.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton12.Text = "Edit Image"
        '
        'ToolStripButton13
        '
        Me.ToolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton13.Image = CType(resources.GetObject("ToolStripButton13.Image"), System.Drawing.Image)
        Me.ToolStripButton13.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton13.Name = "ToolStripButton13"
        Me.ToolStripButton13.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton13.Text = "Tooth Whitening"
        '
        'ToolStripButton14
        '
        Me.ToolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton14.Image = CType(resources.GetObject("ToolStripButton14.Image"), System.Drawing.Image)
        Me.ToolStripButton14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton14.Name = "ToolStripButton14"
        Me.ToolStripButton14.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton14.Text = "Intra-Oral Camera"
        '
        'ToolStripButton19
        '
        Me.ToolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton19.Image = CType(resources.GetObject("ToolStripButton19.Image"), System.Drawing.Image)
        Me.ToolStripButton19.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton19.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton19.Name = "ToolStripButton19"
        Me.ToolStripButton19.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton19.Text = "Scanner"
        '
        'ToolStripButton15
        '
        Me.ToolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton15.Image = CType(resources.GetObject("ToolStripButton15.Image"), System.Drawing.Image)
        Me.ToolStripButton15.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton15.Name = "ToolStripButton15"
        Me.ToolStripButton15.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton15.Text = "Obtain X-Ray"
        '
        'ToolStripButton16
        '
        Me.ToolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton16.Image = CType(resources.GetObject("ToolStripButton16.Image"), System.Drawing.Image)
        Me.ToolStripButton16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton16.Name = "ToolStripButton16"
        Me.ToolStripButton16.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton16.Text = "Negative"
        '
        'ToolStripButton17
        '
        Me.ToolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton17.Image = CType(resources.GetObject("ToolStripButton17.Image"), System.Drawing.Image)
        Me.ToolStripButton17.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton17.Name = "ToolStripButton17"
        Me.ToolStripButton17.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton17.Text = "Sharpness"
        '
        'ToolStripButton18
        '
        Me.ToolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton18.Image = CType(resources.GetObject("ToolStripButton18.Image"), System.Drawing.Image)
        Me.ToolStripButton18.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton18.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton18.Name = "ToolStripButton18"
        Me.ToolStripButton18.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton18.Text = "Smooth"
        '
        'ToolStripButton21
        '
        Me.ToolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton21.Image = CType(resources.GetObject("ToolStripButton21.Image"), System.Drawing.Image)
        Me.ToolStripButton21.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton21.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton21.Name = "ToolStripButton21"
        Me.ToolStripButton21.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton21.Text = "Contrast"
        '
        'ToolStripButton20
        '
        Me.ToolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton20.Image = CType(resources.GetObject("ToolStripButton20.Image"), System.Drawing.Image)
        Me.ToolStripButton20.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton20.Name = "ToolStripButton20"
        Me.ToolStripButton20.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton20.Text = "Brightness"
        '
        'ToolStripButton22
        '
        Me.ToolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton22.Image = CType(resources.GetObject("ToolStripButton22.Image"), System.Drawing.Image)
        Me.ToolStripButton22.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton22.Name = "ToolStripButton22"
        Me.ToolStripButton22.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton22.Text = "Zoom In"
        '
        'ToolStripButton23
        '
        Me.ToolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton23.Image = CType(resources.GetObject("ToolStripButton23.Image"), System.Drawing.Image)
        Me.ToolStripButton23.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton23.Name = "ToolStripButton23"
        Me.ToolStripButton23.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton23.Text = "Zoom Out"
        '
        'ToolStripButton24
        '
        Me.ToolStripButton24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton24.Image = CType(resources.GetObject("ToolStripButton24.Image"), System.Drawing.Image)
        Me.ToolStripButton24.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton24.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton24.Name = "ToolStripButton24"
        Me.ToolStripButton24.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton24.Text = "Measure"
        '
        'ToolStripButton26
        '
        Me.ToolStripButton26.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton26.Image = CType(resources.GetObject("ToolStripButton26.Image"), System.Drawing.Image)
        Me.ToolStripButton26.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripButton26.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton26.Name = "ToolStripButton26"
        Me.ToolStripButton26.Size = New System.Drawing.Size(44, 44)
        Me.ToolStripButton26.Text = "Delete"
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.ContentPanel
        '
        Me.ToolStripContainer1.ContentPanel.Size = New System.Drawing.Size(150, 150)
        Me.ToolStripContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        Me.ToolStripContainer1.Size = New System.Drawing.Size(150, 175)
        Me.ToolStripContainer1.TabIndex = 0
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Size = New System.Drawing.Size(150, 100)
        Me.SplitContainer1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.GroupBox2)
        Me.Panel2.Location = New System.Drawing.Point(0, 74)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(110, 149)
        Me.Panel2.TabIndex = 5
        '
        'GroupBox2
        '
        Me.GroupBox2.AutoSize = True
        Me.GroupBox2.Controls.Add(Me.btnImport)
        Me.GroupBox2.Location = New System.Drawing.Point(-6, -6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(114, 137)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        '
        'btnImport
        '
        Me.btnImport.Location = New System.Drawing.Point(14, 17)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(75, 23)
        Me.btnImport.TabIndex = 0
        Me.btnImport.Text = "Import..."
        Me.btnImport.UseVisualStyleBackColor = True
        Me.btnImport.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Controls.Add(Me.grp1X)
        Me.Panel3.Controls.Add(Me.grp2X)
        Me.Panel3.Controls.Add(Me.grp9X)
        Me.Panel3.Controls.Add(Me.grp4X)
        Me.Panel3.Controls.Add(Me.grpViewer)
        Me.Panel3.Controls.Add(Me.grp16X)
        Me.Panel3.Controls.Add(Me.grpFullMouth)
        Me.Panel3.Controls.Add(Me.GroupBox3)
        Me.Panel3.Location = New System.Drawing.Point(110, 72)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(310, 150)
        Me.Panel3.TabIndex = 6
        '
        'grp1X
        '
        Me.grp1X.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grp1X.Controls.Add(Me.Pnl_1X1)
        Me.grp1X.Location = New System.Drawing.Point(-2, 18)
        Me.grp1X.Name = "grp1X"
        Me.grp1X.Size = New System.Drawing.Size(233, 100)
        Me.grp1X.TabIndex = 14
        Me.grp1X.TabStop = False
        Me.grp1X.Visible = False
        '
        'Pnl_1X1
        '
        Me.Pnl_1X1.AutoScroll = True
        Me.Pnl_1X1.AutoScrollMinSize = New System.Drawing.Size(610, 600)
        Me.Pnl_1X1.Controls.Add(Me.Pic_1_grp1X)
        Me.Pnl_1X1.Location = New System.Drawing.Point(6, 14)
        Me.Pnl_1X1.Name = "Pnl_1X1"
        Me.Pnl_1X1.Size = New System.Drawing.Size(132, 63)
        Me.Pnl_1X1.TabIndex = 20
        '
        'Pic_1_grp1X
        '
        Me.Pic_1_grp1X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Pic_1_grp1X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pic_1_grp1X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Pic_1_grp1X.Location = New System.Drawing.Point(3, 3)
        Me.Pic_1_grp1X.Name = "Pic_1_grp1X"
        Me.Pic_1_grp1X.Size = New System.Drawing.Size(123, 55)
        Me.Pic_1_grp1X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_1_grp1X.TabIndex = 20
        Me.Pic_1_grp1X.TabStop = False
        '
        'grp2X
        '
        Me.grp2X.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grp2X.Controls.Add(Me.Pnl_2X2)
        Me.grp2X.Controls.Add(Me.Pnl_2X1)
        Me.grp2X.Location = New System.Drawing.Point(-2, 18)
        Me.grp2X.Name = "grp2X"
        Me.grp2X.Size = New System.Drawing.Size(233, 100)
        Me.grp2X.TabIndex = 7
        Me.grp2X.TabStop = False
        Me.grp2X.Visible = False
        '
        'Pnl_2X2
        '
        Me.Pnl_2X2.AutoScroll = True
        Me.Pnl_2X2.Controls.Add(Me.pic_2_grp2X)
        Me.Pnl_2X2.Location = New System.Drawing.Point(83, 14)
        Me.Pnl_2X2.Name = "Pnl_2X2"
        Me.Pnl_2X2.Size = New System.Drawing.Size(124, 62)
        Me.Pnl_2X2.TabIndex = 21
        '
        'pic_2_grp2X
        '
        Me.pic_2_grp2X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_2_grp2X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_2_grp2X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_2_grp2X.Location = New System.Drawing.Point(6, 6)
        Me.pic_2_grp2X.Name = "pic_2_grp2X"
        Me.pic_2_grp2X.Size = New System.Drawing.Size(116, 50)
        Me.pic_2_grp2X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_2_grp2X.TabIndex = 2
        Me.pic_2_grp2X.TabStop = False
        '
        'Pnl_2X1
        '
        Me.Pnl_2X1.AutoScroll = True
        Me.Pnl_2X1.AutoScrollMinSize = New System.Drawing.Size(610, 600)
        Me.Pnl_2X1.Controls.Add(Me.pic_1_grp2X)
        Me.Pnl_2X1.Location = New System.Drawing.Point(6, 14)
        Me.Pnl_2X1.Name = "Pnl_2X1"
        Me.Pnl_2X1.Size = New System.Drawing.Size(132, 63)
        Me.Pnl_2X1.TabIndex = 20
        '
        'pic_1_grp2X
        '
        Me.pic_1_grp2X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_1_grp2X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_1_grp2X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_1_grp2X.Location = New System.Drawing.Point(3, 3)
        Me.pic_1_grp2X.Name = "pic_1_grp2X"
        Me.pic_1_grp2X.Size = New System.Drawing.Size(123, 55)
        Me.pic_1_grp2X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_1_grp2X.TabIndex = 20
        Me.pic_1_grp2X.TabStop = False
        '
        'grp9X
        '
        Me.grp9X.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grp9X.Controls.Add(Me.Pnl_9X9)
        Me.grp9X.Controls.Add(Me.Pnl_9X6)
        Me.grp9X.Controls.Add(Me.Pnl_9X3)
        Me.grp9X.Controls.Add(Me.Pnl_9X8)
        Me.grp9X.Controls.Add(Me.Pnl_9X5)
        Me.grp9X.Controls.Add(Me.Pnl_9X2)
        Me.grp9X.Controls.Add(Me.Pnl_9X7)
        Me.grp9X.Controls.Add(Me.Pnl_9X4)
        Me.grp9X.Controls.Add(Me.Pnl_9X1)
        Me.grp9X.Location = New System.Drawing.Point(-2, 10)
        Me.grp9X.Name = "grp9X"
        Me.grp9X.Size = New System.Drawing.Size(233, 100)
        Me.grp9X.TabIndex = 9
        Me.grp9X.TabStop = False
        Me.grp9X.Visible = False
        '
        'Pnl_9X9
        '
        Me.Pnl_9X9.AutoScroll = True
        Me.Pnl_9X9.Controls.Add(Me.pic_9_grp9x)
        Me.Pnl_9X9.Location = New System.Drawing.Point(64, 37)
        Me.Pnl_9X9.Name = "Pnl_9X9"
        Me.Pnl_9X9.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X9.TabIndex = 28
        '
        'pic_9_grp9x
        '
        Me.pic_9_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_9_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_9_grp9x.Location = New System.Drawing.Point(5, 7)
        Me.pic_9_grp9x.Name = "pic_9_grp9x"
        Me.pic_9_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_9_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_9_grp9x.TabIndex = 8
        Me.pic_9_grp9x.TabStop = False
        '
        'Pnl_9X6
        '
        Me.Pnl_9X6.AutoScroll = True
        Me.Pnl_9X6.Controls.Add(Me.pic_6_grp9x)
        Me.Pnl_9X6.Location = New System.Drawing.Point(64, 24)
        Me.Pnl_9X6.Name = "Pnl_9X6"
        Me.Pnl_9X6.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X6.TabIndex = 28
        '
        'pic_6_grp9x
        '
        Me.pic_6_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_6_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_6_grp9x.Location = New System.Drawing.Point(5, 7)
        Me.pic_6_grp9x.Name = "pic_6_grp9x"
        Me.pic_6_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_6_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_6_grp9x.TabIndex = 7
        Me.pic_6_grp9x.TabStop = False
        '
        'Pnl_9X3
        '
        Me.Pnl_9X3.AutoScroll = True
        Me.Pnl_9X3.Controls.Add(Me.pic_3_grp9x)
        Me.Pnl_9X3.Location = New System.Drawing.Point(64, 13)
        Me.Pnl_9X3.Name = "Pnl_9X3"
        Me.Pnl_9X3.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X3.TabIndex = 30
        '
        'pic_3_grp9x
        '
        Me.pic_3_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_3_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_3_grp9x.Location = New System.Drawing.Point(5, 7)
        Me.pic_3_grp9x.Name = "pic_3_grp9x"
        Me.pic_3_grp9x.Size = New System.Drawing.Size(116, 50)
        Me.pic_3_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_3_grp9x.TabIndex = 6
        Me.pic_3_grp9x.TabStop = False
        '
        'Pnl_9X8
        '
        Me.Pnl_9X8.AutoScroll = True
        Me.Pnl_9X8.Controls.Add(Me.pic_8_grp9x)
        Me.Pnl_9X8.Location = New System.Drawing.Point(33, 37)
        Me.Pnl_9X8.Name = "Pnl_9X8"
        Me.Pnl_9X8.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X8.TabIndex = 29
        '
        'pic_8_grp9x
        '
        Me.pic_8_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_8_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_8_grp9x.Location = New System.Drawing.Point(4, 7)
        Me.pic_8_grp9x.Name = "pic_8_grp9x"
        Me.pic_8_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_8_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_8_grp9x.TabIndex = 5
        Me.pic_8_grp9x.TabStop = False
        '
        'Pnl_9X5
        '
        Me.Pnl_9X5.AutoScroll = True
        Me.Pnl_9X5.Controls.Add(Me.pic_5_grp9x)
        Me.Pnl_9X5.Location = New System.Drawing.Point(33, 24)
        Me.Pnl_9X5.Name = "Pnl_9X5"
        Me.Pnl_9X5.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X5.TabIndex = 28
        '
        'pic_5_grp9x
        '
        Me.pic_5_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_5_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_5_grp9x.Location = New System.Drawing.Point(5, 7)
        Me.pic_5_grp9x.Name = "pic_5_grp9x"
        Me.pic_5_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_5_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_5_grp9x.TabIndex = 3
        Me.pic_5_grp9x.TabStop = False
        '
        'Pnl_9X2
        '
        Me.Pnl_9X2.AutoScroll = True
        Me.Pnl_9X2.Controls.Add(Me.pic_2_grp9x)
        Me.Pnl_9X2.Location = New System.Drawing.Point(33, 13)
        Me.Pnl_9X2.Name = "Pnl_9X2"
        Me.Pnl_9X2.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X2.TabIndex = 27
        '
        'pic_2_grp9x
        '
        Me.pic_2_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_2_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_2_grp9x.Location = New System.Drawing.Point(6, 7)
        Me.pic_2_grp9x.Name = "pic_2_grp9x"
        Me.pic_2_grp9x.Size = New System.Drawing.Size(116, 50)
        Me.pic_2_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_2_grp9x.TabIndex = 1
        Me.pic_2_grp9x.TabStop = False
        '
        'Pnl_9X7
        '
        Me.Pnl_9X7.AutoScroll = True
        Me.Pnl_9X7.Controls.Add(Me.pic_7_grp9x)
        Me.Pnl_9X7.Location = New System.Drawing.Point(7, 37)
        Me.Pnl_9X7.Name = "Pnl_9X7"
        Me.Pnl_9X7.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X7.TabIndex = 26
        '
        'pic_7_grp9x
        '
        Me.pic_7_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_7_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_7_grp9x.Location = New System.Drawing.Point(6, 5)
        Me.pic_7_grp9x.Name = "pic_7_grp9x"
        Me.pic_7_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_7_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_7_grp9x.TabIndex = 4
        Me.pic_7_grp9x.TabStop = False
        '
        'Pnl_9X4
        '
        Me.Pnl_9X4.AutoScroll = True
        Me.Pnl_9X4.Controls.Add(Me.pic_4_grp9x)
        Me.Pnl_9X4.Location = New System.Drawing.Point(9, 23)
        Me.Pnl_9X4.Name = "Pnl_9X4"
        Me.Pnl_9X4.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X4.TabIndex = 25
        '
        'pic_4_grp9x
        '
        Me.pic_4_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_4_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_4_grp9x.Location = New System.Drawing.Point(6, 7)
        Me.pic_4_grp9x.Name = "pic_4_grp9x"
        Me.pic_4_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_4_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_4_grp9x.TabIndex = 2
        Me.pic_4_grp9x.TabStop = False
        '
        'Pnl_9X1
        '
        Me.Pnl_9X1.AutoScroll = True
        Me.Pnl_9X1.Controls.Add(Me.pic_1_grp9x)
        Me.Pnl_9X1.Location = New System.Drawing.Point(8, 13)
        Me.Pnl_9X1.Name = "Pnl_9X1"
        Me.Pnl_9X1.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_9X1.TabIndex = 24
        '
        'pic_1_grp9x
        '
        Me.pic_1_grp9x.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_1_grp9x.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_1_grp9x.Location = New System.Drawing.Point(5, 6)
        Me.pic_1_grp9x.Name = "pic_1_grp9x"
        Me.pic_1_grp9x.Size = New System.Drawing.Size(117, 50)
        Me.pic_1_grp9x.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_1_grp9x.TabIndex = 0
        Me.pic_1_grp9x.TabStop = False
        '
        'grp4X
        '
        Me.grp4X.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grp4X.Controls.Add(Me.Pnl_4X2)
        Me.grp4X.Controls.Add(Me.Pnl_4X4)
        Me.grp4X.Controls.Add(Me.Pnl_4X3)
        Me.grp4X.Controls.Add(Me.Pnl_4X1)
        Me.grp4X.Location = New System.Drawing.Point(-2, 10)
        Me.grp4X.Name = "grp4X"
        Me.grp4X.Size = New System.Drawing.Size(233, 100)
        Me.grp4X.TabIndex = 8
        Me.grp4X.TabStop = False
        Me.grp4X.Visible = False
        '
        'Pnl_4X2
        '
        Me.Pnl_4X2.AutoScroll = True
        Me.Pnl_4X2.Controls.Add(Me.Pic_2_grp4X)
        Me.Pnl_4X2.Location = New System.Drawing.Point(52, 12)
        Me.Pnl_4X2.Name = "Pnl_4X2"
        Me.Pnl_4X2.Size = New System.Drawing.Size(126, 62)
        Me.Pnl_4X2.TabIndex = 23
        '
        'Pic_2_grp4X
        '
        Me.Pic_2_grp4X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Pic_2_grp4X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pic_2_grp4X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Pic_2_grp4X.Location = New System.Drawing.Point(5, 5)
        Me.Pic_2_grp4X.Name = "Pic_2_grp4X"
        Me.Pic_2_grp4X.Size = New System.Drawing.Size(116, 50)
        Me.Pic_2_grp4X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_2_grp4X.TabIndex = 1
        Me.Pic_2_grp4X.TabStop = False
        '
        'Pnl_4X4
        '
        Me.Pnl_4X4.AutoScroll = True
        Me.Pnl_4X4.Controls.Add(Me.Pic_4_grp4X)
        Me.Pnl_4X4.Location = New System.Drawing.Point(53, 30)
        Me.Pnl_4X4.Name = "Pnl_4X4"
        Me.Pnl_4X4.Size = New System.Drawing.Size(124, 62)
        Me.Pnl_4X4.TabIndex = 25
        '
        'Pic_4_grp4X
        '
        Me.Pic_4_grp4X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Pic_4_grp4X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pic_4_grp4X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Pic_4_grp4X.Location = New System.Drawing.Point(4, 3)
        Me.Pic_4_grp4X.Name = "Pic_4_grp4X"
        Me.Pic_4_grp4X.Size = New System.Drawing.Size(116, 50)
        Me.Pic_4_grp4X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_4_grp4X.TabIndex = 3
        Me.Pic_4_grp4X.TabStop = False
        '
        'Pnl_4X3
        '
        Me.Pnl_4X3.AutoScroll = True
        Me.Pnl_4X3.Controls.Add(Me.Pic_3_grp4X)
        Me.Pnl_4X3.Location = New System.Drawing.Point(3, 29)
        Me.Pnl_4X3.Name = "Pnl_4X3"
        Me.Pnl_4X3.Size = New System.Drawing.Size(124, 62)
        Me.Pnl_4X3.TabIndex = 24
        '
        'Pic_3_grp4X
        '
        Me.Pic_3_grp4X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Pic_3_grp4X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pic_3_grp4X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Pic_3_grp4X.Location = New System.Drawing.Point(5, 6)
        Me.Pic_3_grp4X.Name = "Pic_3_grp4X"
        Me.Pic_3_grp4X.Size = New System.Drawing.Size(116, 50)
        Me.Pic_3_grp4X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_3_grp4X.TabIndex = 2
        Me.Pic_3_grp4X.TabStop = False
        '
        'Pnl_4X1
        '
        Me.Pnl_4X1.AutoScroll = True
        Me.Pnl_4X1.Controls.Add(Me.Pic_1_grp4X)
        Me.Pnl_4X1.Location = New System.Drawing.Point(4, 13)
        Me.Pnl_4X1.Name = "Pnl_4X1"
        Me.Pnl_4X1.Size = New System.Drawing.Size(124, 62)
        Me.Pnl_4X1.TabIndex = 22
        '
        'Pic_1_grp4X
        '
        Me.Pic_1_grp4X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Pic_1_grp4X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pic_1_grp4X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Pic_1_grp4X.Location = New System.Drawing.Point(5, 6)
        Me.Pic_1_grp4X.Name = "Pic_1_grp4X"
        Me.Pic_1_grp4X.Size = New System.Drawing.Size(116, 50)
        Me.Pic_1_grp4X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_1_grp4X.TabIndex = 0
        Me.Pic_1_grp4X.TabStop = False
        '
        'grpViewer
        '
        Me.grpViewer.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grpViewer.Controls.Add(Me.WebBrowser1)
        Me.grpViewer.Location = New System.Drawing.Point(-2, 24)
        Me.grpViewer.Name = "grpViewer"
        Me.grpViewer.Size = New System.Drawing.Size(267, 100)
        Me.grpViewer.TabIndex = 13
        Me.grpViewer.TabStop = False
        Me.grpViewer.Visible = False
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(3, 17)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(261, 80)
        Me.WebBrowser1.TabIndex = 0
        '
        'grp16X
        '
        Me.grp16X.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grp16X.Controls.Add(Me.pic_16_grp16X)
        Me.grp16X.Controls.Add(Me.pic_15_grp16X)
        Me.grp16X.Controls.Add(Me.pic_14_grp16X)
        Me.grp16X.Controls.Add(Me.pic_13_grp16X)
        Me.grp16X.Controls.Add(Me.pic_12_grp16X)
        Me.grp16X.Controls.Add(Me.pic_8_grp16X)
        Me.grp16X.Controls.Add(Me.pic_4_grp16X)
        Me.grp16X.Controls.Add(Me.pic_11_grp16X)
        Me.grp16X.Controls.Add(Me.pic_7_grp16X)
        Me.grp16X.Controls.Add(Me.pic_3_grp16X)
        Me.grp16X.Controls.Add(Me.pic_10_grp16X)
        Me.grp16X.Controls.Add(Me.pic_9_grp16X)
        Me.grp16X.Controls.Add(Me.pic_6_grp16X)
        Me.grp16X.Controls.Add(Me.pic_5_grp16X)
        Me.grp16X.Controls.Add(Me.pic_2_grp16X)
        Me.grp16X.Controls.Add(Me.pic_1_grp16X)
        Me.grp16X.Location = New System.Drawing.Point(-2, 24)
        Me.grp16X.Name = "grp16X"
        Me.grp16X.Size = New System.Drawing.Size(267, 100)
        Me.grp16X.TabIndex = 12
        Me.grp16X.TabStop = False
        Me.grp16X.Visible = False
        '
        'pic_16_grp16X
        '
        Me.pic_16_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_16_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_16_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_16_grp16X.Location = New System.Drawing.Point(145, 47)
        Me.pic_16_grp16X.Name = "pic_16_grp16X"
        Me.pic_16_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_16_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_16_grp16X.TabIndex = 15
        Me.pic_16_grp16X.TabStop = False
        '
        'pic_15_grp16X
        '
        Me.pic_15_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_15_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_15_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_15_grp16X.Location = New System.Drawing.Point(111, 47)
        Me.pic_15_grp16X.Name = "pic_15_grp16X"
        Me.pic_15_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_15_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_15_grp16X.TabIndex = 14
        Me.pic_15_grp16X.TabStop = False
        '
        'pic_14_grp16X
        '
        Me.pic_14_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_14_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_14_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_14_grp16X.Location = New System.Drawing.Point(59, 47)
        Me.pic_14_grp16X.Name = "pic_14_grp16X"
        Me.pic_14_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_14_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_14_grp16X.TabIndex = 13
        Me.pic_14_grp16X.TabStop = False
        '
        'pic_13_grp16X
        '
        Me.pic_13_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_13_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_13_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_13_grp16X.Location = New System.Drawing.Point(4, 47)
        Me.pic_13_grp16X.Name = "pic_13_grp16X"
        Me.pic_13_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_13_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_13_grp16X.TabIndex = 12
        Me.pic_13_grp16X.TabStop = False
        '
        'pic_12_grp16X
        '
        Me.pic_12_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_12_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_12_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_12_grp16X.Location = New System.Drawing.Point(144, 36)
        Me.pic_12_grp16X.Name = "pic_12_grp16X"
        Me.pic_12_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_12_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_12_grp16X.TabIndex = 11
        Me.pic_12_grp16X.TabStop = False
        '
        'pic_8_grp16X
        '
        Me.pic_8_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_8_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_8_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_8_grp16X.Location = New System.Drawing.Point(144, 26)
        Me.pic_8_grp16X.Name = "pic_8_grp16X"
        Me.pic_8_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_8_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_8_grp16X.TabIndex = 10
        Me.pic_8_grp16X.TabStop = False
        '
        'pic_4_grp16X
        '
        Me.pic_4_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_4_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_4_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_4_grp16X.Location = New System.Drawing.Point(144, 15)
        Me.pic_4_grp16X.Name = "pic_4_grp16X"
        Me.pic_4_grp16X.Size = New System.Drawing.Size(116, 50)
        Me.pic_4_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_4_grp16X.TabIndex = 9
        Me.pic_4_grp16X.TabStop = False
        '
        'pic_11_grp16X
        '
        Me.pic_11_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_11_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_11_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_11_grp16X.Location = New System.Drawing.Point(110, 36)
        Me.pic_11_grp16X.Name = "pic_11_grp16X"
        Me.pic_11_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_11_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_11_grp16X.TabIndex = 8
        Me.pic_11_grp16X.TabStop = False
        '
        'pic_7_grp16X
        '
        Me.pic_7_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_7_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_7_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_7_grp16X.Location = New System.Drawing.Point(110, 26)
        Me.pic_7_grp16X.Name = "pic_7_grp16X"
        Me.pic_7_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_7_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_7_grp16X.TabIndex = 7
        Me.pic_7_grp16X.TabStop = False
        '
        'pic_3_grp16X
        '
        Me.pic_3_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_3_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_3_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_3_grp16X.Location = New System.Drawing.Point(110, 15)
        Me.pic_3_grp16X.Name = "pic_3_grp16X"
        Me.pic_3_grp16X.Size = New System.Drawing.Size(116, 50)
        Me.pic_3_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_3_grp16X.TabIndex = 6
        Me.pic_3_grp16X.TabStop = False
        '
        'pic_10_grp16X
        '
        Me.pic_10_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_10_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_10_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_10_grp16X.Location = New System.Drawing.Point(58, 36)
        Me.pic_10_grp16X.Name = "pic_10_grp16X"
        Me.pic_10_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_10_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_10_grp16X.TabIndex = 5
        Me.pic_10_grp16X.TabStop = False
        '
        'pic_9_grp16X
        '
        Me.pic_9_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_9_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_9_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_9_grp16X.Location = New System.Drawing.Point(3, 36)
        Me.pic_9_grp16X.Name = "pic_9_grp16X"
        Me.pic_9_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_9_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_9_grp16X.TabIndex = 4
        Me.pic_9_grp16X.TabStop = False
        '
        'pic_6_grp16X
        '
        Me.pic_6_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_6_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_6_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_6_grp16X.Location = New System.Drawing.Point(58, 26)
        Me.pic_6_grp16X.Name = "pic_6_grp16X"
        Me.pic_6_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_6_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_6_grp16X.TabIndex = 3
        Me.pic_6_grp16X.TabStop = False
        '
        'pic_5_grp16X
        '
        Me.pic_5_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_5_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_5_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_5_grp16X.Location = New System.Drawing.Point(3, 26)
        Me.pic_5_grp16X.Name = "pic_5_grp16X"
        Me.pic_5_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_5_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_5_grp16X.TabIndex = 2
        Me.pic_5_grp16X.TabStop = False
        '
        'pic_2_grp16X
        '
        Me.pic_2_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_2_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_2_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_2_grp16X.Location = New System.Drawing.Point(58, 15)
        Me.pic_2_grp16X.Name = "pic_2_grp16X"
        Me.pic_2_grp16X.Size = New System.Drawing.Size(116, 50)
        Me.pic_2_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_2_grp16X.TabIndex = 1
        Me.pic_2_grp16X.TabStop = False
        '
        'pic_1_grp16X
        '
        Me.pic_1_grp16X.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_1_grp16X.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_1_grp16X.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_1_grp16X.Location = New System.Drawing.Point(3, 16)
        Me.pic_1_grp16X.Name = "pic_1_grp16X"
        Me.pic_1_grp16X.Size = New System.Drawing.Size(117, 50)
        Me.pic_1_grp16X.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_1_grp16X.TabIndex = 0
        Me.pic_1_grp16X.TabStop = False
        '
        'grpFullMouth
        '
        Me.grpFullMouth.BackColor = System.Drawing.Color.CornflowerBlue
        Me.grpFullMouth.Controls.Add(Me.pic_18_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_17_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_16_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_15_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_14_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_13_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_12_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_11_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_10_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_9_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_8_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_7_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_6_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_5_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_4_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_3_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_2_grpFullMouth)
        Me.grpFullMouth.Controls.Add(Me.pic_1_grpFullMouth)
        Me.grpFullMouth.Location = New System.Drawing.Point(-2, 24)
        Me.grpFullMouth.Name = "grpFullMouth"
        Me.grpFullMouth.Size = New System.Drawing.Size(309, 109)
        Me.grpFullMouth.TabIndex = 11
        Me.grpFullMouth.TabStop = False
        Me.grpFullMouth.Visible = False
        '
        'pic_18_grpFullMouth
        '
        Me.pic_18_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_18_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_18_grpFullMouth.Location = New System.Drawing.Point(173, 55)
        Me.pic_18_grpFullMouth.Name = "pic_18_grpFullMouth"
        Me.pic_18_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_18_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_18_grpFullMouth.TabIndex = 17
        Me.pic_18_grpFullMouth.TabStop = False
        '
        'pic_17_grpFullMouth
        '
        Me.pic_17_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_17_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_17_grpFullMouth.Location = New System.Drawing.Point(118, 55)
        Me.pic_17_grpFullMouth.Name = "pic_17_grpFullMouth"
        Me.pic_17_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_17_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_17_grpFullMouth.TabIndex = 16
        Me.pic_17_grpFullMouth.TabStop = False
        '
        'pic_16_grpFullMouth
        '
        Me.pic_16_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_16_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_16_grpFullMouth.Location = New System.Drawing.Point(173, 45)
        Me.pic_16_grpFullMouth.Name = "pic_16_grpFullMouth"
        Me.pic_16_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_16_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_16_grpFullMouth.TabIndex = 15
        Me.pic_16_grpFullMouth.TabStop = False
        '
        'pic_15_grpFullMouth
        '
        Me.pic_15_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_15_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_15_grpFullMouth.Location = New System.Drawing.Point(118, 45)
        Me.pic_15_grpFullMouth.Name = "pic_15_grpFullMouth"
        Me.pic_15_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_15_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_15_grpFullMouth.TabIndex = 14
        Me.pic_15_grpFullMouth.TabStop = False
        '
        'pic_14_grpFullMouth
        '
        Me.pic_14_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_14_grpFullMouth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_14_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_14_grpFullMouth.Location = New System.Drawing.Point(173, 34)
        Me.pic_14_grpFullMouth.Name = "pic_14_grpFullMouth"
        Me.pic_14_grpFullMouth.Size = New System.Drawing.Size(116, 50)
        Me.pic_14_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_14_grpFullMouth.TabIndex = 13
        Me.pic_14_grpFullMouth.TabStop = False
        '
        'pic_13_grpFullMouth
        '
        Me.pic_13_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_13_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_13_grpFullMouth.Location = New System.Drawing.Point(118, 35)
        Me.pic_13_grpFullMouth.Name = "pic_13_grpFullMouth"
        Me.pic_13_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_13_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_13_grpFullMouth.TabIndex = 12
        Me.pic_13_grpFullMouth.TabStop = False
        '
        'pic_12_grpFullMouth
        '
        Me.pic_12_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_12_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_12_grpFullMouth.Location = New System.Drawing.Point(133, 23)
        Me.pic_12_grpFullMouth.Name = "pic_12_grpFullMouth"
        Me.pic_12_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_12_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_12_grpFullMouth.TabIndex = 11
        Me.pic_12_grpFullMouth.TabStop = False
        '
        'pic_11_grpFullMouth
        '
        Me.pic_11_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_11_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_11_grpFullMouth.Location = New System.Drawing.Point(117, 23)
        Me.pic_11_grpFullMouth.Name = "pic_11_grpFullMouth"
        Me.pic_11_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_11_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_11_grpFullMouth.TabIndex = 10
        Me.pic_11_grpFullMouth.TabStop = False
        '
        'pic_10_grpFullMouth
        '
        Me.pic_10_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_10_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_10_grpFullMouth.Location = New System.Drawing.Point(96, 22)
        Me.pic_10_grpFullMouth.Name = "pic_10_grpFullMouth"
        Me.pic_10_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_10_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_10_grpFullMouth.TabIndex = 9
        Me.pic_10_grpFullMouth.TabStop = False
        '
        'pic_9_grpFullMouth
        '
        Me.pic_9_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_9_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_9_grpFullMouth.Location = New System.Drawing.Point(134, 11)
        Me.pic_9_grpFullMouth.Name = "pic_9_grpFullMouth"
        Me.pic_9_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_9_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_9_grpFullMouth.TabIndex = 8
        Me.pic_9_grpFullMouth.TabStop = False
        '
        'pic_8_grpFullMouth
        '
        Me.pic_8_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_8_grpFullMouth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_8_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_8_grpFullMouth.Location = New System.Drawing.Point(117, 11)
        Me.pic_8_grpFullMouth.Name = "pic_8_grpFullMouth"
        Me.pic_8_grpFullMouth.Size = New System.Drawing.Size(116, 50)
        Me.pic_8_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_8_grpFullMouth.TabIndex = 7
        Me.pic_8_grpFullMouth.TabStop = False
        '
        'pic_7_grpFullMouth
        '
        Me.pic_7_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_7_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_7_grpFullMouth.Location = New System.Drawing.Point(95, 12)
        Me.pic_7_grpFullMouth.Name = "pic_7_grpFullMouth"
        Me.pic_7_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_7_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_7_grpFullMouth.TabIndex = 6
        Me.pic_7_grpFullMouth.TabStop = False
        '
        'pic_6_grpFullMouth
        '
        Me.pic_6_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_6_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_6_grpFullMouth.Location = New System.Drawing.Point(58, 36)
        Me.pic_6_grpFullMouth.Name = "pic_6_grpFullMouth"
        Me.pic_6_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_6_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_6_grpFullMouth.TabIndex = 5
        Me.pic_6_grpFullMouth.TabStop = False
        '
        'pic_5_grpFullMouth
        '
        Me.pic_5_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_5_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_5_grpFullMouth.Location = New System.Drawing.Point(3, 36)
        Me.pic_5_grpFullMouth.Name = "pic_5_grpFullMouth"
        Me.pic_5_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_5_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_5_grpFullMouth.TabIndex = 4
        Me.pic_5_grpFullMouth.TabStop = False
        '
        'pic_4_grpFullMouth
        '
        Me.pic_4_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_4_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_4_grpFullMouth.Location = New System.Drawing.Point(58, 26)
        Me.pic_4_grpFullMouth.Name = "pic_4_grpFullMouth"
        Me.pic_4_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_4_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_4_grpFullMouth.TabIndex = 3
        Me.pic_4_grpFullMouth.TabStop = False
        '
        'pic_3_grpFullMouth
        '
        Me.pic_3_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_3_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_3_grpFullMouth.Location = New System.Drawing.Point(3, 26)
        Me.pic_3_grpFullMouth.Name = "pic_3_grpFullMouth"
        Me.pic_3_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_3_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_3_grpFullMouth.TabIndex = 2
        Me.pic_3_grpFullMouth.TabStop = False
        '
        'pic_2_grpFullMouth
        '
        Me.pic_2_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_2_grpFullMouth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_2_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_2_grpFullMouth.Location = New System.Drawing.Point(58, 15)
        Me.pic_2_grpFullMouth.Name = "pic_2_grpFullMouth"
        Me.pic_2_grpFullMouth.Size = New System.Drawing.Size(116, 50)
        Me.pic_2_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_2_grpFullMouth.TabIndex = 1
        Me.pic_2_grpFullMouth.TabStop = False
        '
        'pic_1_grpFullMouth
        '
        Me.pic_1_grpFullMouth.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.pic_1_grpFullMouth.ContextMenuStrip = Me.ContextMenuStrip1
        Me.pic_1_grpFullMouth.Location = New System.Drawing.Point(3, 16)
        Me.pic_1_grpFullMouth.Name = "pic_1_grpFullMouth"
        Me.pic_1_grpFullMouth.Size = New System.Drawing.Size(117, 50)
        Me.pic_1_grpFullMouth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic_1_grpFullMouth.TabIndex = 0
        Me.pic_1_grpFullMouth.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackgroundImage = CType(resources.GetObject("GroupBox3.BackgroundImage"), System.Drawing.Image)
        Me.GroupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox3.Location = New System.Drawing.Point(-3, -6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(292, 99)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExportOriginalToolStripMenuItem1, Me.ExportProcessedToolStripMenuItem1, Me.PrintTheCurrentToolStripMenuItem, Me.SendToolStripMenuItem, Me.ToolStripSeparator9, Me.DeleteToolStripMenuItem2, Me.CopyToolStripMenuItem1, Me.ToolStripMenuItem6, Me.ToolStripSeparator10, Me.PropertiesToolStripMenuItem1})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(251, 192)
        '
        'ExportOriginalToolStripMenuItem1
        '
        Me.ExportOriginalToolStripMenuItem1.Name = "ExportOriginalToolStripMenuItem1"
        Me.ExportOriginalToolStripMenuItem1.Size = New System.Drawing.Size(250, 22)
        Me.ExportOriginalToolStripMenuItem1.Text = "Export Image"
        '
        'ExportProcessedToolStripMenuItem1
        '
        Me.ExportProcessedToolStripMenuItem1.Name = "ExportProcessedToolStripMenuItem1"
        Me.ExportProcessedToolStripMenuItem1.Size = New System.Drawing.Size(250, 22)
        Me.ExportProcessedToolStripMenuItem1.Text = "Export Image with Changes"
        '
        'PrintTheCurrentToolStripMenuItem
        '
        Me.PrintTheCurrentToolStripMenuItem.Name = "PrintTheCurrentToolStripMenuItem"
        Me.PrintTheCurrentToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.PrintTheCurrentToolStripMenuItem.Text = "Print"
        '
        'SendToolStripMenuItem
        '
        Me.SendToolStripMenuItem.Name = "SendToolStripMenuItem"
        Me.SendToolStripMenuItem.Size = New System.Drawing.Size(250, 22)
        Me.SendToolStripMenuItem.Text = "Access Email"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(247, 6)
        '
        'DeleteToolStripMenuItem2
        '
        Me.DeleteToolStripMenuItem2.Name = "DeleteToolStripMenuItem2"
        Me.DeleteToolStripMenuItem2.Size = New System.Drawing.Size(250, 22)
        Me.DeleteToolStripMenuItem2.Text = "Delete"
        '
        'CopyToolStripMenuItem1
        '
        Me.CopyToolStripMenuItem1.Name = "CopyToolStripMenuItem1"
        Me.CopyToolStripMenuItem1.Size = New System.Drawing.Size(250, 22)
        Me.CopyToolStripMenuItem1.Text = "Setup a Copy"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeViewToolStripMenuItem, Me.FullMouthSeriesViewToolStripMenuItem1, Me.PatientFileVewToolStripMenuItem, Me.BitewingViewToolStripMenuItem})
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(250, 22)
        Me.ToolStripMenuItem6.Text = "Move"
        '
        'HomeViewToolStripMenuItem
        '
        Me.HomeViewToolStripMenuItem.Name = "HomeViewToolStripMenuItem"
        Me.HomeViewToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.HomeViewToolStripMenuItem.Text = "Home View"
        '
        'FullMouthSeriesViewToolStripMenuItem1
        '
        Me.FullMouthSeriesViewToolStripMenuItem1.Name = "FullMouthSeriesViewToolStripMenuItem1"
        Me.FullMouthSeriesViewToolStripMenuItem1.Size = New System.Drawing.Size(215, 22)
        Me.FullMouthSeriesViewToolStripMenuItem1.Text = "Full Mouth Series View"
        '
        'PatientFileVewToolStripMenuItem
        '
        Me.PatientFileVewToolStripMenuItem.Name = "PatientFileVewToolStripMenuItem"
        Me.PatientFileVewToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.PatientFileVewToolStripMenuItem.Text = "Patient File View"
        '
        'BitewingViewToolStripMenuItem
        '
        Me.BitewingViewToolStripMenuItem.Name = "BitewingViewToolStripMenuItem"
        Me.BitewingViewToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.BitewingViewToolStripMenuItem.Text = "Bitewing View"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(247, 6)
        '
        'PropertiesToolStripMenuItem1
        '
        Me.PropertiesToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PropertiesToolStripMenuItem1.Name = "PropertiesToolStripMenuItem1"
        Me.PropertiesToolStripMenuItem1.Size = New System.Drawing.Size(250, 22)
        Me.PropertiesToolStripMenuItem1.Text = "Properties..."
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.btnCloseMeasurement)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.PictureBox8)
        Me.Panel1.Controls.Add(Me.Measure_Text)
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.pic_distance_measure)
        Me.Panel1.Controls.Add(Me.Measure_Move)
        Me.Panel1.Location = New System.Drawing.Point(484, 130)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(449, 214)
        Me.Panel1.TabIndex = 7
        Me.Panel1.Visible = False
        '
        'btnCloseMeasurement
        '
        Me.btnCloseMeasurement.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseMeasurement.ForeColor = System.Drawing.Color.Red
        Me.btnCloseMeasurement.Location = New System.Drawing.Point(424, 2)
        Me.btnCloseMeasurement.Name = "btnCloseMeasurement"
        Me.btnCloseMeasurement.Size = New System.Drawing.Size(20, 23)
        Me.btnCloseMeasurement.TabIndex = 13
        Me.btnCloseMeasurement.Text = "X"
        Me.btnCloseMeasurement.UseVisualStyleBackColor = True
        '
        'PictureBox9
        '
        Me.PictureBox9.BackgroundImage = CType(resources.GetObject("PictureBox9.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox9.Location = New System.Drawing.Point(314, 28)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox9.TabIndex = 12
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImage = CType(resources.GetObject("PictureBox10.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox10.Location = New System.Drawing.Point(270, 28)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox10.TabIndex = 11
        Me.PictureBox10.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackgroundImage = CType(resources.GetObject("PictureBox8.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox8.Location = New System.Drawing.Point(403, 28)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox8.TabIndex = 9
        Me.PictureBox8.TabStop = False
        '
        'Measure_Text
        '
        Me.Measure_Text.BackgroundImage = CType(resources.GetObject("Measure_Text.BackgroundImage"), System.Drawing.Image)
        Me.Measure_Text.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Measure_Text.Location = New System.Drawing.Point(358, 28)
        Me.Measure_Text.Name = "Measure_Text"
        Me.Measure_Text.Size = New System.Drawing.Size(40, 44)
        Me.Measure_Text.TabIndex = 10
        Me.Measure_Text.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox6.Location = New System.Drawing.Point(226, 28)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox6.TabIndex = 8
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox5.Location = New System.Drawing.Point(182, 28)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox4.Location = New System.Drawing.Point(138, 28)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox3.Location = New System.Drawing.Point(94, 28)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(40, 44)
        Me.PictureBox3.TabIndex = 6
        Me.PictureBox3.TabStop = False
        '
        'pic_distance_measure
        '
        Me.pic_distance_measure.BackgroundImage = CType(resources.GetObject("pic_distance_measure.BackgroundImage"), System.Drawing.Image)
        Me.pic_distance_measure.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pic_distance_measure.Location = New System.Drawing.Point(50, 28)
        Me.pic_distance_measure.Name = "pic_distance_measure"
        Me.pic_distance_measure.Size = New System.Drawing.Size(40, 44)
        Me.pic_distance_measure.TabIndex = 5
        Me.pic_distance_measure.TabStop = False
        '
        'Measure_Move
        '
        Me.Measure_Move.BackgroundImage = CType(resources.GetObject("Measure_Move.BackgroundImage"), System.Drawing.Image)
        Me.Measure_Move.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Measure_Move.Location = New System.Drawing.Point(6, 28)
        Me.Measure_Move.Name = "Measure_Move"
        Me.Measure_Move.Size = New System.Drawing.Size(40, 44)
        Me.Measure_Move.TabIndex = 7
        Me.Measure_Move.TabStop = False
        '
        'frm_MainScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1370, 390)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frm_MainScreen"
        Me.Text = "LynxVision Professional"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.grp1X.ResumeLayout(False)
        Me.Pnl_1X1.ResumeLayout(False)
        CType(Me.Pic_1_grp1X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp2X.ResumeLayout(False)
        Me.Pnl_2X2.ResumeLayout(False)
        CType(Me.pic_2_grp2X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_2X1.ResumeLayout(False)
        CType(Me.pic_1_grp2X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp9X.ResumeLayout(False)
        Me.Pnl_9X9.ResumeLayout(False)
        CType(Me.pic_9_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X6.ResumeLayout(False)
        CType(Me.pic_6_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X3.ResumeLayout(False)
        CType(Me.pic_3_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X8.ResumeLayout(False)
        CType(Me.pic_8_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X5.ResumeLayout(False)
        CType(Me.pic_5_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X2.ResumeLayout(False)
        CType(Me.pic_2_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X7.ResumeLayout(False)
        CType(Me.pic_7_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X4.ResumeLayout(False)
        CType(Me.pic_4_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_9X1.ResumeLayout(False)
        CType(Me.pic_1_grp9x, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp4X.ResumeLayout(False)
        Me.Pnl_4X2.ResumeLayout(False)
        CType(Me.Pic_2_grp4X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_4X4.ResumeLayout(False)
        CType(Me.Pic_4_grp4X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_4X3.ResumeLayout(False)
        CType(Me.Pic_3_grp4X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_4X1.ResumeLayout(False)
        CType(Me.Pic_1_grp4X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpViewer.ResumeLayout(False)
        Me.grp16X.ResumeLayout(False)
        CType(Me.pic_16_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_15_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_14_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_13_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_12_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_8_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_4_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_11_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_7_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_3_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_10_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_9_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_6_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_5_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_2_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_1_grp16X, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpFullMouth.ResumeLayout(False)
        CType(Me.pic_18_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_17_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_16_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_15_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_14_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_13_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_12_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_11_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_10_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_9_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_8_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_7_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_6_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_5_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_4_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_3_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_2_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_1_grpFullMouth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Measure_Text, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_distance_measure, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Measure_Move, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents PatientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton8 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton9 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton11 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton12 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton13 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton14 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton15 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton16 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton17 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton18 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton19 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton21 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton20 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton22 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton23 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton24 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripContainer1 As System.Windows.Forms.ToolStripContainer
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents SelectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClosePatientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreatedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UntreatedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DiagnosedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UndiagnosedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitewingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TodaysImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpecificImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SynchronizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitScreenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullViewAreaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullScreenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToOtherMonitorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MeasurementsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewMakersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlinkMakersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VideoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScannerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportOriginalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportProcessedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DuplicateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToothWhitenerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResetAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RotateMirrirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EffectsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InteractiveContrastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContrastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HistogramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubtractToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImagePropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplicationSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatabaseSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExternalApplicationSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommunicationSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeviceSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents XRaySettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserWithPrivateSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WaitingRoomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendNotesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenMeasurementsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grp2X As System.Windows.Forms.GroupBox
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScreenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScreenToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grp4X As System.Windows.Forms.GroupBox
    Friend WithEvents Pic_4_grp4X As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_3_grp4X As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_2_grp4X As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_1_grp4X As System.Windows.Forms.PictureBox
    Friend WithEvents grp9X As System.Windows.Forms.GroupBox
    Friend WithEvents pic_5_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_4_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_2_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_1_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_9_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_6_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_3_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_8_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents pic_7_grp9x As System.Windows.Forms.PictureBox
    Friend WithEvents ToolStripButton26 As System.Windows.Forms.ToolStripButton
    Friend WithEvents Rotate90ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rotate180ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rotate270ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NegativeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PseudoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SharpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SmoothenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MediaFilterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SofttissueFilterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MirrorXToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MirrorYToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FullScreenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ResetAllToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResetContrastToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResetZoomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Rotate90ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rotate180ºToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rotate270ºToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MirrorXToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MirrorYToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ColorBrandingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColorDiferencingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SofttissueFilterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents HistogramToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ExportOriginalToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportProcessedToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintTheCurrentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeleteToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PropertiesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grpFullMouth As System.Windows.Forms.GroupBox
    Friend WithEvents pic_6_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_5_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_4_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_3_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_2_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_1_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_12_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_11_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_10_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_9_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_8_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_7_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_18_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_17_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_16_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_15_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_14_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents pic_13_grpFullMouth As System.Windows.Forms.PictureBox
    Friend WithEvents ToolStripButton6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DentistToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullMouthSeriesViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomeViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FullMouthSeriesViewToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PatientFileVewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitewingViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents X4GridToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grp16X As System.Windows.Forms.GroupBox
    Friend WithEvents pic_16_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_15_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_14_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_13_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_12_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_8_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_4_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_11_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_7_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_3_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_10_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_9_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_6_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_5_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_2_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents pic_1_grp16X As System.Windows.Forms.PictureBox
    Friend WithEvents grpViewer As System.Windows.Forms.GroupBox
    Friend WithEvents btnImport As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents Pnl_2X1 As System.Windows.Forms.Panel
    Friend WithEvents pic_1_grp2X As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_2X2 As System.Windows.Forms.Panel
    Friend WithEvents pic_2_grp2X As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_4X1 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_4X4 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_4X3 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_4X2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents Measure_Text As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents pic_distance_measure As System.Windows.Forms.PictureBox
    Friend WithEvents Measure_Move As System.Windows.Forms.PictureBox
    Friend WithEvents btnCloseMeasurement As System.Windows.Forms.Button
    Friend WithEvents Pnl_9X7 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X4 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X1 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X9 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X6 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X3 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X8 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X5 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_9X2 As System.Windows.Forms.Panel
    Friend WithEvents StatisticsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NormalPrinterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImagePrinterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TestPrintToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PageSetupDialog1 As System.Windows.Forms.PageSetupDialog
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents grp1X As System.Windows.Forms.GroupBox
    Friend WithEvents Pnl_1X1 As System.Windows.Forms.Panel
    Friend WithEvents Pic_1_grp1X As System.Windows.Forms.PictureBox

End Class
