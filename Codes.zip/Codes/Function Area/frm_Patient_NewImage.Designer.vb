﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Patient_NewImage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Patient_NewImage))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScannerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XRayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadBackupImagesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.AutoResetPatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.AutoSaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoAcquireToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FootpedalActiveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Rotate90ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate180ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Rotate270ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MirrorXToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MirrorYToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultImageSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PhotoSequencesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditScaleFactorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToothNumberingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FDIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.USAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DanishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BritishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetToothIconsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton13 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton12 = New System.Windows.Forms.ToolStripButton()
        Me.TSBCopy = New System.Windows.Forms.ToolStripButton()
        Me.TSBPaste = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton9 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton10 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton11 = New System.Windows.Forms.ToolStripButton()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.dtpRegDate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCEPH = New System.Windows.Forms.Button()
        Me.btnPAN = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.btnCloseX = New System.Windows.Forms.Button()
        Me.Teeth = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox34 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.btnL2 = New System.Windows.Forms.Button()
        Me.btnL1 = New System.Windows.Forms.Button()
        Me.btnR2 = New System.Windows.Forms.Button()
        Me.btnR1 = New System.Windows.Forms.Button()
        Me.Teeth32 = New System.Windows.Forms.PictureBox()
        Me.Teeth31 = New System.Windows.Forms.PictureBox()
        Me.Teeth30 = New System.Windows.Forms.PictureBox()
        Me.Teeth29 = New System.Windows.Forms.PictureBox()
        Me.Teeth28 = New System.Windows.Forms.PictureBox()
        Me.Teeth27 = New System.Windows.Forms.PictureBox()
        Me.Teeth26 = New System.Windows.Forms.PictureBox()
        Me.Teeth25 = New System.Windows.Forms.PictureBox()
        Me.Teeth24 = New System.Windows.Forms.PictureBox()
        Me.Teeth23 = New System.Windows.Forms.PictureBox()
        Me.Teeth22 = New System.Windows.Forms.PictureBox()
        Me.Teeth21 = New System.Windows.Forms.PictureBox()
        Me.Teeth20 = New System.Windows.Forms.PictureBox()
        Me.Teeth19 = New System.Windows.Forms.PictureBox()
        Me.Teeth18 = New System.Windows.Forms.PictureBox()
        Me.Teeth17 = New System.Windows.Forms.PictureBox()
        Me.Teeth16 = New System.Windows.Forms.PictureBox()
        Me.Teeth15 = New System.Windows.Forms.PictureBox()
        Me.Teeth14 = New System.Windows.Forms.PictureBox()
        Me.Teeth13 = New System.Windows.Forms.PictureBox()
        Me.Teeth12 = New System.Windows.Forms.PictureBox()
        Me.Teeth11 = New System.Windows.Forms.PictureBox()
        Me.Teeth10 = New System.Windows.Forms.PictureBox()
        Me.Teeth9 = New System.Windows.Forms.PictureBox()
        Me.Teeth8 = New System.Windows.Forms.PictureBox()
        Me.Teeth7 = New System.Windows.Forms.PictureBox()
        Me.Teeth6 = New System.Windows.Forms.PictureBox()
        Me.Teeth5 = New System.Windows.Forms.PictureBox()
        Me.Teeth4 = New System.Windows.Forms.PictureBox()
        Me.Teeth3 = New System.Windows.Forms.PictureBox()
        Me.Teeth2 = New System.Windows.Forms.PictureBox()
        Me.Teeth1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Teeth1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImageToolStripMenuItem, Me.EditToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(797, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ImageToolStripMenuItem
        '
        Me.ImageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImportToolStripMenuItem, Me.ScannerToolStripMenuItem, Me.XRayToolStripMenuItem, Me.LoadBackupImagesToolStripMenuItem, Me.ToolStripSeparator3, Me.AutoResetPatientToolStripMenuItem, Me.ToolStripSeparator4, Me.AutoSaveToolStripMenuItem, Me.AutoAcquireToolStripMenuItem, Me.FootpedalActiveToolStripMenuItem, Me.ToolStripSeparator5, Me.SaveToolStripMenuItem, Me.SaveToolStripMenuItem1, Me.ExitToolStripMenuItem})
        Me.ImageToolStripMenuItem.Name = "ImageToolStripMenuItem"
        Me.ImageToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.ImageToolStripMenuItem.Text = "Image"
        '
        'ImportToolStripMenuItem
        '
        Me.ImportToolStripMenuItem.Name = "ImportToolStripMenuItem"
        Me.ImportToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.ImportToolStripMenuItem.Text = "Import"
        '
        'ScannerToolStripMenuItem
        '
        Me.ScannerToolStripMenuItem.Enabled = False
        Me.ScannerToolStripMenuItem.Name = "ScannerToolStripMenuItem"
        Me.ScannerToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.ScannerToolStripMenuItem.Text = "Scanner"
        '
        'XRayToolStripMenuItem
        '
        Me.XRayToolStripMenuItem.Name = "XRayToolStripMenuItem"
        Me.XRayToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.XRayToolStripMenuItem.Text = "X-Ray"
        '
        'LoadBackupImagesToolStripMenuItem
        '
        Me.LoadBackupImagesToolStripMenuItem.Name = "LoadBackupImagesToolStripMenuItem"
        Me.LoadBackupImagesToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.LoadBackupImagesToolStripMenuItem.Text = "Load Backup Images"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(199, 6)
        '
        'AutoResetPatientToolStripMenuItem
        '
        Me.AutoResetPatientToolStripMenuItem.Name = "AutoResetPatientToolStripMenuItem"
        Me.AutoResetPatientToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.AutoResetPatientToolStripMenuItem.Text = "Auto reset patient status"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(199, 6)
        '
        'AutoSaveToolStripMenuItem
        '
        Me.AutoSaveToolStripMenuItem.Enabled = False
        Me.AutoSaveToolStripMenuItem.Name = "AutoSaveToolStripMenuItem"
        Me.AutoSaveToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.AutoSaveToolStripMenuItem.Text = "Auto Save"
        '
        'AutoAcquireToolStripMenuItem
        '
        Me.AutoAcquireToolStripMenuItem.Enabled = False
        Me.AutoAcquireToolStripMenuItem.Name = "AutoAcquireToolStripMenuItem"
        Me.AutoAcquireToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.AutoAcquireToolStripMenuItem.Text = "Auto-Acquire"
        '
        'FootpedalActiveToolStripMenuItem
        '
        Me.FootpedalActiveToolStripMenuItem.Enabled = False
        Me.FootpedalActiveToolStripMenuItem.Name = "FootpedalActiveToolStripMenuItem"
        Me.FootpedalActiveToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.FootpedalActiveToolStripMenuItem.Text = "Footpedal Active"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(199, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.SaveToolStripMenuItem.Text = "Save and Close"
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(202, 22)
        Me.SaveToolStripMenuItem1.Text = "Save"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(202, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.PasteToolStripMenuItem, Me.ToolStripSeparator1, Me.Rotate90ToolStripMenuItem, Me.Rotate180ToolStripMenuItem, Me.Rotate270ToolStripMenuItem, Me.MirrorXToolStripMenuItem, Me.MirrorYToolStripMenuItem})
        Me.EditToolStripMenuItem.Enabled = False
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Enabled = False
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(129, 22)
        Me.ToolStripMenuItem1.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Enabled = False
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(126, 6)
        '
        'Rotate90ToolStripMenuItem
        '
        Me.Rotate90ToolStripMenuItem.Name = "Rotate90ToolStripMenuItem"
        Me.Rotate90ToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.Rotate90ToolStripMenuItem.Text = "Rotate 90"
        '
        'Rotate180ToolStripMenuItem
        '
        Me.Rotate180ToolStripMenuItem.Name = "Rotate180ToolStripMenuItem"
        Me.Rotate180ToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.Rotate180ToolStripMenuItem.Text = "Rotate 180"
        '
        'Rotate270ToolStripMenuItem
        '
        Me.Rotate270ToolStripMenuItem.Name = "Rotate270ToolStripMenuItem"
        Me.Rotate270ToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.Rotate270ToolStripMenuItem.Text = "Rotate 270"
        '
        'MirrorXToolStripMenuItem
        '
        Me.MirrorXToolStripMenuItem.Name = "MirrorXToolStripMenuItem"
        Me.MirrorXToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.MirrorXToolStripMenuItem.Text = "Mirror X"
        '
        'MirrorYToolStripMenuItem
        '
        Me.MirrorYToolStripMenuItem.Name = "MirrorYToolStripMenuItem"
        Me.MirrorYToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.MirrorYToolStripMenuItem.Text = "Mirror Y"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DefaultImageSettingsToolStripMenuItem, Me.PhotoSequencesToolStripMenuItem, Me.EditScaleFactorsToolStripMenuItem, Me.ToothNumberingToolStripMenuItem, Me.ResetToothIconsToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'DefaultImageSettingsToolStripMenuItem
        '
        Me.DefaultImageSettingsToolStripMenuItem.Name = "DefaultImageSettingsToolStripMenuItem"
        Me.DefaultImageSettingsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.DefaultImageSettingsToolStripMenuItem.Text = "Default Image Settings"
        '
        'PhotoSequencesToolStripMenuItem
        '
        Me.PhotoSequencesToolStripMenuItem.Name = "PhotoSequencesToolStripMenuItem"
        Me.PhotoSequencesToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.PhotoSequencesToolStripMenuItem.Text = "Photo Sequences"
        '
        'EditScaleFactorsToolStripMenuItem
        '
        Me.EditScaleFactorsToolStripMenuItem.Name = "EditScaleFactorsToolStripMenuItem"
        Me.EditScaleFactorsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.EditScaleFactorsToolStripMenuItem.Text = "Edit Scale Factors"
        '
        'ToothNumberingToolStripMenuItem
        '
        Me.ToothNumberingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FDIToolStripMenuItem, Me.USAToolStripMenuItem, Me.DanishToolStripMenuItem, Me.BritishToolStripMenuItem})
        Me.ToothNumberingToolStripMenuItem.Name = "ToothNumberingToolStripMenuItem"
        Me.ToothNumberingToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.ToothNumberingToolStripMenuItem.Text = "Tooth Numbering"
        '
        'FDIToolStripMenuItem
        '
        Me.FDIToolStripMenuItem.Checked = True
        Me.FDIToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FDIToolStripMenuItem.Name = "FDIToolStripMenuItem"
        Me.FDIToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.FDIToolStripMenuItem.Text = "FDI"
        '
        'USAToolStripMenuItem
        '
        Me.USAToolStripMenuItem.Name = "USAToolStripMenuItem"
        Me.USAToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.USAToolStripMenuItem.Text = "USA"
        '
        'DanishToolStripMenuItem
        '
        Me.DanishToolStripMenuItem.Name = "DanishToolStripMenuItem"
        Me.DanishToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.DanishToolStripMenuItem.Text = "Danish"
        '
        'BritishToolStripMenuItem
        '
        Me.BritishToolStripMenuItem.Name = "BritishToolStripMenuItem"
        Me.BritishToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.BritishToolStripMenuItem.Text = "British"
        '
        'ResetToothIconsToolStripMenuItem
        '
        Me.ResetToothIconsToolStripMenuItem.Name = "ResetToothIconsToolStripMenuItem"
        Me.ResetToothIconsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.ResetToothIconsToolStripMenuItem.Text = "Reset Tooth Icons"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(35, 33)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton13, Me.ToolStripButton12, Me.TSBCopy, Me.TSBPaste, Me.ToolStripButton2, Me.ToolStripButton6, Me.ToolStripButton7, Me.ToolStripButton8, Me.ToolStripButton9, Me.ToolStripButton10, Me.ToolStripButton11})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(797, 40)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton13
        '
        Me.ToolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton13.Image = CType(resources.GetObject("ToolStripButton13.Image"), System.Drawing.Image)
        Me.ToolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton13.Name = "ToolStripButton13"
        Me.ToolStripButton13.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton13.Text = "Save"
        '
        'ToolStripButton12
        '
        Me.ToolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton12.Image = CType(resources.GetObject("ToolStripButton12.Image"), System.Drawing.Image)
        Me.ToolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton12.Name = "ToolStripButton12"
        Me.ToolStripButton12.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton12.Text = "Import"
        '
        'TSBCopy
        '
        Me.TSBCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBCopy.Enabled = False
        Me.TSBCopy.Image = CType(resources.GetObject("TSBCopy.Image"), System.Drawing.Image)
        Me.TSBCopy.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCopy.Name = "TSBCopy"
        Me.TSBCopy.Size = New System.Drawing.Size(39, 37)
        Me.TSBCopy.Text = "Copy"
        '
        'TSBPaste
        '
        Me.TSBPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBPaste.Enabled = False
        Me.TSBPaste.Image = CType(resources.GetObject("TSBPaste.Image"), System.Drawing.Image)
        Me.TSBPaste.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBPaste.Name = "TSBPaste"
        Me.TSBPaste.Size = New System.Drawing.Size(39, 37)
        Me.TSBPaste.Text = "Paste"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton2.Text = "Default"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton6.Text = "X-Ray Image"
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton7.Image = CType(resources.GetObject("ToolStripButton7.Image"), System.Drawing.Image)
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton7.Text = "Rotate 90º"
        '
        'ToolStripButton8
        '
        Me.ToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton8.Image = CType(resources.GetObject("ToolStripButton8.Image"), System.Drawing.Image)
        Me.ToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton8.Name = "ToolStripButton8"
        Me.ToolStripButton8.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton8.Text = "Rotate 180º"
        '
        'ToolStripButton9
        '
        Me.ToolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton9.Image = CType(resources.GetObject("ToolStripButton9.Image"), System.Drawing.Image)
        Me.ToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton9.Name = "ToolStripButton9"
        Me.ToolStripButton9.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton9.Text = "Rotate 270º"
        '
        'ToolStripButton10
        '
        Me.ToolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton10.Image = CType(resources.GetObject("ToolStripButton10.Image"), System.Drawing.Image)
        Me.ToolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton10.Name = "ToolStripButton10"
        Me.ToolStripButton10.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton10.Text = "Flip Horizontal"
        '
        'ToolStripButton11
        '
        Me.ToolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton11.Image = CType(resources.GetObject("ToolStripButton11.Image"), System.Drawing.Image)
        Me.ToolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton11.Name = "ToolStripButton11"
        Me.ToolStripButton11.Size = New System.Drawing.Size(39, 37)
        Me.ToolStripButton11.Text = "Flip Vertical"
        '
        'txtNotes
        '
        Me.txtNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNotes.Enabled = False
        Me.txtNotes.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNotes.Location = New System.Drawing.Point(5, 552)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(544, 56)
        Me.txtNotes.TabIndex = 13
        '
        'dtpRegDate
        '
        Me.dtpRegDate.CalendarFont = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpRegDate.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpRegDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpRegDate.Location = New System.Drawing.Point(672, 592)
        Me.dtpRegDate.Name = "dtpRegDate"
        Me.dtpRegDate.Size = New System.Drawing.Size(113, 23)
        Me.dtpRegDate.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(611, 597)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 14)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Date"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(2, 534)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 14)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Notes :"
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Image = CType(resources.GetObject("btnDelete.Image"), System.Drawing.Image)
        Me.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDelete.Location = New System.Drawing.Point(691, 548)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(97, 34)
        Me.btnDelete.TabIndex = 19
        Me.btnDelete.Text = "   &Exit"
        Me.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Image = CType(resources.GetObject("btnSave.Image"), System.Drawing.Image)
        Me.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.Location = New System.Drawing.Point(572, 547)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(97, 34)
        Me.btnSave.TabIndex = 18
        Me.btnSave.Text = "   &Save"
        Me.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.AutoScrollMinSize = New System.Drawing.Size(1, 1)
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(0, 66)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(797, 468)
        Me.Panel1.TabIndex = 20
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnCEPH)
        Me.Panel2.Controls.Add(Me.btnPAN)
        Me.Panel2.Controls.Add(Me.Label28)
        Me.Panel2.Controls.Add(Me.Label29)
        Me.Panel2.Controls.Add(Me.Label30)
        Me.Panel2.Controls.Add(Me.Label31)
        Me.Panel2.Controls.Add(Me.Label32)
        Me.Panel2.Controls.Add(Me.Label33)
        Me.Panel2.Controls.Add(Me.Label34)
        Me.Panel2.Controls.Add(Me.Label35)
        Me.Panel2.Controls.Add(Me.Label20)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.Label22)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Controls.Add(Me.btnL2)
        Me.Panel2.Controls.Add(Me.btnL1)
        Me.Panel2.Controls.Add(Me.btnR2)
        Me.Panel2.Controls.Add(Me.btnR1)
        Me.Panel2.Controls.Add(Me.Teeth32)
        Me.Panel2.Controls.Add(Me.Teeth31)
        Me.Panel2.Controls.Add(Me.Teeth30)
        Me.Panel2.Controls.Add(Me.Teeth29)
        Me.Panel2.Controls.Add(Me.Teeth28)
        Me.Panel2.Controls.Add(Me.Teeth27)
        Me.Panel2.Controls.Add(Me.Teeth26)
        Me.Panel2.Controls.Add(Me.Teeth25)
        Me.Panel2.Controls.Add(Me.Teeth24)
        Me.Panel2.Controls.Add(Me.Teeth23)
        Me.Panel2.Controls.Add(Me.Teeth22)
        Me.Panel2.Controls.Add(Me.Teeth21)
        Me.Panel2.Controls.Add(Me.Teeth20)
        Me.Panel2.Controls.Add(Me.Teeth19)
        Me.Panel2.Controls.Add(Me.Teeth18)
        Me.Panel2.Controls.Add(Me.Teeth17)
        Me.Panel2.Controls.Add(Me.Teeth16)
        Me.Panel2.Controls.Add(Me.Teeth15)
        Me.Panel2.Controls.Add(Me.Teeth14)
        Me.Panel2.Controls.Add(Me.Teeth13)
        Me.Panel2.Controls.Add(Me.Teeth12)
        Me.Panel2.Controls.Add(Me.Teeth11)
        Me.Panel2.Controls.Add(Me.Teeth10)
        Me.Panel2.Controls.Add(Me.Teeth9)
        Me.Panel2.Controls.Add(Me.Teeth8)
        Me.Panel2.Controls.Add(Me.Teeth7)
        Me.Panel2.Controls.Add(Me.Teeth6)
        Me.Panel2.Controls.Add(Me.Teeth5)
        Me.Panel2.Controls.Add(Me.Teeth4)
        Me.Panel2.Controls.Add(Me.Teeth3)
        Me.Panel2.Controls.Add(Me.Teeth2)
        Me.Panel2.Controls.Add(Me.Teeth1)
        Me.Panel2.Location = New System.Drawing.Point(28, 57)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(745, 323)
        Me.Panel2.TabIndex = 6
        '
        'btnCEPH
        '
        Me.btnCEPH.BackColor = System.Drawing.Color.White
        Me.btnCEPH.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCEPH.Location = New System.Drawing.Point(385, 274)
        Me.btnCEPH.Name = "btnCEPH"
        Me.btnCEPH.Size = New System.Drawing.Size(80, 33)
        Me.btnCEPH.TabIndex = 73
        Me.btnCEPH.Text = "CEPH"
        Me.btnCEPH.UseVisualStyleBackColor = False
        '
        'btnPAN
        '
        Me.btnPAN.BackColor = System.Drawing.Color.White
        Me.btnPAN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPAN.Location = New System.Drawing.Point(272, 274)
        Me.btnPAN.Name = "btnPAN"
        Me.btnPAN.Size = New System.Drawing.Size(80, 33)
        Me.btnPAN.TabIndex = 72
        Me.btnPAN.Text = "PAN"
        Me.btnPAN.UseVisualStyleBackColor = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(663, 223)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(26, 16)
        Me.Label28.TabIndex = 71
        Me.Label28.Text = "32"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.White
        Me.Label29.Location = New System.Drawing.Point(626, 223)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(26, 16)
        Me.Label29.TabIndex = 70
        Me.Label29.Text = "31"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.White
        Me.Label30.Location = New System.Drawing.Point(585, 223)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(26, 16)
        Me.Label30.TabIndex = 69
        Me.Label30.Text = "30"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.White
        Me.Label31.Location = New System.Drawing.Point(548, 223)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(26, 16)
        Me.Label31.TabIndex = 68
        Me.Label31.Text = "29"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(510, 223)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(26, 16)
        Me.Label32.TabIndex = 67
        Me.Label32.Text = "28"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.White
        Me.Label33.Location = New System.Drawing.Point(473, 223)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(26, 16)
        Me.Label33.TabIndex = 66
        Me.Label33.Text = "27"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.White
        Me.Label34.Location = New System.Drawing.Point(433, 223)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(26, 16)
        Me.Label34.TabIndex = 65
        Me.Label34.Text = "26"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.White
        Me.Label35.Location = New System.Drawing.Point(396, 223)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(26, 16)
        Me.Label35.TabIndex = 64
        Me.Label35.Text = "25"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(331, 223)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(26, 16)
        Me.Label20.TabIndex = 63
        Me.Label20.Text = "24"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(294, 223)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(26, 16)
        Me.Label21.TabIndex = 62
        Me.Label21.Text = "23"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(253, 223)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(26, 16)
        Me.Label22.TabIndex = 61
        Me.Label22.Text = "22"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(216, 223)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(26, 16)
        Me.Label23.TabIndex = 60
        Me.Label23.Text = "21"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(178, 223)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(26, 16)
        Me.Label24.TabIndex = 59
        Me.Label24.Text = "20"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(141, 223)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(26, 16)
        Me.Label25.TabIndex = 58
        Me.Label25.Text = "19"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(101, 223)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(26, 16)
        Me.Label26.TabIndex = 57
        Me.Label26.Text = "18"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(64, 223)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(26, 16)
        Me.Label27.TabIndex = 56
        Me.Label27.Text = "17"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(663, 1)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(26, 16)
        Me.Label12.TabIndex = 55
        Me.Label12.Text = "16"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(626, 1)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(26, 16)
        Me.Label13.TabIndex = 54
        Me.Label13.Text = "15"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(585, 1)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(26, 16)
        Me.Label14.TabIndex = 53
        Me.Label14.Text = "14"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(548, 1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(26, 16)
        Me.Label15.TabIndex = 52
        Me.Label15.Text = "13"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(510, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(26, 16)
        Me.Label16.TabIndex = 51
        Me.Label16.Text = "12"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(473, 1)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(26, 16)
        Me.Label17.TabIndex = 50
        Me.Label17.Text = "11"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(433, 1)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(26, 16)
        Me.Label18.TabIndex = 49
        Me.Label18.Text = "10"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(396, 1)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(17, 16)
        Me.Label19.TabIndex = 48
        Me.Label19.Text = "9"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(331, 1)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(17, 16)
        Me.Label10.TabIndex = 47
        Me.Label10.Text = "8"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(294, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(17, 16)
        Me.Label11.TabIndex = 46
        Me.Label11.Text = "7"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(253, 1)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(17, 16)
        Me.Label8.TabIndex = 45
        Me.Label8.Text = "6"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(216, 1)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(17, 16)
        Me.Label9.TabIndex = 44
        Me.Label9.Text = "5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(178, 1)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 16)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "4"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(141, 1)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(17, 16)
        Me.Label7.TabIndex = 42
        Me.Label7.Text = "3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(101, 1)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(17, 16)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(64, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(17, 16)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "1"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label38)
        Me.Panel3.Controls.Add(Me.Label37)
        Me.Panel3.Controls.Add(Me.Label36)
        Me.Panel3.Controls.Add(Me.btnCloseX)
        Me.Panel3.Controls.Add(Me.Teeth)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.PictureBox34)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Location = New System.Drawing.Point(284, 53)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(200, 143)
        Me.Panel3.TabIndex = 40
        Me.Panel3.Visible = False
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.White
        Me.Label38.Location = New System.Drawing.Point(122, 102)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(52, 16)
        Me.Label38.TabIndex = 19
        Me.Label38.Text = "X-Ray"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.White
        Me.Label37.Location = New System.Drawing.Point(121, 88)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(56, 16)
        Me.Label37.TabIndex = 18
        Me.Label37.Text = "Obtain"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.White
        Me.Label36.Location = New System.Drawing.Point(25, 88)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(58, 16)
        Me.Label36.TabIndex = 17
        Me.Label36.Text = "Import"
        '
        'btnCloseX
        '
        Me.btnCloseX.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseX.Location = New System.Drawing.Point(179, -2)
        Me.btnCloseX.Name = "btnCloseX"
        Me.btnCloseX.Size = New System.Drawing.Size(21, 20)
        Me.btnCloseX.TabIndex = 16
        Me.btnCloseX.Text = "X"
        Me.btnCloseX.UseVisualStyleBackColor = True
        '
        'Teeth
        '
        Me.Teeth.AutoSize = True
        Me.Teeth.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Teeth.ForeColor = System.Drawing.Color.White
        Me.Teeth.Location = New System.Drawing.Point(97, 3)
        Me.Teeth.Name = "Teeth"
        Me.Teeth.Size = New System.Drawing.Size(0, 16)
        Me.Teeth.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(35, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 16)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Teeth:"
        '
        'PictureBox34
        '
        Me.PictureBox34.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PictureBox34.BackgroundImage = CType(resources.GetObject("PictureBox34.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox34.Location = New System.Drawing.Point(114, 27)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(65, 58)
        Me.PictureBox34.TabIndex = 13
        Me.PictureBox34.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(21, 27)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(65, 58)
        Me.PictureBox2.TabIndex = 12
        Me.PictureBox2.TabStop = False
        '
        'btnL2
        '
        Me.btnL2.BackColor = System.Drawing.Color.White
        Me.btnL2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnL2.Location = New System.Drawing.Point(603, 274)
        Me.btnL2.Name = "btnL2"
        Me.btnL2.Size = New System.Drawing.Size(80, 33)
        Me.btnL2.TabIndex = 39
        Me.btnL2.Text = "BW L2"
        Me.btnL2.UseVisualStyleBackColor = False
        '
        'btnL1
        '
        Me.btnL1.BackColor = System.Drawing.Color.White
        Me.btnL1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnL1.Location = New System.Drawing.Point(490, 274)
        Me.btnL1.Name = "btnL1"
        Me.btnL1.Size = New System.Drawing.Size(80, 33)
        Me.btnL1.TabIndex = 38
        Me.btnL1.Text = "BW L1"
        Me.btnL1.UseVisualStyleBackColor = False
        '
        'btnR2
        '
        Me.btnR2.BackColor = System.Drawing.Color.White
        Me.btnR2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnR2.Location = New System.Drawing.Point(165, 274)
        Me.btnR2.Name = "btnR2"
        Me.btnR2.Size = New System.Drawing.Size(80, 33)
        Me.btnR2.TabIndex = 37
        Me.btnR2.Text = "BW R2"
        Me.btnR2.UseVisualStyleBackColor = False
        '
        'btnR1
        '
        Me.btnR1.BackColor = System.Drawing.Color.White
        Me.btnR1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnR1.Location = New System.Drawing.Point(52, 274)
        Me.btnR1.Name = "btnR1"
        Me.btnR1.Size = New System.Drawing.Size(80, 33)
        Me.btnR1.TabIndex = 21
        Me.btnR1.Text = "BW R1"
        Me.btnR1.UseVisualStyleBackColor = False
        '
        'Teeth32
        '
        Me.Teeth32.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth32.BackgroundImage = CType(resources.GetObject("Teeth32.BackgroundImage"), System.Drawing.Image)
        Me.Teeth32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth32.Location = New System.Drawing.Point(657, 135)
        Me.Teeth32.Name = "Teeth32"
        Me.Teeth32.Size = New System.Drawing.Size(31, 84)
        Me.Teeth32.TabIndex = 36
        Me.Teeth32.TabStop = False
        '
        'Teeth31
        '
        Me.Teeth31.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth31.BackgroundImage = CType(resources.GetObject("Teeth31.BackgroundImage"), System.Drawing.Image)
        Me.Teeth31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth31.Location = New System.Drawing.Point(620, 135)
        Me.Teeth31.Name = "Teeth31"
        Me.Teeth31.Size = New System.Drawing.Size(31, 84)
        Me.Teeth31.TabIndex = 35
        Me.Teeth31.TabStop = False
        '
        'Teeth30
        '
        Me.Teeth30.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth30.BackgroundImage = CType(resources.GetObject("Teeth30.BackgroundImage"), System.Drawing.Image)
        Me.Teeth30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth30.Location = New System.Drawing.Point(580, 135)
        Me.Teeth30.Name = "Teeth30"
        Me.Teeth30.Size = New System.Drawing.Size(31, 84)
        Me.Teeth30.TabIndex = 34
        Me.Teeth30.TabStop = False
        '
        'Teeth29
        '
        Me.Teeth29.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth29.BackgroundImage = CType(resources.GetObject("Teeth29.BackgroundImage"), System.Drawing.Image)
        Me.Teeth29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth29.Location = New System.Drawing.Point(543, 135)
        Me.Teeth29.Name = "Teeth29"
        Me.Teeth29.Size = New System.Drawing.Size(31, 84)
        Me.Teeth29.TabIndex = 33
        Me.Teeth29.TabStop = False
        '
        'Teeth28
        '
        Me.Teeth28.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth28.BackgroundImage = CType(resources.GetObject("Teeth28.BackgroundImage"), System.Drawing.Image)
        Me.Teeth28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth28.Location = New System.Drawing.Point(503, 135)
        Me.Teeth28.Name = "Teeth28"
        Me.Teeth28.Size = New System.Drawing.Size(31, 84)
        Me.Teeth28.TabIndex = 32
        Me.Teeth28.TabStop = False
        '
        'Teeth27
        '
        Me.Teeth27.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth27.BackgroundImage = CType(resources.GetObject("Teeth27.BackgroundImage"), System.Drawing.Image)
        Me.Teeth27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth27.Location = New System.Drawing.Point(466, 135)
        Me.Teeth27.Name = "Teeth27"
        Me.Teeth27.Size = New System.Drawing.Size(31, 84)
        Me.Teeth27.TabIndex = 31
        Me.Teeth27.TabStop = False
        '
        'Teeth26
        '
        Me.Teeth26.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth26.BackgroundImage = CType(resources.GetObject("Teeth26.BackgroundImage"), System.Drawing.Image)
        Me.Teeth26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth26.Location = New System.Drawing.Point(427, 135)
        Me.Teeth26.Name = "Teeth26"
        Me.Teeth26.Size = New System.Drawing.Size(31, 84)
        Me.Teeth26.TabIndex = 30
        Me.Teeth26.TabStop = False
        '
        'Teeth25
        '
        Me.Teeth25.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth25.BackgroundImage = CType(resources.GetObject("Teeth25.BackgroundImage"), System.Drawing.Image)
        Me.Teeth25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth25.Location = New System.Drawing.Point(390, 135)
        Me.Teeth25.Name = "Teeth25"
        Me.Teeth25.Size = New System.Drawing.Size(31, 84)
        Me.Teeth25.TabIndex = 29
        Me.Teeth25.TabStop = False
        '
        'Teeth24
        '
        Me.Teeth24.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth24.BackgroundImage = CType(resources.GetObject("Teeth24.BackgroundImage"), System.Drawing.Image)
        Me.Teeth24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth24.Location = New System.Drawing.Point(324, 135)
        Me.Teeth24.Name = "Teeth24"
        Me.Teeth24.Size = New System.Drawing.Size(31, 84)
        Me.Teeth24.TabIndex = 28
        Me.Teeth24.TabStop = False
        '
        'Teeth23
        '
        Me.Teeth23.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth23.BackgroundImage = CType(resources.GetObject("Teeth23.BackgroundImage"), System.Drawing.Image)
        Me.Teeth23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth23.Location = New System.Drawing.Point(287, 135)
        Me.Teeth23.Name = "Teeth23"
        Me.Teeth23.Size = New System.Drawing.Size(31, 84)
        Me.Teeth23.TabIndex = 27
        Me.Teeth23.TabStop = False
        '
        'Teeth22
        '
        Me.Teeth22.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth22.BackgroundImage = CType(resources.GetObject("Teeth22.BackgroundImage"), System.Drawing.Image)
        Me.Teeth22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth22.Location = New System.Drawing.Point(247, 135)
        Me.Teeth22.Name = "Teeth22"
        Me.Teeth22.Size = New System.Drawing.Size(31, 84)
        Me.Teeth22.TabIndex = 26
        Me.Teeth22.TabStop = False
        '
        'Teeth21
        '
        Me.Teeth21.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth21.BackgroundImage = CType(resources.GetObject("Teeth21.BackgroundImage"), System.Drawing.Image)
        Me.Teeth21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth21.Location = New System.Drawing.Point(210, 135)
        Me.Teeth21.Name = "Teeth21"
        Me.Teeth21.Size = New System.Drawing.Size(31, 84)
        Me.Teeth21.TabIndex = 25
        Me.Teeth21.TabStop = False
        '
        'Teeth20
        '
        Me.Teeth20.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth20.BackgroundImage = CType(resources.GetObject("Teeth20.BackgroundImage"), System.Drawing.Image)
        Me.Teeth20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth20.Location = New System.Drawing.Point(170, 135)
        Me.Teeth20.Name = "Teeth20"
        Me.Teeth20.Size = New System.Drawing.Size(31, 84)
        Me.Teeth20.TabIndex = 24
        Me.Teeth20.TabStop = False
        '
        'Teeth19
        '
        Me.Teeth19.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth19.BackgroundImage = CType(resources.GetObject("Teeth19.BackgroundImage"), System.Drawing.Image)
        Me.Teeth19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth19.Location = New System.Drawing.Point(133, 135)
        Me.Teeth19.Name = "Teeth19"
        Me.Teeth19.Size = New System.Drawing.Size(31, 84)
        Me.Teeth19.TabIndex = 23
        Me.Teeth19.TabStop = False
        '
        'Teeth18
        '
        Me.Teeth18.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth18.BackgroundImage = CType(resources.GetObject("Teeth18.BackgroundImage"), System.Drawing.Image)
        Me.Teeth18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth18.Location = New System.Drawing.Point(94, 135)
        Me.Teeth18.Name = "Teeth18"
        Me.Teeth18.Size = New System.Drawing.Size(31, 84)
        Me.Teeth18.TabIndex = 22
        Me.Teeth18.TabStop = False
        '
        'Teeth17
        '
        Me.Teeth17.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth17.BackgroundImage = CType(resources.GetObject("Teeth17.BackgroundImage"), System.Drawing.Image)
        Me.Teeth17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth17.Location = New System.Drawing.Point(57, 135)
        Me.Teeth17.Name = "Teeth17"
        Me.Teeth17.Size = New System.Drawing.Size(31, 84)
        Me.Teeth17.TabIndex = 21
        Me.Teeth17.TabStop = False
        '
        'Teeth16
        '
        Me.Teeth16.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth16.BackgroundImage = CType(resources.GetObject("Teeth16.BackgroundImage"), System.Drawing.Image)
        Me.Teeth16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth16.Location = New System.Drawing.Point(657, 20)
        Me.Teeth16.Name = "Teeth16"
        Me.Teeth16.Size = New System.Drawing.Size(31, 84)
        Me.Teeth16.TabIndex = 20
        Me.Teeth16.TabStop = False
        '
        'Teeth15
        '
        Me.Teeth15.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth15.BackgroundImage = CType(resources.GetObject("Teeth15.BackgroundImage"), System.Drawing.Image)
        Me.Teeth15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth15.Location = New System.Drawing.Point(620, 20)
        Me.Teeth15.Name = "Teeth15"
        Me.Teeth15.Size = New System.Drawing.Size(31, 84)
        Me.Teeth15.TabIndex = 19
        Me.Teeth15.TabStop = False
        '
        'Teeth14
        '
        Me.Teeth14.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth14.BackgroundImage = CType(resources.GetObject("Teeth14.BackgroundImage"), System.Drawing.Image)
        Me.Teeth14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth14.Location = New System.Drawing.Point(580, 20)
        Me.Teeth14.Name = "Teeth14"
        Me.Teeth14.Size = New System.Drawing.Size(31, 84)
        Me.Teeth14.TabIndex = 18
        Me.Teeth14.TabStop = False
        '
        'Teeth13
        '
        Me.Teeth13.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth13.BackgroundImage = CType(resources.GetObject("Teeth13.BackgroundImage"), System.Drawing.Image)
        Me.Teeth13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth13.Location = New System.Drawing.Point(543, 20)
        Me.Teeth13.Name = "Teeth13"
        Me.Teeth13.Size = New System.Drawing.Size(31, 84)
        Me.Teeth13.TabIndex = 17
        Me.Teeth13.TabStop = False
        '
        'Teeth12
        '
        Me.Teeth12.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth12.BackgroundImage = CType(resources.GetObject("Teeth12.BackgroundImage"), System.Drawing.Image)
        Me.Teeth12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth12.Location = New System.Drawing.Point(503, 20)
        Me.Teeth12.Name = "Teeth12"
        Me.Teeth12.Size = New System.Drawing.Size(31, 84)
        Me.Teeth12.TabIndex = 16
        Me.Teeth12.TabStop = False
        '
        'Teeth11
        '
        Me.Teeth11.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth11.BackgroundImage = CType(resources.GetObject("Teeth11.BackgroundImage"), System.Drawing.Image)
        Me.Teeth11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth11.Location = New System.Drawing.Point(466, 20)
        Me.Teeth11.Name = "Teeth11"
        Me.Teeth11.Size = New System.Drawing.Size(31, 84)
        Me.Teeth11.TabIndex = 15
        Me.Teeth11.TabStop = False
        '
        'Teeth10
        '
        Me.Teeth10.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth10.BackgroundImage = CType(resources.GetObject("Teeth10.BackgroundImage"), System.Drawing.Image)
        Me.Teeth10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth10.Location = New System.Drawing.Point(427, 20)
        Me.Teeth10.Name = "Teeth10"
        Me.Teeth10.Size = New System.Drawing.Size(31, 84)
        Me.Teeth10.TabIndex = 14
        Me.Teeth10.TabStop = False
        '
        'Teeth9
        '
        Me.Teeth9.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth9.BackgroundImage = CType(resources.GetObject("Teeth9.BackgroundImage"), System.Drawing.Image)
        Me.Teeth9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth9.Location = New System.Drawing.Point(390, 20)
        Me.Teeth9.Name = "Teeth9"
        Me.Teeth9.Size = New System.Drawing.Size(31, 84)
        Me.Teeth9.TabIndex = 13
        Me.Teeth9.TabStop = False
        '
        'Teeth8
        '
        Me.Teeth8.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth8.BackgroundImage = CType(resources.GetObject("Teeth8.BackgroundImage"), System.Drawing.Image)
        Me.Teeth8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth8.Location = New System.Drawing.Point(324, 20)
        Me.Teeth8.Name = "Teeth8"
        Me.Teeth8.Size = New System.Drawing.Size(31, 84)
        Me.Teeth8.TabIndex = 12
        Me.Teeth8.TabStop = False
        '
        'Teeth7
        '
        Me.Teeth7.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth7.BackgroundImage = CType(resources.GetObject("Teeth7.BackgroundImage"), System.Drawing.Image)
        Me.Teeth7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth7.Location = New System.Drawing.Point(287, 20)
        Me.Teeth7.Name = "Teeth7"
        Me.Teeth7.Size = New System.Drawing.Size(31, 84)
        Me.Teeth7.TabIndex = 11
        Me.Teeth7.TabStop = False
        '
        'Teeth6
        '
        Me.Teeth6.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth6.BackgroundImage = CType(resources.GetObject("Teeth6.BackgroundImage"), System.Drawing.Image)
        Me.Teeth6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth6.Location = New System.Drawing.Point(247, 20)
        Me.Teeth6.Name = "Teeth6"
        Me.Teeth6.Size = New System.Drawing.Size(31, 84)
        Me.Teeth6.TabIndex = 10
        Me.Teeth6.TabStop = False
        '
        'Teeth5
        '
        Me.Teeth5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth5.BackgroundImage = CType(resources.GetObject("Teeth5.BackgroundImage"), System.Drawing.Image)
        Me.Teeth5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth5.Location = New System.Drawing.Point(210, 20)
        Me.Teeth5.Name = "Teeth5"
        Me.Teeth5.Size = New System.Drawing.Size(31, 84)
        Me.Teeth5.TabIndex = 9
        Me.Teeth5.TabStop = False
        '
        'Teeth4
        '
        Me.Teeth4.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth4.BackgroundImage = CType(resources.GetObject("Teeth4.BackgroundImage"), System.Drawing.Image)
        Me.Teeth4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth4.Location = New System.Drawing.Point(170, 20)
        Me.Teeth4.Name = "Teeth4"
        Me.Teeth4.Size = New System.Drawing.Size(31, 84)
        Me.Teeth4.TabIndex = 8
        Me.Teeth4.TabStop = False
        '
        'Teeth3
        '
        Me.Teeth3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth3.BackgroundImage = CType(resources.GetObject("Teeth3.BackgroundImage"), System.Drawing.Image)
        Me.Teeth3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth3.Location = New System.Drawing.Point(133, 20)
        Me.Teeth3.Name = "Teeth3"
        Me.Teeth3.Size = New System.Drawing.Size(31, 84)
        Me.Teeth3.TabIndex = 7
        Me.Teeth3.TabStop = False
        '
        'Teeth2
        '
        Me.Teeth2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth2.BackgroundImage = CType(resources.GetObject("Teeth2.BackgroundImage"), System.Drawing.Image)
        Me.Teeth2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth2.Location = New System.Drawing.Point(94, 20)
        Me.Teeth2.Name = "Teeth2"
        Me.Teeth2.Size = New System.Drawing.Size(31, 84)
        Me.Teeth2.TabIndex = 6
        Me.Teeth2.TabStop = False
        '
        'Teeth1
        '
        Me.Teeth1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Teeth1.BackgroundImage = CType(resources.GetObject("Teeth1.BackgroundImage"), System.Drawing.Image)
        Me.Teeth1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Teeth1.Location = New System.Drawing.Point(57, 20)
        Me.Teeth1.Name = "Teeth1"
        Me.Teeth1.Size = New System.Drawing.Size(31, 84)
        Me.Teeth1.TabIndex = 5
        Me.Teeth1.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.PictureBox1.Location = New System.Drawing.Point(-1, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(797, 466)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'frm_Patient_NewImage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(797, 619)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtpRegDate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frm_Patient_NewImage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Image Input"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Teeth1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents TSBCopy As System.Windows.Forms.ToolStripButton
    Friend WithEvents TSBPaste As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton8 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton9 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton10 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton11 As System.Windows.Forms.ToolStripButton
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents dtpRegDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Rotate90ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rotate180ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Rotate270ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MirrorXToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MirrorYToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultImageSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PhotoSequencesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditScaleFactorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToothNumberingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FDIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents USAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DanishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BritishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResetToothIconsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScannerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents XRayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadBackupImagesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AutoResetPatientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AutoSaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoAcquireToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FootpedalActiveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton13 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton12 As System.Windows.Forms.ToolStripButton
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Teeth2 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth1 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth8 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth7 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth6 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth5 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth4 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth3 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth16 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth15 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth14 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth13 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth12 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth11 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth10 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth9 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth32 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth31 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth30 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth29 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth28 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth27 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth26 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth25 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth24 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth23 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth22 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth21 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth20 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth19 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth18 As System.Windows.Forms.PictureBox
    Friend WithEvents Teeth17 As System.Windows.Forms.PictureBox
    Friend WithEvents btnR1 As System.Windows.Forms.Button
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents btnR2 As System.Windows.Forms.Button
    Friend WithEvents btnL2 As System.Windows.Forms.Button
    Friend WithEvents btnL1 As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox34 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Teeth As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnCloseX As System.Windows.Forms.Button
    Friend WithEvents btnCEPH As System.Windows.Forms.Button
    Friend WithEvents btnPAN As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
