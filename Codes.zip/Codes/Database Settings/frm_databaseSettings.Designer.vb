﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_databaseSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_databaseSettings))
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.txtPortNumber = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtHostName = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.chkReplication = New System.Windows.Forms.CheckBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.btnFilePath_Open1 = New System.Windows.Forms.Button()
        Me.txtFilePath_Read = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.chkReceiveSync = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.btnFilePath_Open = New System.Windows.Forms.Button()
        Me.txtFilePath_Send = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.chkAutoStart_Slave = New System.Windows.Forms.CheckBox()
        Me.chkSyncAuto = New System.Windows.Forms.CheckBox()
        Me.chkSendSync = New System.Windows.Forms.CheckBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtWorkstation_Name = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkDentist_ID = New System.Windows.Forms.CheckBox()
        Me.chkWorkstations = New System.Windows.Forms.CheckBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LetterJPEG = New System.Windows.Forms.NumericUpDown()
        Me.cmbLetterImg = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ThumbnailsJPEG = New System.Windows.Forms.NumericUpDown()
        Me.cmbColorThumbnails = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ColorJPEG = New System.Windows.Forms.NumericUpDown()
        Me.cmbColorImages = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.XrayJPEG = New System.Windows.Forms.NumericUpDown()
        Me.cmbXRay_fotos = New System.Windows.Forms.ComboBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.btnLocks_browse = New System.Windows.Forms.Button()
        Me.txtLocks_folder = New System.Windows.Forms.TextBox()
        Me.btnImplants_browse = New System.Windows.Forms.Button()
        Me.txtImplants_folder = New System.Windows.Forms.TextBox()
        Me.btnFileDbase_browse = New System.Windows.Forms.Button()
        Me.txtFileDbase_path = New System.Windows.Forms.TextBox()
        Me.btnDbase_browse = New System.Windows.Forms.Button()
        Me.txtDbase_path = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.chkPerformTest = New System.Windows.Forms.CheckBox()
        Me.chkDisableDelete = New System.Windows.Forms.CheckBox()
        Me.chkAutoOpen = New System.Windows.Forms.CheckBox()
        Me.chkAutoPt_ID = New System.Windows.Forms.CheckBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.TabPage6.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.LetterJPEG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.ThumbnailsJPEG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.ColorJPEG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.XrayJPEG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.txtPortNumber)
        Me.TabPage6.Controls.Add(Me.Label15)
        Me.TabPage6.Controls.Add(Me.txtHostName)
        Me.TabPage6.Controls.Add(Me.Label14)
        Me.TabPage6.Controls.Add(Me.chkReplication)
        Me.TabPage6.Location = New System.Drawing.Point(4, 23)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(810, 419)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Replication"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'txtPortNumber
        '
        Me.txtPortNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPortNumber.Location = New System.Drawing.Point(129, 94)
        Me.txtPortNumber.Name = "txtPortNumber"
        Me.txtPortNumber.Size = New System.Drawing.Size(179, 22)
        Me.txtPortNumber.TabIndex = 4
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(24, 97)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(90, 14)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "Port number:"
        '
        'txtHostName
        '
        Me.txtHostName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtHostName.Location = New System.Drawing.Point(129, 66)
        Me.txtHostName.Name = "txtHostName"
        Me.txtHostName.Size = New System.Drawing.Size(457, 22)
        Me.txtHostName.TabIndex = 2
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(24, 69)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 14)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Host name/IP:"
        '
        'chkReplication
        '
        Me.chkReplication.AutoSize = True
        Me.chkReplication.Location = New System.Drawing.Point(15, 22)
        Me.chkReplication.Name = "chkReplication"
        Me.chkReplication.Size = New System.Drawing.Size(110, 17)
        Me.chkReplication.TabIndex = 0
        Me.chkReplication.Text = "Enable replication"
        Me.chkReplication.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox6)
        Me.TabPage5.Controls.Add(Me.GroupBox5)
        Me.TabPage5.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage5.Location = New System.Drawing.Point(4, 23)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(810, 419)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Synchron."
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.btnFilePath_Open1)
        Me.GroupBox6.Controls.Add(Me.txtFilePath_Read)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.chkReceiveSync)
        Me.GroupBox6.Location = New System.Drawing.Point(20, 183)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(558, 107)
        Me.GroupBox6.TabIndex = 18
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Slave"
        '
        'btnFilePath_Open1
        '
        Me.btnFilePath_Open1.BackgroundImage = CType(resources.GetObject("btnFilePath_Open1.BackgroundImage"), System.Drawing.Image)
        Me.btnFilePath_Open1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnFilePath_Open1.Location = New System.Drawing.Point(428, 69)
        Me.btnFilePath_Open1.Name = "btnFilePath_Open1"
        Me.btnFilePath_Open1.Size = New System.Drawing.Size(40, 28)
        Me.btnFilePath_Open1.TabIndex = 5
        Me.btnFilePath_Open1.UseVisualStyleBackColor = True
        '
        'txtFilePath_Read
        '
        Me.txtFilePath_Read.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilePath_Read.Location = New System.Drawing.Point(19, 71)
        Me.txtFilePath_Read.Name = "txtFilePath_Read"
        Me.txtFilePath_Read.Size = New System.Drawing.Size(403, 22)
        Me.txtFilePath_Read.TabIndex = 4
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(16, 54)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(148, 14)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "File path to read from:"
        '
        'chkReceiveSync
        '
        Me.chkReceiveSync.AutoSize = True
        Me.chkReceiveSync.Location = New System.Drawing.Point(19, 23)
        Me.chkReceiveSync.Name = "chkReceiveSync"
        Me.chkReceiveSync.Size = New System.Drawing.Size(213, 18)
        Me.chkReceiveSync.TabIndex = 0
        Me.chkReceiveSync.Text = "Receive synchronize requests"
        Me.chkReceiveSync.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnFilePath_Open)
        Me.GroupBox5.Controls.Add(Me.txtFilePath_Send)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.chkAutoStart_Slave)
        Me.GroupBox5.Controls.Add(Me.chkSyncAuto)
        Me.GroupBox5.Controls.Add(Me.chkSendSync)
        Me.GroupBox5.Location = New System.Drawing.Point(20, 16)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(558, 140)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Master"
        '
        'btnFilePath_Open
        '
        Me.btnFilePath_Open.BackgroundImage = CType(resources.GetObject("btnFilePath_Open.BackgroundImage"), System.Drawing.Image)
        Me.btnFilePath_Open.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnFilePath_Open.Location = New System.Drawing.Point(428, 101)
        Me.btnFilePath_Open.Name = "btnFilePath_Open"
        Me.btnFilePath_Open.Size = New System.Drawing.Size(40, 28)
        Me.btnFilePath_Open.TabIndex = 5
        Me.btnFilePath_Open.UseVisualStyleBackColor = True
        '
        'txtFilePath_Send
        '
        Me.txtFilePath_Send.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilePath_Send.Location = New System.Drawing.Point(19, 104)
        Me.txtFilePath_Send.Name = "txtFilePath_Send"
        Me.txtFilePath_Send.Size = New System.Drawing.Size(403, 22)
        Me.txtFilePath_Send.TabIndex = 4
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(16, 87)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(135, 14)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "File path to send to:"
        '
        'chkAutoStart_Slave
        '
        Me.chkAutoStart_Slave.AutoSize = True
        Me.chkAutoStart_Slave.Location = New System.Drawing.Point(19, 58)
        Me.chkAutoStart_Slave.Name = "chkAutoStart_Slave"
        Me.chkAutoStart_Slave.Size = New System.Drawing.Size(224, 18)
        Me.chkAutoStart_Slave.TabIndex = 2
        Me.chkAutoStart_Slave.Text = "Auto-start the slave application"
        Me.chkAutoStart_Slave.UseVisualStyleBackColor = True
        '
        'chkSyncAuto
        '
        Me.chkSyncAuto.AutoSize = True
        Me.chkSyncAuto.Location = New System.Drawing.Point(19, 40)
        Me.chkSyncAuto.Name = "chkSyncAuto"
        Me.chkSyncAuto.Size = New System.Drawing.Size(189, 18)
        Me.chkSyncAuto.TabIndex = 1
        Me.chkSyncAuto.Text = "Synchronize automatically"
        Me.chkSyncAuto.UseVisualStyleBackColor = True
        '
        'chkSendSync
        '
        Me.chkSendSync.AutoSize = True
        Me.chkSendSync.Location = New System.Drawing.Point(19, 23)
        Me.chkSendSync.Name = "chkSendSync"
        Me.chkSendSync.Size = New System.Drawing.Size(197, 18)
        Me.chkSendSync.TabIndex = 0
        Me.chkSendSync.Text = "Send synchronize requests"
        Me.chkSendSync.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.DataGridView1)
        Me.TabPage4.Controls.Add(Me.Label11)
        Me.TabPage4.Controls.Add(Me.Label10)
        Me.TabPage4.Controls.Add(Me.txtWorkstation_Name)
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.chkDentist_ID)
        Me.TabPage4.Controls.Add(Me.chkWorkstations)
        Me.TabPage4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(810, 419)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Workstations"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        Me.DataGridView1.Location = New System.Drawing.Point(20, 155)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(560, 244)
        Me.DataGridView1.TabIndex = 6
        '
        'Column1
        '
        Me.Column1.HeaderText = "Name"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Description"
        Me.Column2.Name = "Column2"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(17, 138)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(96, 14)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Workstations:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(204, 95)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(337, 14)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "The name must match an existing workstation name"
        '
        'txtWorkstation_Name
        '
        Me.txtWorkstation_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWorkstation_Name.Location = New System.Drawing.Point(207, 70)
        Me.txtWorkstation_Name.Name = "txtWorkstation_Name"
        Me.txtWorkstation_Name.Size = New System.Drawing.Size(334, 22)
        Me.txtWorkstation_Name.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(73, 73)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(128, 14)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Workstation name:"
        '
        'chkDentist_ID
        '
        Me.chkDentist_ID.AutoSize = True
        Me.chkDentist_ID.Location = New System.Drawing.Point(20, 36)
        Me.chkDentist_ID.Name = "chkDentist_ID"
        Me.chkDentist_ID.Size = New System.Drawing.Size(139, 18)
        Me.chkDentist_ID.TabIndex = 1
        Me.chkDentist_ID.Text = "Display Dentist-ID"
        Me.chkDentist_ID.UseVisualStyleBackColor = True
        '
        'chkWorkstations
        '
        Me.chkWorkstations.AutoSize = True
        Me.chkWorkstations.Location = New System.Drawing.Point(20, 17)
        Me.chkWorkstations.Name = "chkWorkstations"
        Me.chkWorkstations.Size = New System.Drawing.Size(155, 18)
        Me.chkWorkstations.TabIndex = 0
        Me.chkWorkstations.Text = "Enable workstations"
        Me.chkWorkstations.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Controls.Add(Me.GroupBox3)
        Me.TabPage3.Controls.Add(Me.GroupBox2)
        Me.TabPage3.Controls.Add(Me.GroupBox1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 23)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(810, 419)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Compression"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.LetterJPEG)
        Me.GroupBox4.Controls.Add(Me.cmbLetterImg)
        Me.GroupBox4.Location = New System.Drawing.Point(24, 303)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(547, 88)
        Me.GroupBox4.TabIndex = 18
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Letter images"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(262, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(128, 14)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "JPEG quality factor:"
        '
        'LetterJPEG
        '
        Me.LetterJPEG.Location = New System.Drawing.Point(399, 50)
        Me.LetterJPEG.Name = "LetterJPEG"
        Me.LetterJPEG.Size = New System.Drawing.Size(120, 22)
        Me.LetterJPEG.TabIndex = 1
        Me.LetterJPEG.Value = New Decimal(New Integer() {60, 0, 0, 0})
        '
        'cmbLetterImg
        '
        Me.cmbLetterImg.FormattingEnabled = True
        Me.cmbLetterImg.Items.AddRange(New Object() {"No compression", "JPEG(lossy,high compression)", "JPEG2000(little loss,high compression)", "ZIP(loseless,low compression)"})
        Me.cmbLetterImg.Location = New System.Drawing.Point(35, 21)
        Me.cmbLetterImg.Name = "cmbLetterImg"
        Me.cmbLetterImg.Size = New System.Drawing.Size(484, 22)
        Me.cmbLetterImg.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.ThumbnailsJPEG)
        Me.GroupBox3.Controls.Add(Me.cmbColorThumbnails)
        Me.GroupBox3.Location = New System.Drawing.Point(24, 207)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(547, 88)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Color thumbnails"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(262, 53)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 14)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "JPEG quality factor:"
        '
        'ThumbnailsJPEG
        '
        Me.ThumbnailsJPEG.Location = New System.Drawing.Point(399, 50)
        Me.ThumbnailsJPEG.Name = "ThumbnailsJPEG"
        Me.ThumbnailsJPEG.Size = New System.Drawing.Size(120, 22)
        Me.ThumbnailsJPEG.TabIndex = 1
        Me.ThumbnailsJPEG.Value = New Decimal(New Integer() {75, 0, 0, 0})
        '
        'cmbColorThumbnails
        '
        Me.cmbColorThumbnails.FormattingEnabled = True
        Me.cmbColorThumbnails.Items.AddRange(New Object() {"No compression", "JPEG(lossy,high compression)", "JPEG2000(little loss,high compression)", "ZIP(loseless,low compression)"})
        Me.cmbColorThumbnails.Location = New System.Drawing.Point(35, 21)
        Me.cmbColorThumbnails.Name = "cmbColorThumbnails"
        Me.cmbColorThumbnails.Size = New System.Drawing.Size(484, 22)
        Me.cmbColorThumbnails.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.ColorJPEG)
        Me.GroupBox2.Controls.Add(Me.cmbColorImages)
        Me.GroupBox2.Location = New System.Drawing.Point(24, 113)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(547, 88)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Color images"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(262, 53)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 14)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "JPEG quality factor:"
        '
        'ColorJPEG
        '
        Me.ColorJPEG.Location = New System.Drawing.Point(399, 50)
        Me.ColorJPEG.Name = "ColorJPEG"
        Me.ColorJPEG.Size = New System.Drawing.Size(120, 22)
        Me.ColorJPEG.TabIndex = 1
        Me.ColorJPEG.Value = New Decimal(New Integer() {80, 0, 0, 0})
        '
        'cmbColorImages
        '
        Me.cmbColorImages.FormattingEnabled = True
        Me.cmbColorImages.Items.AddRange(New Object() {"No compression", "JPEG(lossy,high compression)", "JPEG2000(little loss,high compression)", "ZIP(loseless,low compression)"})
        Me.cmbColorImages.Location = New System.Drawing.Point(35, 21)
        Me.cmbColorImages.Name = "cmbColorImages"
        Me.cmbColorImages.Size = New System.Drawing.Size(484, 22)
        Me.cmbColorImages.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.XrayJPEG)
        Me.GroupBox1.Controls.Add(Me.cmbXRay_fotos)
        Me.GroupBox1.Location = New System.Drawing.Point(24, 14)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(547, 88)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "X-Ray fotos"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(262, 53)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(128, 14)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "JPEG quality factor:"
        '
        'XrayJPEG
        '
        Me.XrayJPEG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.XrayJPEG.Location = New System.Drawing.Point(399, 50)
        Me.XrayJPEG.Name = "XrayJPEG"
        Me.XrayJPEG.Size = New System.Drawing.Size(120, 22)
        Me.XrayJPEG.TabIndex = 1
        Me.XrayJPEG.Value = New Decimal(New Integer() {90, 0, 0, 0})
        '
        'cmbXRay_fotos
        '
        Me.cmbXRay_fotos.FormattingEnabled = True
        Me.cmbXRay_fotos.Items.AddRange(New Object() {"No compression", "JPEG(lossy,high compression)", "JPEG2000(little loss,high compression)", "ZIP(loseless,low compression)"})
        Me.cmbXRay_fotos.Location = New System.Drawing.Point(35, 21)
        Me.cmbXRay_fotos.Name = "cmbXRay_fotos"
        Me.cmbXRay_fotos.Size = New System.Drawing.Size(484, 22)
        Me.cmbXRay_fotos.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btnLocks_browse)
        Me.TabPage2.Controls.Add(Me.txtLocks_folder)
        Me.TabPage2.Controls.Add(Me.btnImplants_browse)
        Me.TabPage2.Controls.Add(Me.txtImplants_folder)
        Me.TabPage2.Controls.Add(Me.btnFileDbase_browse)
        Me.TabPage2.Controls.Add(Me.txtFileDbase_path)
        Me.TabPage2.Controls.Add(Me.btnDbase_browse)
        Me.TabPage2.Controls.Add(Me.txtDbase_path)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(810, 419)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Database"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btnLocks_browse
        '
        Me.btnLocks_browse.BackgroundImage = CType(resources.GetObject("btnLocks_browse.BackgroundImage"), System.Drawing.Image)
        Me.btnLocks_browse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnLocks_browse.Location = New System.Drawing.Point(605, 193)
        Me.btnLocks_browse.Name = "btnLocks_browse"
        Me.btnLocks_browse.Size = New System.Drawing.Size(39, 27)
        Me.btnLocks_browse.TabIndex = 11
        Me.btnLocks_browse.UseVisualStyleBackColor = True
        '
        'txtLocks_folder
        '
        Me.txtLocks_folder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLocks_folder.Location = New System.Drawing.Point(205, 195)
        Me.txtLocks_folder.Name = "txtLocks_folder"
        Me.txtLocks_folder.Size = New System.Drawing.Size(394, 22)
        Me.txtLocks_folder.TabIndex = 10
        '
        'btnImplants_browse
        '
        Me.btnImplants_browse.BackgroundImage = CType(resources.GetObject("btnImplants_browse.BackgroundImage"), System.Drawing.Image)
        Me.btnImplants_browse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnImplants_browse.Location = New System.Drawing.Point(605, 132)
        Me.btnImplants_browse.Name = "btnImplants_browse"
        Me.btnImplants_browse.Size = New System.Drawing.Size(39, 27)
        Me.btnImplants_browse.TabIndex = 9
        Me.btnImplants_browse.UseVisualStyleBackColor = True
        '
        'txtImplants_folder
        '
        Me.txtImplants_folder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtImplants_folder.Location = New System.Drawing.Point(205, 134)
        Me.txtImplants_folder.Name = "txtImplants_folder"
        Me.txtImplants_folder.Size = New System.Drawing.Size(394, 22)
        Me.txtImplants_folder.TabIndex = 8
        '
        'btnFileDbase_browse
        '
        Me.btnFileDbase_browse.BackgroundImage = CType(resources.GetObject("btnFileDbase_browse.BackgroundImage"), System.Drawing.Image)
        Me.btnFileDbase_browse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnFileDbase_browse.Location = New System.Drawing.Point(605, 75)
        Me.btnFileDbase_browse.Name = "btnFileDbase_browse"
        Me.btnFileDbase_browse.Size = New System.Drawing.Size(39, 27)
        Me.btnFileDbase_browse.TabIndex = 7
        Me.btnFileDbase_browse.UseVisualStyleBackColor = True
        '
        'txtFileDbase_path
        '
        Me.txtFileDbase_path.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFileDbase_path.Location = New System.Drawing.Point(205, 77)
        Me.txtFileDbase_path.Name = "txtFileDbase_path"
        Me.txtFileDbase_path.Size = New System.Drawing.Size(394, 22)
        Me.txtFileDbase_path.TabIndex = 6
        '
        'btnDbase_browse
        '
        Me.btnDbase_browse.BackgroundImage = CType(resources.GetObject("btnDbase_browse.BackgroundImage"), System.Drawing.Image)
        Me.btnDbase_browse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnDbase_browse.Location = New System.Drawing.Point(605, 19)
        Me.btnDbase_browse.Name = "btnDbase_browse"
        Me.btnDbase_browse.Size = New System.Drawing.Size(39, 28)
        Me.btnDbase_browse.TabIndex = 5
        Me.btnDbase_browse.UseVisualStyleBackColor = True
        '
        'txtDbase_path
        '
        Me.txtDbase_path.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDbase_path.Location = New System.Drawing.Point(205, 23)
        Me.txtDbase_path.Name = "txtDbase_path"
        Me.txtDbase_path.Size = New System.Drawing.Size(394, 22)
        Me.txtDbase_path.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(69, 198)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(87, 14)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Locks folder:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(69, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 14)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Implants folder:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 14)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "File-database path:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Database path:"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.chkPerformTest)
        Me.TabPage1.Controls.Add(Me.chkDisableDelete)
        Me.TabPage1.Controls.Add(Me.chkAutoOpen)
        Me.TabPage1.Controls.Add(Me.chkAutoPt_ID)
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(810, 419)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "General"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'chkPerformTest
        '
        Me.chkPerformTest.AutoSize = True
        Me.chkPerformTest.Location = New System.Drawing.Point(16, 81)
        Me.chkPerformTest.Name = "chkPerformTest"
        Me.chkPerformTest.Size = New System.Drawing.Size(232, 18)
        Me.chkPerformTest.TabIndex = 3
        Me.chkPerformTest.Text = "Perform 11 test on SSN numbers"
        Me.chkPerformTest.UseVisualStyleBackColor = True
        '
        'chkDisableDelete
        '
        Me.chkDisableDelete.AutoSize = True
        Me.chkDisableDelete.Location = New System.Drawing.Point(16, 62)
        Me.chkDisableDelete.Name = "chkDisableDelete"
        Me.chkDisableDelete.Size = New System.Drawing.Size(164, 18)
        Me.chkDisableDelete.TabIndex = 2
        Me.chkDisableDelete.Text = "Disable delete photos"
        Me.chkDisableDelete.UseVisualStyleBackColor = True
        '
        'chkAutoOpen
        '
        Me.chkAutoOpen.AutoSize = True
        Me.chkAutoOpen.Location = New System.Drawing.Point(16, 43)
        Me.chkAutoOpen.Name = "chkAutoOpen"
        Me.chkAutoOpen.Size = New System.Drawing.Size(216, 18)
        Me.chkAutoOpen.TabIndex = 1
        Me.chkAutoOpen.Text = "Auto-open patient list window"
        Me.chkAutoOpen.UseVisualStyleBackColor = True
        '
        'chkAutoPt_ID
        '
        Me.chkAutoPt_ID.AutoSize = True
        Me.chkAutoPt_ID.Location = New System.Drawing.Point(16, 24)
        Me.chkAutoPt_ID.Name = "chkAutoPt_ID"
        Me.chkAutoPt_ID.Size = New System.Drawing.Size(167, 18)
        Me.chkAutoPt_ID.TabIndex = 0
        Me.chkAutoPt_ID.Text = "Auto create patient-ID"
        Me.chkAutoPt_ID.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(12, 2)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(818, 446)
        Me.TabControl1.TabIndex = 0
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(699, 149)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(94, 31)
        Me.btnHelp.TabIndex = 17
        Me.btnHelp.Text = "&Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(699, 101)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(94, 31)
        Me.btnCancel.TabIndex = 16
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOk
        '
        Me.btnOk.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOk.Location = New System.Drawing.Point(699, 55)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(94, 31)
        Me.btnOk.TabIndex = 15
        Me.btnOk.Text = "&Ok"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'frm_databaseSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(830, 448)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frm_databaseSettings"
        Me.Text = "Database Settings"
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.LetterJPEG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.ThumbnailsJPEG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.ColorJPEG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.XrayJPEG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents chkPerformTest As System.Windows.Forms.CheckBox
    Friend WithEvents chkDisableDelete As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoOpen As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoPt_ID As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtDbase_path As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnImplants_browse As System.Windows.Forms.Button
    Friend WithEvents txtImplants_folder As System.Windows.Forms.TextBox
    Friend WithEvents btnFileDbase_browse As System.Windows.Forms.Button
    Friend WithEvents txtFileDbase_path As System.Windows.Forms.TextBox
    Friend WithEvents btnDbase_browse As System.Windows.Forms.Button
    Friend WithEvents btnLocks_browse As System.Windows.Forms.Button
    Friend WithEvents txtLocks_folder As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LetterJPEG As System.Windows.Forms.NumericUpDown
    Friend WithEvents cmbLetterImg As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ThumbnailsJPEG As System.Windows.Forms.NumericUpDown
    Friend WithEvents cmbColorThumbnails As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ColorJPEG As System.Windows.Forms.NumericUpDown
    Friend WithEvents cmbColorImages As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents XrayJPEG As System.Windows.Forms.NumericUpDown
    Friend WithEvents cmbXRay_fotos As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtWorkstation_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkDentist_ID As System.Windows.Forms.CheckBox
    Friend WithEvents chkWorkstations As System.Windows.Forms.CheckBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtFilePath_Send As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents chkAutoStart_Slave As System.Windows.Forms.CheckBox
    Friend WithEvents chkSyncAuto As System.Windows.Forms.CheckBox
    Friend WithEvents chkSendSync As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents btnFilePath_Open1 As System.Windows.Forms.Button
    Friend WithEvents txtFilePath_Read As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents chkReceiveSync As System.Windows.Forms.CheckBox
    Friend WithEvents btnFilePath_Open As System.Windows.Forms.Button
    Friend WithEvents txtPortNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtHostName As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents chkReplication As System.Windows.Forms.CheckBox
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOk As System.Windows.Forms.Button
End Class
